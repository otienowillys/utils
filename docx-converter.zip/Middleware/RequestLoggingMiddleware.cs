using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace DocxConverter.Middleware
{
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RequestLoggingMiddleware> _logger;

        public RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var stopwatch = Stopwatch.StartNew();
            var requestId = Guid.NewGuid().ToString();
            
            // Add request ID to response headers for tracking
            context.Response.Headers.Add("X-Request-ID", requestId);
            
            // Log request details
            _logger.LogInformation(
                "Request {RequestId} {Method} {Path} started at {Time} from {IP}",
                requestId,
                context.Request.Method,
                context.Request.Path,
                DateTime.UtcNow,
                context.Connection.RemoteIpAddress
            );
            
            // Enable request body rewind
            context.Request.EnableBuffering();
            
            // Capture the original response body stream
            var originalBodyStream = context.Response.Body;
            
            try
            {
                // Create a new memory stream for the response
                using var responseBody = new MemoryStream();
                context.Response.Body = responseBody;
                
                // Continue down the middleware pipeline
                await _next(context);
                
                // Log response details
                stopwatch.Stop();
                _logger.LogInformation(
                    "Request {RequestId} {Method} {Path} completed with status {StatusCode} in {ElapsedMilliseconds}ms",
                    requestId,
                    context.Request.Method,
                    context.Request.Path,
                    context.Response.StatusCode,
                    stopwatch.ElapsedMilliseconds
                );
                
                // Copy the response body to the original stream
                responseBody.Seek(0, SeekOrigin.Begin);
                await responseBody.CopyToAsync(originalBodyStream);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger.LogError(
                    ex,
                    "Request {RequestId} {Method} {Path} failed after {ElapsedMilliseconds}ms",
                    requestId,
                    context.Request.Method,
                    context.Request.Path,
                    stopwatch.ElapsedMilliseconds
                );
                throw;
            }
            finally
            {
                // Restore the original response body stream
                context.Response.Body = originalBodyStream;
            }
        }
    }
}

