// This is an empty middleware file to replace any existing middleware
// that might be causing redirection issues

