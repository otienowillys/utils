using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DocxConverter.Services
{
    public interface IStorageService
    {
        Task<string> UploadFileAsync(IFormFile file, string containerName);
        Task<string> UploadFileAsync(byte[] fileData, string fileName, string containerName);
        Task<byte[]> DownloadFileAsync(string fileName, string containerName);
        Task DeleteFileAsync(string fileName, string containerName);
        string GetFileUrl(string fileName, string containerName);
    }

    public class FileSystemStorageService : IStorageService
    {
        private readonly string _basePath;
        private readonly ILogger<FileSystemStorageService> _logger;

        public FileSystemStorageService(IConfiguration configuration, ILogger<FileSystemStorageService> logger)
        {
            _basePath = configuration["Storage:FilePath"] ?? Path.Combine(Directory.GetCurrentDirectory(), "Storage");
            _logger = logger;
            
            // Ensure storage directory exists
            Directory.CreateDirectory(_basePath);
        }

        public async Task<string> UploadFileAsync(IFormFile file, string containerName)
        {
            if (file == null)
            {
                throw new ArgumentNullException(nameof(file));
            }

            var containerPath = Path.Combine(_basePath, containerName);
            Directory.CreateDirectory(containerPath);

            var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";
            var filePath = Path.Combine(containerPath, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            _logger.LogInformation("File {FileName} uploaded to {ContainerName}", fileName, containerName);
            return fileName;
        }

        public async Task<string> UploadFileAsync(byte[] fileData, string fileName, string containerName)
        {
            if (fileData == null)
            {
                throw new ArgumentNullException(nameof(fileData));
            }

            var containerPath = Path.Combine(_basePath, containerName);
            Directory.CreateDirectory(containerPath);

            var uniqueFileName = $"{Guid.NewGuid()}_{fileName}";
            var filePath = Path.Combine(containerPath, uniqueFileName);

            await File.WriteAllBytesAsync(filePath, fileData);

            _logger.LogInformation("File {FileName} uploaded to {ContainerName}", uniqueFileName, containerName);
            return uniqueFileName;
        }

        public async Task<byte[]> DownloadFileAsync(string fileName, string containerName)
        {
            var filePath = Path.Combine(_basePath, containerName, fileName);
            
            if (!File.Exists(filePath))
            {
                _logger.LogWarning("File {FileName} not found in {ContainerName}", fileName, containerName);
                throw new FileNotFoundException($"File {fileName} not found in {containerName}");
            }

            return await File.ReadAllBytesAsync(filePath);
        }

        public Task DeleteFileAsync(string fileName, string containerName)
        {
            var filePath = Path.Combine(_basePath, containerName, fileName);
            
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
                _logger.LogInformation("File {FileName} deleted from {ContainerName}", fileName, containerName);
            }
            else
            {
                _logger.LogWarning("File {FileName} not found in {ContainerName} for deletion", fileName, containerName);
            }

            return Task.CompletedTask;
        }

        public string GetFileUrl(string fileName, string containerName)
        {
            // In a real implementation, this would return a URL to access the file
            // For a file system implementation, we'll return a local path that can be used in API endpoints
            return $"/api/files/{containerName}/{fileName}";
        }
    }
}

