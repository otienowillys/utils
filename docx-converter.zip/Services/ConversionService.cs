using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace DocxConverter.Services
{
    public interface IConversionService
    {
        Task<byte[]> ConvertDocumentAsync(byte[] docxBytes, Dictionary<string, string> replacements);
        Task<Dictionary<string, string>> IdentifySectionsAsync(byte[] docxBytes);
        Task<byte[]> ApplyTemplateAsync(byte[] templateBytes, Dictionary<string, string> sectionContents);
    }

    public class ConversionService : IConversionService
    {
        private readonly IOpenXmlService _openXmlService;
        private readonly ILexicalParserService _lexicalParserService;
        private readonly ILogger<ConversionService> _logger;

        public ConversionService(
            IOpenXmlService openXmlService,
            ILexicalParserService lexicalParserService,
            ILogger<ConversionService> logger)
        {
            _openXmlService = openXmlService;
            _lexicalParserService = lexicalParserService;
            _logger = logger;
        }

        public async Task<byte[]> ConvertDocumentAsync(byte[] docxBytes, Dictionary<string, string> replacements)
        {
            _logger.LogInformation("Starting document conversion with {Count} replacements", replacements.Count);
            
            try
            {
                // Parse and replace content in the document
                var result = await _openXmlService.ParseAndReplaceContentAsync(docxBytes, replacements);
                
                _logger.LogInformation("Document conversion completed successfully");
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during document conversion");
                throw;
            }
        }

        public async Task<Dictionary<string, string>> IdentifySectionsAsync(byte[] docxBytes)
        {
            _logger.LogInformation("Identifying sections in document");
            
            try
            {
                return await _openXmlService.IdentifySectionsAsync(docxBytes);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error identifying sections in document");
                throw;
            }
        }

        public async Task<byte[]> ApplyTemplateAsync(byte[] templateBytes, Dictionary<string, string> sectionContents)
        {
            _logger.LogInformation("Applying template with {Count} section contents", sectionContents.Count);
            
            try
            {
                // Convert Lexical JSON content to formatted text if needed
                var processedContents = new Dictionary<string, string>();
                
                foreach (var section in sectionContents)
                {
                    // Check if content is in Lexical JSON format
                    if (section.Value.StartsWith("{") && section.Value.Contains("\"root\":"))
                    {
                        // Parse Lexical JSON to formatted text
                        var formattedText = await _lexicalParserService.ConvertLexicalToFormattedTextAsync(section.Value);
                        processedContents[section.Key] = formattedText;
                    }
                    else
                    {
                        // Use content as is
                        processedContents[section.Key] = section.Value;
                    }
                }
                
                // Apply the processed content to the template
                return await _openXmlService.ParseAndReplaceContentAsync(templateBytes, processedContents);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error applying template to document");
                throw;
            }
        }
    }
}

