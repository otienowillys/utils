using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace DocxConverter.Services
{
  public interface IOpenXmlService
  {
      Task<byte[]> ParseAndReplaceContentAsync(byte[] docxBytes, Dictionary<string, string> replacements);
      Task<Dictionary<string, string>> ExtractContentAsync(byte[] docxBytes);
      Task<byte[]> MergeDocumentsAsync(List<byte[]> documents);
      Task<Dictionary<string, string>> IdentifySectionsAsync(byte[] docxBytes);
      Task<List<DocumentHeading>> ExtractHeadingsAsync(byte[] docxBytes); // New method
  }

  // New class to represent document headings
  public class DocumentHeading
  {
      public string Id { get; set; }
      public string Text { get; set; }
      public int Level { get; set; }
      public string Content { get; set; }
      public List<DocumentHeading> Children { get; set; } = new List<DocumentHeading>();
      public string StyleName { get; set; }
  }

  public class OpenXmlService : IOpenXmlService
  {
      private readonly ILogger<OpenXmlService> _logger;

      public OpenXmlService(ILogger<OpenXmlService> logger)
      {
          _logger = logger;
      }

      public async Task<byte[]> ParseAndReplaceContentAsync(byte[] docxBytes, Dictionary<string, string> replacements)
      {
          _logger.LogInformation("Starting document content replacement with {Count} replacements", replacements.Count);
          
          using var memoryStream = new MemoryStream();
          memoryStream.Write(docxBytes, 0, docxBytes.Length);
          memoryStream.Position = 0;

          using (WordprocessingDocument doc = WordprocessingDocument.Open(memoryStream, true))
          {
              var body = doc.MainDocumentPart.Document.Body;

              // Process all paragraphs
              foreach (var paragraph in body.Descendants<Paragraph>())
              {
                  ProcessParagraphForReplacements(paragraph, replacements);
              }

              // Process all tables
              foreach (var table in body.Descendants<Table>())
              {
                  foreach (var cell in table.Descendants<TableCell>())
                  {
                      foreach (var paragraph in cell.Descendants<Paragraph>())
                      {
                          ProcessParagraphForReplacements(paragraph, replacements);
                      }
                  }
              }

              // Process headers and footers
              foreach (var headerPart in doc.MainDocumentPart.HeaderParts)
              {
                  foreach (var paragraph in headerPart.Header.Descendants<Paragraph>())
                  {
                      ProcessParagraphForReplacements(paragraph, replacements);
                  }
              }

              foreach (var footerPart in doc.MainDocumentPart.FooterParts)
              {
                  foreach (var paragraph in footerPart.Footer.Descendants<Paragraph>())
                  {
                      ProcessParagraphForReplacements(paragraph, replacements);
                  }
              }

              doc.MainDocumentPart.Document.Save();
          }

          memoryStream.Position = 0;
          return memoryStream.ToArray();
      }

      private void ProcessParagraphForReplacements(Paragraph paragraph, Dictionary<string, string> replacements)
      {
          string paragraphText = paragraph.InnerText;
          bool paragraphModified = false;

          foreach (var replacement in replacements)
          {
              string placeholder = $"{{{{{replacement.Key}}}}}";
              
              if (paragraphText.Contains(placeholder))
              {
                  paragraphModified = true;
                  
                  // Create a new paragraph with the same properties
                  var newParagraph = new Paragraph(paragraph.ParagraphProperties?.CloneNode(true));
                  
                  // Process each run in the paragraph
                  foreach (var run in paragraph.Elements<Run>())
                  {
                      var runText = run.InnerText;
                      
                      if (runText.Contains(placeholder))
                      {
                          // Replace the placeholder in this run
                          var newRunText = runText.Replace(placeholder, replacement.Value);
                          var newRun = new Run(run.RunProperties?.CloneNode(true));
                          newRun.AppendChild(new Text(newRunText));
                          newParagraph.AppendChild(newRun);
                      }
                      else
                      {
                          // Keep the run as is
                          newParagraph.AppendChild(run.CloneNode(true));
                      }
                  }
                  
                  // Replace the old paragraph with the new one
                  paragraph.Parent.ReplaceChild(newParagraph, paragraph);
                  break; // We've modified this paragraph, move to the next one
              }
          }
      }

      public async Task<Dictionary<string, string>> ExtractContentAsync(byte[] docxBytes)
      {
          _logger.LogInformation("Extracting content from document");
          var content = new Dictionary<string, string>();
          
          using var memoryStream = new MemoryStream();
          memoryStream.Write(docxBytes, 0, docxBytes.Length);
          memoryStream.Position = 0;

          using (WordprocessingDocument doc = WordprocessingDocument.Open(memoryStream, false))
          {
              var body = doc.MainDocumentPart.Document.Body;
              
              // Extract content from sections marked with bookmarks or content controls
              foreach (var bookmarkStart in body.Descendants<BookmarkStart>())
              {
                  string bookmarkName = bookmarkStart.Name.Value;
                  string bookmarkText = ExtractTextBetweenBookmarks(bookmarkStart);
                  
                  if (!string.IsNullOrEmpty(bookmarkText))
                  {
                      content[bookmarkName] = bookmarkText;
                  }
              }
              
              // Extract content from content controls
              foreach (var sdtElement in body.Descendants<SdtElement>())
              {
                  var tag = sdtElement.SdtProperties?.GetFirstChild<Tag>();
                  if (tag != null && !string.IsNullOrEmpty(tag.Val.Value))
                  {
                      string tagName = tag.Val.Value;
                      string tagText = sdtElement.InnerText;
                      
                      if (!string.IsNullOrEmpty(tagText))
                      {
                          content[tagName] = tagText;
                      }
                  }
              }
          }

          return content;
      }

      private string ExtractTextBetweenBookmarks(BookmarkStart bookmarkStart)
      {
          var bookmarkEnd = bookmarkStart.Parent.Descendants<BookmarkEnd>()
              .FirstOrDefault(b => b.Id.Value == bookmarkStart.Id.Value);
              
          if (bookmarkEnd == null)
          {
              return string.Empty;
          }
          
          var sb = new StringBuilder();
          var element = bookmarkStart.NextSibling();
          
          while (element != null && element != bookmarkEnd)
          {
              if (element is Text text)
              {
                  sb.Append(text.Text);
              }
              else if (element is Run run)
              {
                  sb.Append(run.InnerText);
              }
              
              element = element.NextSibling();
          }
          
          return sb.ToString();
      }

      public async Task<byte[]> MergeDocumentsAsync(List<byte[]> documents)
      {
          if (documents == null || documents.Count == 0)
          {
              throw new ArgumentException("No documents provided for merging");
          }
          
          if (documents.Count == 1)
          {
              return documents[0];
          }
          
          _logger.LogInformation("Merging {Count} documents", documents.Count);
          
          // Use the first document as the base
          using var resultStream = new MemoryStream();
          resultStream.Write(documents[0], 0, documents[0].Length);
          resultStream.Position = 0;
          
          using (WordprocessingDocument mainDoc = WordprocessingDocument.Open(resultStream, true))
          {
              var mainBody = mainDoc.MainDocumentPart.Document.Body;
              
              // Process each additional document
              for (int i = 1; i < documents.Count; i++)
              {
                  using var sourceStream = new MemoryStream();
                  sourceStream.Write(documents[i], 0, documents[i].Length);
                  sourceStream.Position = 0;
                  
                  using (WordprocessingDocument sourceDoc = WordprocessingDocument.Open(sourceStream, false))
                  {
                      var sourceBody = sourceDoc.MainDocumentPart.Document.Body;
                      
                      // Add a section break
                      var sectionBreak = new Paragraph(
                          new Run(
                              new Break { Type = BreakValues.Page }
                          )
                      );
                      mainBody.AppendChild(sectionBreak.CloneNode(true));
                      
                      // Copy all elements from the source document
                      foreach (var element in sourceBody.Elements())
                      {
                          mainBody.AppendChild(element.CloneNode(true));
                      }
                  }
              }
              
              mainDoc.MainDocumentPart.Document.Save();
          }
          
          resultStream.Position = 0;
          return resultStream.ToArray();
      }

      public async Task<Dictionary<string, string>> IdentifySectionsAsync(byte[] docxBytes)
      {
          _logger.LogInformation("Identifying sections in document");
          var sections = new Dictionary<string, string>();
          
          using var memoryStream = new MemoryStream();
          memoryStream.Write(docxBytes, 0, docxBytes.Length);
          memoryStream.Position = 0;

          using (WordprocessingDocument doc = WordprocessingDocument.Open(memoryStream, false))
          {
              var body = doc.MainDocumentPart.Document.Body;
              
              // Identify sections by headings
              int sectionCount = 0;
              foreach (var paragraph in body.Elements<Paragraph>())
              {
                  // Check if paragraph has heading style
                  var styleId = paragraph.ParagraphProperties?.ParagraphStyleId?.Val;
                  if (styleId != null && (styleId.Value.StartsWith("Heading") || styleId.Value.StartsWith("Title")))
                  {
                      sectionCount++;
                      string sectionName = $"Section{sectionCount}";
                      string headingText = paragraph.InnerText;
                      
                      sections[sectionName] = headingText;
                  }
              }
              
              // Identify sections by bookmarks
              foreach (var bookmarkStart in body.Descendants<BookmarkStart>())
              {
                  string bookmarkName = bookmarkStart.Name.Value;
                  sections[bookmarkName] = bookmarkName;
              }
              
              // Identify sections by content controls
              foreach (var sdtElement in body.Descendants<SdtElement>())
              {
                  var tag = sdtElement.SdtProperties?.GetFirstChild<Tag>();
                  if (tag != null && !string.IsNullOrEmpty(tag.Val.Value))
                  {
                      string tagName = tag.Val.Value;
                      sections[tagName] = tagName;
                  }
              }
          }

          return sections;
      }

      // New method to extract headings from DOCX
      public async Task<List<DocumentHeading>> ExtractHeadingsAsync(byte[] docxBytes)
      {
          _logger.LogInformation("Extracting headings from document");
          var headings = new List<DocumentHeading>();
          var headingStack = new Stack<DocumentHeading>();
          
          using var memoryStream = new MemoryStream();
          memoryStream.Write(docxBytes, 0, docxBytes.Length);
          memoryStream.Position = 0;

          using (WordprocessingDocument doc = WordprocessingDocument.Open(memoryStream, false))
          {
              var body = doc.MainDocumentPart.Document.Body;
              var styles = doc.MainDocumentPart.StyleDefinitionsPart?.Styles;
              
              // Get all paragraphs
              var paragraphs = body.Elements<Paragraph>().ToList();
              
              // Process each paragraph
              for (int i = 0; i < paragraphs.Count; i++)
              {
                  var paragraph = paragraphs[i];
                  var styleId = paragraph.ParagraphProperties?.ParagraphStyleId?.Val;
                  
                  // Check if this is a heading
                  if (styleId != null)
                  {
                      string styleName = styleId.Value;
                      int headingLevel = 0;
                      
                      // Check if it's a heading style
                      if (styleName.StartsWith("Heading"))
                      {
                          // Extract heading level (Heading1, Heading2, etc.)
                          if (int.TryParse(styleName.Substring(7), out int level))
                          {
                              headingLevel = level;
                          }
                      }
                      else if (styleName == "Title")
                      {
                          headingLevel = 1; // Treat Title as H1
                      }
                      
                      // If this is a heading (level 1-3)
                      if (headingLevel >= 1 && headingLevel <= 3)
                      {
                          string headingText = paragraph.InnerText.Trim();
                          
                          // Create a new heading object
                          var heading = new DocumentHeading
                          {
                              Id = Guid.NewGuid().ToString(),
                              Text = headingText,
                              Level = headingLevel,
                              StyleName = styleName,
                              Content = ExtractContentForHeading(paragraphs, i)
                          };
                          
                          // Handle heading hierarchy
                          while (headingStack.Count > 0 && headingStack.Peek().Level >= headingLevel)
                          {
                              headingStack.Pop();
                          }
                          
                          if (headingStack.Count > 0)
                          {
                              // Add as child to parent heading
                              headingStack.Peek().Children.Add(heading);
                          }
                          else
                          {
                              // Add as top-level heading
                              headings.Add(heading);
                          }
                          
                          // Push to stack for potential children
                          headingStack.Push(heading);
                      }
                  }
              }
          }
          
          return headings;
      }
      
      // Helper method to extract content between this heading and the next heading
      private string ExtractContentForHeading(List<Paragraph> paragraphs, int headingIndex)
      {
          var sb = new StringBuilder();
          int currentIndex = headingIndex + 1;
          
          // Get the current heading's level
          var currentHeadingStyle = paragraphs[headingIndex].ParagraphProperties?.ParagraphStyleId?.Val;
          int currentLevel = GetHeadingLevel(currentHeadingStyle?.Value);
          
          // Extract content until we hit another heading of same or higher level
          while (currentIndex < paragraphs.Count)
          {
              var paragraph = paragraphs[currentIndex];
              var styleId = paragraph.ParagraphProperties?.ParagraphStyleId?.Val;
              
              // Check if this is a heading
              if (styleId != null)
              {
                  int level = GetHeadingLevel(styleId.Value);
                  
                  // If we hit a heading of same or higher level, stop
                  if (level > 0 && level <= currentLevel)
                  {
                      break;
                  }
              }
              
              // Add paragraph text to content
              sb.AppendLine(paragraph.InnerText);
              currentIndex++;
          }
          
          return sb.ToString().Trim();
      }
      
      // Helper method to get heading level from style name
      private int GetHeadingLevel(string styleName)
      {
          if (string.IsNullOrEmpty(styleName))
          {
              return 0;
          }
          
          if (styleName == "Title")
          {
              return 1;
          }
          
          if (styleName.StartsWith("Heading") && int.TryParse(styleName.Substring(7), out int level))
          {
              return level;
          }
          
          return 0;
      }
  }
}

