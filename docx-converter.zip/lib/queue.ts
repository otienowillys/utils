import { captureException } from "./error-logging"

// Use in-memory storage instead of Redis
const jobsMap = new Map<string, any>()

// Define job types
export interface ConversionJob {
  templateId: string
  userId: string
  filename: string
  fileUrl: string
  sectionMapping: Record<string, string>
  sectionContents?: Record<string, string>
  resultId: string
}

// Create queues
export const conversionQueue = {
  add: async (name: string, job: ConversionJob, options: any = {}) => {
    const id = job.resultId || options.jobId || Date.now().toString()
    jobsMap.set(id, { id, data: job, status: "waiting", progress: 0 })
    return { id }
  },
  getJob: async (jobId: string) => {
    const job = jobsMap.get(jobId)
    if (!job) return null

    return {
      id: job.id,
      data: job.data,
      progress: job.progress,
      getState: async () => job.status,
    }
  },
}

// Helper function to add a job to the conversion queue
export async function addConversionJob(job: ConversionJob): Promise<string> {
  const result = await conversionQueue.add("convert", job, {
    priority: 1,
    jobId: job.resultId,
  })
  return result.id
}

// Helper function to get job status
export async function getJobStatus(jobId: string) {
  const job = await conversionQueue.getJob(jobId)
  if (!job) {
    return { status: "not-found" }
  }

  const state = await job.getState()
  const progress = job.progress

  return {
    id: job.id,
    status: state,
    progress,
    data: job.data,
  }
}

// Simple job processor that doesn't depend on external workers
export async function processJob(jobId: string): Promise<void> {
  const job = jobsMap.get(jobId)
  if (!job) return

  try {
    job.status = "processing"
    job.progress = 10

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 2000))
    job.progress = 50

    await new Promise((resolve) => setTimeout(resolve, 2000))
    job.progress = 100

    job.status = "completed"
    console.log(`Job ${jobId} completed successfully`)
  } catch (error) {
    job.status = "failed"
    console.error(`Job ${jobId} failed with error:`, error)
    captureException(error as Error, {
      extra: { jobId, jobData: job.data },
    })
  }
}

