// A simplified toast function that doesn't rely on context
// This helps avoid the multiple renderers issue

type ToastOptions = {
  title?: string
  description?: string
  duration?: number
  variant?: "default" | "destructive"
}

export function toast(options: ToastOptions) {
  // Create toast element
  const toastEl = document.createElement("div")
  toastEl.className =
    "fixed top-4 right-4 z-50 max-w-md animate-in fade-in slide-in-from-top-2 bg-white dark:bg-gray-800 p-4 rounded-md shadow-lg border border-gray-200 dark:border-gray-700"

  // Add variant styling
  if (options.variant === "destructive") {
    toastEl.classList.add("bg-red-50", "dark:bg-red-900", "border-red-200", "dark:border-red-800")
  }

  // Create content
  let content = ""
  if (options.title) {
    content += `<div class="font-medium ${options.variant === "destructive" ? "text-red-800 dark:text-red-200" : ""}">${options.title}</div>`
  }
  if (options.description) {
    content += `<div class="text-sm text-gray-500 dark:text-gray-400 ${options.variant === "destructive" ? "text-red-700 dark:text-red-300" : ""}">${options.description}</div>`
  }

  toastEl.innerHTML = content

  // Add close button
  const closeButton = document.createElement("button")
  closeButton.className =
    "absolute top-2 right-2 p-1 rounded-md text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
  closeButton.innerHTML =
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>'
  closeButton.onclick = () => document.body.removeChild(toastEl)
  toastEl.appendChild(closeButton)

  // Add to DOM
  document.body.appendChild(toastEl)

  // Auto-remove after duration
  setTimeout(() => {
    if (document.body.contains(toastEl)) {
      toastEl.classList.add("animate-out", "fade-out", "slide-out-to-right-2")
      setTimeout(() => {
        if (document.body.contains(toastEl)) {
          document.body.removeChild(toastEl)
        }
      }, 300)
    }
  }, options.duration || 5000)

  // Return object with dismiss method
  return {
    dismiss: () => {
      if (document.body.contains(toastEl)) {
        document.body.removeChild(toastEl)
      }
    },
  }
}

