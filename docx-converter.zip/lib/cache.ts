import type { Template } from "./types"
import NodeCache from "node-cache"

// Create in-memory cache
const cache = new NodeCache({
  stdTTL: 300, // 5 minutes default TTL
  checkperiod: 60, // Check for expired keys every 60 seconds
})

// Cache keys
const CACHE_KEYS = {
  TEMPLATE_LIST: "templates:list",
  TEMPLATE: (id: string) => `template:${id}`,
  USER_TEMPLATES: (userId: string) => `user:${userId}:templates`,
}

// Cache TTL in seconds
const TTL = {
  TEMPLATE_LIST: 60 * 5, // 5 minutes
  TEMPLATE: 60 * 60, // 1 hour
  USER_TEMPLATES: 60 * 10, // 10 minutes
}

// Cache templates list
export async function cacheTemplatesList(templates: Template[]): Promise<void> {
  cache.set(CACHE_KEYS.TEMPLATE_LIST, templates, TTL.TEMPLATE_LIST)
}

// Get cached templates list
export async function getCachedTemplatesList(): Promise<Template[] | null> {
  return (cache.get(CACHE_KEYS.TEMPLATE_LIST) as Template[]) || null
}

// Cache a single template
export async function cacheTemplate(template: Template): Promise<void> {
  cache.set(CACHE_KEYS.TEMPLATE(template.id), template, TTL.TEMPLATE)

  // Also update the user's templates cache if applicable
  if (template.userId) {
    const userTemplatesKey = CACHE_KEYS.USER_TEMPLATES(template.userId)
    const cachedTemplates = (cache.get(userTemplatesKey) as Template[]) || []

    const index = cachedTemplates.findIndex((t) => t.id === template.id)

    if (index >= 0) {
      cachedTemplates[index] = template
    } else {
      cachedTemplates.push(template)
    }

    cache.set(userTemplatesKey, cachedTemplates, TTL.USER_TEMPLATES)
  }
}

// Get a cached template
export async function getCachedTemplate(id: string): Promise<Template | null> {
  return (cache.get(CACHE_KEYS.TEMPLATE(id)) as Template) || null
}

// Cache user templates
export async function cacheUserTemplates(userId: string, templates: Template[]): Promise<void> {
  cache.set(CACHE_KEYS.USER_TEMPLATES(userId), templates, TTL.USER_TEMPLATES)
}

// Get cached user templates
export async function getCachedUserTemplates(userId: string): Promise<Template[] | null> {
  return (cache.get(CACHE_KEYS.USER_TEMPLATES(userId)) as Template[]) || null
}

// Invalidate template cache
export async function invalidateTemplateCache(id: string): Promise<void> {
  cache.del(CACHE_KEYS.TEMPLATE(id))
  cache.del(CACHE_KEYS.TEMPLATE_LIST)
}

// Invalidate all caches
export async function invalidateAllCaches(): Promise<void> {
  cache.flushAll()
}

