"use server"

import type { Template, ConversionResult } from "./types"

// This is a mock implementation. In a real application, these functions would
// make actual API calls to your C# backend.

export async function getTemplates(): Promise<Template[]> {
  // In a real implementation, this would fetch from your C# API
  return [
    {
      id: "1",
      name: "Standard Report Template",
      description: "A standard report template with executive summary, findings, and recommendations",
      sections: [
        { id: "s1", name: "Executive Summary", type: "text", order: 0 },
        { id: "s2", name: "Introduction", type: "text", order: 1 },
        { id: "s3", name: "Methodology", type: "text", order: 2 },
        { id: "s4", name: "Findings", type: "text", order: 3 },
        { id: "s5", name: "Recommendations", type: "text", order: 4 },
        { id: "s6", name: "Conclusion", type: "text", order: 5 },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: "2",
      name: "Technical Documentation",
      description: "Template for technical documentation with code examples and diagrams",
      sections: [
        { id: "s1", name: "Overview", type: "text", order: 0 },
        { id: "s2", name: "Requirements", type: "text", order: 1 },
        { id: "s3", name: "Architecture", type: "text", order: 2 },
        { id: "s4", name: "Implementation", type: "text", order: 3 },
        { id: "s5", name: "API Reference", type: "text", order: 4 },
        { id: "s6", name: "Examples", type: "text", order: 5 },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ]
}

export async function getTemplate(id: string): Promise<Template | null> {
  const templates = await getTemplates()
  return templates.find((t) => t.id === id) || null
}

export async function createTemplate(template: Omit<Template, "id" | "createdAt" | "updatedAt">): Promise<Template> {
  // In a real implementation, this would send data to your C# API
  return {
    ...template,
    id: Math.random().toString(36).substring(2, 9),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
}

export async function updateTemplate(id: string, template: Partial<Template>): Promise<Template> {
  // In a real implementation, this would send data to your C# API
  const existingTemplate = await getTemplate(id)
  if (!existingTemplate) {
    throw new Error("Template not found")
  }

  return {
    ...existingTemplate,
    ...template,
    updatedAt: new Date().toISOString(),
  }
}

export async function deleteTemplate(id: string): Promise<void> {
  // In a real implementation, this would send a request to your C# API
  console.log(`Deleting template ${id}`)
}

// Mock implementation of a queue
const conversionJobs: any[] = []

async function addConversionJob(job: any) {
  conversionJobs.push(job)
  console.log("Job added to queue:", job)
}

async function processJob(resultId: string) {
  const jobIndex = conversionJobs.findIndex((job) => job.resultId === resultId)
  if (jobIndex === -1) {
    console.log(`Job with resultId ${resultId} not found.`)
    return
  }

  const job = conversionJobs[jobIndex]
  console.log("Processing job:", job)

  // Simulate processing
  await new Promise((resolve) => setTimeout(resolve, 500))

  console.log(`Job ${resultId} processed successfully.`)
  conversionJobs.splice(jobIndex, 1) // Remove job from queue
}

// Update the API service functions to include the output format parameter

// Update the convertSingleDocument function to create actual PDF content when PDF format is selected
export async function convertSingleDocument(
  templateId: string,
  file: File,
  sectionMapping: Record<string, string>,
  outputFormat = "docx",
): Promise<ConversionResult> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 2000))

  // Create a result ID
  const resultId = Math.random().toString(36).substring(2, 9)

  // In a real implementation, this would send the file to your C# backend for conversion

  let convertedFile: File
  let downloadUrl: string

  if (outputFormat === "pdf") {
    // For PDF, create a simple PDF with content (in a real app, this would be done server-side)
    try {
      // Read the file as ArrayBuffer
      const arrayBuffer = await file.arrayBuffer()

      // In a real app, we would convert the DOCX to PDF here
      // For demo purposes, we'll create a simple PDF with some text
      const pdfBlob = await createSimplePdf(file.name, templateId)

      // Create a new File object from the PDF blob
      convertedFile = new File([pdfBlob], file.name.replace(/\.[^/.]+$/, "") + ".pdf", {
        type: "application/pdf",
      })

      // Create a URL for the converted file
      downloadUrl = URL.createObjectURL(convertedFile)
    } catch (error) {
      console.error("Error creating PDF:", error)

      // Fallback to original file if PDF creation fails
      convertedFile = file
      downloadUrl = URL.createObjectURL(file)
    }
  } else if (outputFormat === "html") {
    // For HTML, create a simple HTML file with content
    try {
      // In a real app, we would convert the DOCX to HTML here
      // For demo purposes, we'll create a simple HTML with some text
      const htmlContent = await createSimpleHtml(file.name, templateId)

      // Create a new File object from the HTML content
      convertedFile = new File([htmlContent], file.name.replace(/\.[^/.]+$/, "") + ".html", {
        type: "text/html",
      })

      // Create a URL for the converted file
      downloadUrl = URL.createObjectURL(convertedFile)
    } catch (error) {
      console.error("Error creating HTML:", error)

      // Fallback to original file if HTML creation fails
      convertedFile = file
      downloadUrl = URL.createObjectURL(file)
    }
  } else {
    // For DOCX, just use the original file
    convertedFile = file
    downloadUrl = URL.createObjectURL(file)
  }

  // Return the conversion result
  return {
    id: resultId,
    originalFilename: file.name,
    convertedFilename: convertedFile.name,
    format: outputFormat,
    size: convertedFile.size,
    downloadUrl: downloadUrl,
    status: "completed",
    createdAt: new Date().toISOString(),
  }
}

// Add helper functions to create simple PDF and HTML files
async function createSimplePdf(fileName: string, templateId: string): Promise<Blob> {
  // In a real app, this would be done server-side with a proper PDF library
  // For demo purposes, we'll create a simple PDF using a data URL

  // This is a minimal valid PDF
  const pdfContent = `%PDF-1.4
1 0 obj
<</Type /Catalog /Pages 2 0 R>>
endobj
2 0 obj
<</Type /Pages /Kids [3 0 R] /Count 1>>
endobj
3 0 obj
<</Type /Page /Parent 2 0 R /Resources 4 0 R /MediaBox [0 0 612 792] /Contents 6 0 R>>
endobj
4 0 obj
<</Font <</F1 5 0 R>>>>
endobj
5 0 obj
<</Type /Font /Subtype /Type1 /BaseFont /Helvetica>>
endobj
6 0 obj
<</Length 90>>
stream
BT
/F1 24 Tf
100 700 Td
(Converted Document) Tj
/F1 14 Tf
0 -30 Td
(Original file: ${fileName}) Tj
0 -20 Td
(Template ID: ${templateId}) Tj
0 -20 Td
(Conversion Date: ${new Date().toLocaleString()}) Tj
ET
endstream
endobj
xref
0 7
0000000000 65535 f
0000000009 00000 n
0000000056 00000 n
0000000111 00000 n
0000000212 00000 n
0000000250 00000 n
0000000317 00000 n
trailer
<</Size 7 /Root 1 0 R>>
startxref
406
%%EOF`

  return new Blob([pdfContent], { type: "application/pdf" })
}

async function createSimpleHtml(fileName: string, templateId: string): Promise<string> {
  // Create a simple HTML document
  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Converted Document</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }
    h1 {
      color: #0070f3;
      border-bottom: 1px solid #eaeaea;
      padding-bottom: 10px;
    }
    .info {
      background-color: #f5f5f5;
      padding: 15px;
      border-radius: 5px;
      margin-bottom: 20px;
    }
    .content {
      padding: 20px;
      border: 1px solid #eaeaea;
      border-radius: 5px;
    }
  </style>
</head>
<body>
  <h1>Converted Document</h1>
  
  <div class="info">
    <p><strong>Original file:</strong> ${fileName}</p>
    <p><strong>Template ID:</strong> ${templateId}</p>
    <p><strong>Conversion Date:</strong> ${new Date().toLocaleString()}</p>
  </div>
  
  <div class="content">
    <h2>Document Content</h2>
    <p>This is a sample converted HTML document. In a real application, this would contain the actual content from your DOCX file, properly formatted as HTML.</p>
    <p>The conversion would preserve:</p>
    <ul>
      <li>Text formatting (bold, italic, underline)</li>
      <li>Headings and structure</li>
      <li>Lists (ordered and unordered)</li>
      <li>Tables</li>
      <li>Images</li>
      <li>And other document elements</li>
    </ul>
  </div>
</body>
</html>`

  return htmlContent
}

// Update the batch conversion function to use the same approach
export async function convertBatchDocuments(
  templateId: string,
  files: File[],
  sectionMapping: Record<string, string>,
  outputFormat = "docx",
): Promise<ConversionResult[]> {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 3000))

  // Process each file
  const results = await Promise.all(
    files.map(async (file) => {
      // Create a result ID
      const resultId = Math.random().toString(36).substring(2, 9)

      let convertedFile: File
      let downloadUrl: string

      if (outputFormat === "pdf") {
        try {
          const pdfBlob = await createSimplePdf(file.name, templateId)
          convertedFile = new File([pdfBlob], file.name.replace(/\.[^/.]+$/, "") + ".pdf", {
            type: "application/pdf",
          })
          downloadUrl = URL.createObjectURL(convertedFile)
        } catch (error) {
          console.error("Error creating PDF:", error)
          convertedFile = file
          downloadUrl = URL.createObjectURL(file)
        }
      } else if (outputFormat === "html") {
        try {
          const htmlContent = await createSimpleHtml(file.name, templateId)
          convertedFile = new File([htmlContent], file.name.replace(/\.[^/.]+$/, "") + ".html", {
            type: "text/html",
          })
          downloadUrl = URL.createObjectURL(convertedFile)
        } catch (error) {
          console.error("Error creating HTML:", error)
          convertedFile = file
          downloadUrl = URL.createObjectURL(file)
        }
      } else {
        convertedFile = file
        downloadUrl = URL.createObjectURL(file)
      }

      return {
        id: resultId,
        originalFilename: file.name,
        convertedFilename: convertedFile.name,
        format: outputFormat,
        size: convertedFile.size,
        downloadUrl: downloadUrl,
        status: "completed",
        createdAt: new Date().toISOString(),
      }
    }),
  )

  return results
}

export async function getUserConversions(userId: string): Promise<ConversionResult[]> {
  // In a real implementation, this would fetch from your C# API
  return [
    {
      id: Math.random().toString(36).substring(2, 9),
      filename: "report.docx",
      status: "success",
      downloadUrl: "/api/download/456",
      createdAt: new Date().toISOString(),
    },
    {
      id: Math.random().toString(36).substring(2, 9),
      filename: "presentation.docx",
      status: "error",
      message: "Failed to map all sections",
      createdAt: new Date(Date.now() - 86400000).toISOString(), // Yesterday
    },
    {
      id: Math.random().toString(36).substring(2, 9),
      filename: "document.docx",
      status: "pending",
      createdAt: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
    },
  ]
}

