import { captureException } from "./error-logging"

// Define job types
export interface ConversionJob {
  templateId: string
  userId: string
  filename: string
  fileUrl: string
  sectionMapping: Record<string, string>
  sectionContents?: Record<string, string>
  resultId: string
}

// In-memory job storage
interface JobStatus {
  id: string
  status: "pending" | "processing" | "completed" | "failed"
  progress: number
  result?: any
  error?: string
  data: ConversionJob
  createdAt: Date
  updatedAt: Date
}

const jobs: Record<string, JobStatus> = {}

// Add a job to the queue
export async function addConversionJob(job: ConversionJob): Promise<string> {
  const jobId = job.resultId || Math.random().toString(36).substring(2, 15)

  jobs[jobId] = {
    id: jobId,
    status: "pending",
    progress: 0,
    data: job,
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  // Process the job asynchronously
  setTimeout(() => processJob(jobId), 100)

  return jobId
}

// Get job status
export async function getJobStatus(jobId: string) {
  if (!jobs[jobId]) {
    return { status: "not-found" }
  }

  return {
    id: jobId,
    status: jobs[jobId].status,
    progress: jobs[jobId].progress,
    result: jobs[jobId].result,
    error: jobs[jobId].error,
    data: jobs[jobId].data,
  }
}

// Process a job
async function processJob(jobId: string) {
  if (!jobs[jobId]) return

  const job = jobs[jobId]
  job.status = "processing"
  job.updatedAt = new Date()

  try {
    // Update progress
    updateJobProgress(jobId, 10)

    // Simulate processing time and steps
    await simulateProcessingSteps(jobId)

    // Mark as completed
    jobs[jobId].status = "completed"
    jobs[jobId].progress = 100
    jobs[jobId].result = {
      downloadUrl: `/api/download/${jobId}`,
      filename: job.data.filename.replace(".docx", "_converted.docx"),
    }
    jobs[jobId].updatedAt = new Date()

    console.log(`Job ${jobId} completed successfully`)

    // Clean up old jobs after 24 hours
    setTimeout(
      () => {
        delete jobs[jobId]
      },
      24 * 60 * 60 * 1000,
    )
  } catch (error) {
    jobs[jobId].status = "failed"
    jobs[jobId].error = (error as Error).message
    jobs[jobId].updatedAt = new Date()

    console.error(`Job ${jobId} failed with error: ${(error as Error).message}`)
    captureException(error as Error, {
      extra: { jobId, jobData: job.data },
    })
  }
}

// Update job progress
function updateJobProgress(jobId: string, progress: number) {
  if (jobs[jobId]) {
    jobs[jobId].progress = progress
    jobs[jobId].updatedAt = new Date()
  }
}

// Simulate processing steps with delays
async function simulateProcessingSteps(jobId: string) {
  // Step 1: Download file
  await delay(500)
  updateJobProgress(jobId, 20)

  // Step 2: Parse document
  await delay(1000)
  updateJobProgress(jobId, 40)

  // Step 3: Apply template
  await delay(1500)
  updateJobProgress(jobId, 60)

  // Step 4: Generate new document
  await delay(1000)
  updateJobProgress(jobId, 80)

  // Step 5: Upload result
  await delay(500)
  updateJobProgress(jobId, 95)
}

// Helper function to create delays
function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

