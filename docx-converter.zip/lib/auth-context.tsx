"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

type AuthContextType = {
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // Check authentication on mount
    const authStatus = localStorage.getItem("isAuthenticated") === "true"
    setIsAuthenticated(authStatus)

    // Listen for changes
    const handleStorageChange = () => {
      const authStatus = localStorage.getItem("isAuthenticated") === "true"
      setIsAuthenticated(authStatus)
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("auth-change", handleStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("auth-change", handleStorageChange)
    }
  }, [])

  const login = async (email: string, password: string) => {
    // Simple validation
    if (email === "admin@example.com" && password === "password123") {
      localStorage.setItem("isAuthenticated", "true")
      setIsAuthenticated(true)

      // Notify other components
      window.dispatchEvent(new Event("auth-change"))
      return true
    }
    return false
  }

  const logout = () => {
    localStorage.removeItem("isAuthenticated")
    setIsAuthenticated(false)

    // Notify other components
    window.dispatchEvent(new Event("auth-change"))
  }

  return <AuthContext.Provider value={{ isAuthenticated, login, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

