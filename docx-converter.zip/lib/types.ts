import type React from "react"
export interface Template {
  id: string
  name: string
  description?: string
  sections: Section[]
  createdAt: string
  updatedAt: string
}

export interface Section {
  id: string
  name: string
  type: string
  order: number
}

export interface ProcessingMode {
  id: "single" | "batch"
  label: string
  description: string
  icon: React.ReactNode
}

export interface ConversionResult {
  id: string
  originalFilename: string
  convertedFilename: string
  format: string // Add this line
  size: number
  downloadUrl: string
  status: "pending" | "processing" | "completed" | "failed"
  createdAt: string
  error?: string
}

export interface PredefinedMapping {
  id: string
  name: string
  description: string
  mapping: Record<string, string>
  isCustom?: boolean
}

