"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { Template, ConversionResult } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { SectionMapper } from "./section-mapper"
import { convertSingleDocument, convertBatchDocuments } from "@/lib/api-service"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { AnimatedFileUploader } from "./animated-file-uploader"
import { AnimatedStepIndicator } from "./animated-step-indicator"
import { ConversionResults } from "./conversion-results"
import { TemplateSelector } from "./template-selector"

interface ConversionFormProps {
  templates: Template[]
  mode: "single" | "batch"
}

export default function ConversionForm({ templates, mode }: ConversionFormProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("")
  const [files, setFiles] = useState<File[]>([])
  const [sectionMapping, setSectionMapping] = useState<Record<string, string>>({})
  const [isProcessing, setIsProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<ConversionResult[]>([])
  const { toast } = useToast()

  // Add a new state variable for output format
  const [outputFormat, setOutputFormat] = useState<string>("docx")

  // Set isMounted to true after component mounts
  useEffect(() => {
    setIsMounted(true)
  }, [])

  const steps = [
    { number: 1, label: "Upload" },
    { number: 2, label: "Select Template" },
    { number: 3, label: "Map Sections" },
    { number: 4, label: "Convert" },
  ]

  const handleTemplateChange = (value: string) => {
    setSelectedTemplateId(value)
    // Reset section mapping when template changes
    setSectionMapping({})
  }

  const handleFilesChange = (newFiles: File[]) => {
    setFiles(newFiles)
  }

  const handleSectionMappingChange = (mapping: Record<string, string>) => {
    setSectionMapping(mapping)
  }

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  // Modify the handleSubmit function to include the output format
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedTemplateId) {
      toast({
        title: "Error",
        description: "Please select a template",
        variant: "destructive",
      })
      return
    }

    if (files.length === 0) {
      toast({
        title: "Error",
        description: "Please upload at least one file",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)
    setProgress(0)
    setResults([])

    try {
      if (mode === "single") {
        // Process single document
        const result = await convertSingleDocument(selectedTemplateId, files[0], sectionMapping, outputFormat)
        setResults([result])
      } else {
        // Process batch documents
        // Simulate progress for UX
        const progressInterval = setInterval(() => {
          setProgress((prev) => {
            const newProgress = prev + 5
            if (newProgress >= 95) {
              clearInterval(progressInterval)
              return 95
            }
            return newProgress
          })
        }, 200)

        const results = await convertBatchDocuments(selectedTemplateId, files, sectionMapping, outputFormat)

        clearInterval(progressInterval)
        setProgress(100)
        setResults(results)
      }

      toast({
        title: "Conversion complete",
        description: `Successfully converted ${files.length} document(s) to ${outputFormat.toUpperCase()}`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to convert documents",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const selectedTemplate = templates.find((t) => t.id === selectedTemplateId)
  const isFormValid = selectedTemplateId && files.length > 0

  // For server-side rendering, return a minimal placeholder
  // This avoids the hydration mismatch while still providing content for SSR
  if (!isMounted) {
    return <div className="max-w-4xl mx-auto">Loading conversion form...</div>
  }

  // Render different content based on current step
  let stepContent

  if (currentStep === 1) {
    stepContent = (
      <div>
        <h2 className="text-2xl font-semibold mb-2">Step 1: Upload</h2>
        <p className="text-muted-foreground mb-6">Upload the document you want to convert.</p>

        <AnimatedFileUploader
          multiple={mode === "batch"}
          onChange={handleFilesChange}
          accept=".docx"
          maxFiles={mode === "single" ? 1 : undefined}
        />

        <div className="flex justify-end mt-6">
          <Button type="button" onClick={handleNext} disabled={files.length === 0}>
            Next
          </Button>
        </div>
      </div>
    )
  } else if (currentStep === 2) {
    stepContent = (
      <div>
        <h2 className="text-2xl font-semibold mb-2">Step 2: Select Template</h2>
        <p className="text-muted-foreground mb-6">Choose a template to use for converting your document.</p>

        <TemplateSelector
          templates={templates}
          selectedTemplateId={selectedTemplateId}
          onTemplateChange={handleTemplateChange}
        />

        <div className="flex justify-between mt-6">
          <Button type="button" variant="outline" onClick={handlePrevious}>
            Previous
          </Button>
          <Button type="button" onClick={handleNext} disabled={!selectedTemplateId}>
            Next
          </Button>
        </div>
      </div>
    )
  } else if (currentStep === 3 && selectedTemplate) {
    stepContent = (
      <div>
        <h2 className="text-2xl font-semibold mb-2">Step 3: Map Sections</h2>
        <p className="text-muted-foreground mb-6">Map sections from your document to the template sections.</p>

        <div className="bg-white dark:bg-zinc-900 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
          <SectionMapper templateSections={selectedTemplate.sections} onChange={handleSectionMappingChange} />
        </div>

        <div className="flex justify-between mt-6">
          <Button type="button" variant="outline" onClick={handlePrevious}>
            Previous
          </Button>
          <Button type="button" onClick={handleNext}>
            Next
          </Button>
        </div>
      </div>
    )
  } else if (currentStep === 4) {
    stepContent = (
      <div>
        <h2 className="text-2xl font-semibold mb-2">Step 4: Convert</h2>
        <p className="text-muted-foreground mb-6">Review your selections and convert the document.</p>

        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-md">
                <h3 className="font-medium mb-2">Selected Template</h3>
                <p>{selectedTemplate?.name}</p>
              </div>

              <div className="p-4 bg-muted rounded-md">
                <h3 className="font-medium mb-2">Selected File{files.length > 1 ? "s" : ""}</h3>
                <ul className="space-y-1">
                  {files.map((file, index) => (
                    <li key={index}>
                      {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-4 bg-muted rounded-md mb-4">
                <h3 className="font-medium mb-2">Output Format</h3>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    type="button"
                    variant={outputFormat === "docx" ? "default" : "outline"}
                    onClick={() => setOutputFormat("docx")}
                    className="justify-start"
                  >
                    <span className="mr-2">📄</span> DOCX
                  </Button>
                  <Button
                    type="button"
                    variant={outputFormat === "pdf" ? "default" : "outline"}
                    onClick={() => setOutputFormat("pdf")}
                    className="justify-start"
                  >
                    <span className="mr-2">📑</span> PDF
                  </Button>
                  <Button
                    type="button"
                    variant={outputFormat === "html" ? "default" : "outline"}
                    onClick={() => setOutputFormat("html")}
                    className="justify-start"
                  >
                    <span className="mr-2">🌐</span> HTML
                  </Button>
                </div>
              </div>

              <Button type="submit" disabled={!isFormValid || isProcessing} className="w-full">
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>Convert {mode === "batch" ? "Documents" : "Document"}</>
                )}
              </Button>

              {isProcessing && (
                <div>
                  <Progress value={progress} className="h-2" />
                  <p className="text-sm text-muted-foreground mt-2 text-center">{progress}% complete</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {!isProcessing && (
          <div className="flex justify-between">
            <Button type="button" variant="outline" onClick={handlePrevious}>
              Previous
            </Button>
          </div>
        )}
      </div>
    )
  } else {
    // Default content if no step matches (shouldn't happen)
    stepContent = <div>Please select a step</div>
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
      <AnimatedStepIndicator steps={steps} currentStep={currentStep} />
      {stepContent}
      {results.length > 0 && <ConversionResults results={results} isProcessing={isProcessing} progress={progress} />}
    </form>
  )
}

