"use client"

import { Button } from "@/components/ui/button"
import { Moon, Sun } from "lucide-react"
import { useState, useEffect } from "react"

export function ThemeToggle() {
  // Use state to track the theme, but initialize it to a default value to avoid hydration mismatch
  const [theme, setTheme] = useState<string>("light")
  const [isMounted, setIsMounted] = useState(false)

  // Initialize theme state after mount
  useEffect(() => {
    setIsMounted(true)

    // Check if dark class is present
    const isDark = document.documentElement.classList.contains("dark")
    setTheme(isDark ? "dark" : "light")

    // Set up a mutation observer to track theme changes from other sources
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "attributes" && mutation.attributeName === "class") {
          const isDarkNow = document.documentElement.classList.contains("dark")
          setTheme(isDarkNow ? "dark" : "light")
        }
      })
    })

    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    })

    return () => observer.disconnect()
  }, [])

  // Handle theme toggle
  const toggleTheme = () => {
    if (!isMounted) return

    const newTheme = theme === "dark" ? "light" : "dark"

    // Update DOM
    if (newTheme === "dark") {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }

    // Update localStorage
    try {
      localStorage.setItem("theme", newTheme)
    } catch (e) {
      console.error("Failed to save theme preference:", e)
    }

    // Update state
    setTheme(newTheme)
  }

  // For server-side rendering, return a button with default state
  if (!isMounted) {
    return (
      <Button variant="ghost" size="icon" className="h-9 w-9" aria-label="Toggle theme">
        <Moon className="h-5 w-5" />
        <span className="sr-only">Toggle theme</span>
      </Button>
    )
  }

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggleTheme}
      className="h-9 w-9"
      title={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}
    >
      {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}

