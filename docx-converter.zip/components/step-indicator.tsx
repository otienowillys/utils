"use client"

import { cn } from "@/lib/utils"

interface Step {
  number: number
  label: string
}

interface StepIndicatorProps {
  steps: Step[]
  currentStep: number
  className?: string
}

export function StepIndicator({ steps, currentStep, className }: StepIndicatorProps) {
  return (
    <div className={cn("relative mb-8", className)}>
      {/* Horizontal line connecting steps */}
      <div className="absolute top-4 left-0 right-0 h-0.5 bg-gray-700" />

      {/* Steps */}
      <div className="relative flex justify-between">
        {steps.map((step) => {
          const isActive = step.number === currentStep
          const isCompleted = step.number < currentStep

          return (
            <div key={step.number} className="flex flex-col items-center">
              {/* Step circle */}
              <div
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full border-2 z-10",
                  isActive
                    ? "border-blue-500 bg-blue-500 text-white"
                    : isCompleted
                      ? "border-blue-500 bg-blue-500 text-white"
                      : "border-gray-700 bg-black text-gray-400",
                )}
              >
                {step.number}
              </div>

              {/* Step label */}
              <span
                className={cn(
                  "mt-2 text-sm font-medium",
                  isActive ? "text-blue-500" : isCompleted ? "text-blue-500" : "text-gray-400",
                )}
              >
                {step.label}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

