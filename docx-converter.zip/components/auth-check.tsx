"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export function AuthCheck({
  children,
  redirectTo = "/login",
  requireAuth = true,
}: {
  children: React.ReactNode
  redirectTo?: string
  requireAuth?: boolean
}) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // Check authentication status
    const authStatus = localStorage.getItem("isAuthenticated") === "true"
    setIsAuthenticated(authStatus)
    setIsLoading(false)

    // Redirect if needed
    if (requireAuth && !authStatus) {
      router.push(redirectTo)
    } else if (!requireAuth && authStatus) {
      router.push("/dashboard")
    }
  }, [router, redirectTo, requireAuth])

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    )
  }

  // If authentication check passes, render children
  if ((requireAuth && isAuthenticated) || (!requireAuth && !isAuthenticated)) {
    return <>{children}</>
  }

  // Otherwise render nothing (redirect will happen)
  return null
}

