"use client"

import { useState, useEffect } from "react"
import type { Section } from "@/lib/types"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PredefinedMappings } from "./predefined-mappings"

interface SectionMapperProps {
  templateSections: Section[]
  onChange: (mapping: Record<string, string>) => void
}

export function SectionMapper({ templateSections, onChange }: SectionMapperProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [mapping, setMapping] = useState<Record<string, string>>({})
  const [availableSections] = useState<string[]>([
    "Introduction",
    "Background",
    "Methodology",
    "Results",
    "Discussion",
    "Conclusion",
    "References",
    "Appendix",
    "Executive Summary",
    "Literature Review",
    "Methods",
    "Findings",
    "Recommendations",
    "Abstract",
    "Overview",
    "Requirements",
    "Architecture",
    "Implementation",
    "API Reference",
    "Examples",
    "Company Overview",
    "Market Analysis",
    "Competitive Analysis",
    "Products and Services",
    "Marketing Strategy",
    "Financial Projections",
    "Funding Request",
  ])

  // Ensure hydration safety
  useEffect(() => {
    setIsMounted(true)
  }, [])

  const handleMappingChange = (sectionId: string, value: string) => {
    const newMapping = { ...mapping, [sectionId]: value }
    setMapping(newMapping)
    onChange(newMapping)
  }

  const handleApplyPredefinedMapping = (newMapping: Record<string, string>) => {
    setMapping(newMapping)
    onChange(newMapping)
  }

  // For server-side rendering, return a minimal placeholder
  if (!isMounted) {
    return <div>Loading section mapper...</div>
  }

  return (
    <div className="space-y-4">
      <PredefinedMappings templateSections={templateSections} onApplyMapping={handleApplyPredefinedMapping} />

      {templateSections.map((section) => (
        <div
          key={section.id}
          className="flex items-center justify-between bg-white dark:bg-slate-700 rounded-md h-16 border border-gray-200 dark:border-gray-600 shadow-md"
        >
          <div className="flex-1 px-4 font-medium text-black dark:text-white">{section.name}</div>
          <div className="w-80 pr-4">
            <Select value={mapping[section.id] || ""} onValueChange={(value) => handleMappingChange(section.id, value)}>
              <SelectTrigger className="bg-white dark:bg-slate-800 border-gray-200 dark:border-gray-600 text-black dark:text-white">
                <SelectValue placeholder="Select section" />
              </SelectTrigger>
              <SelectContent className="bg-white dark:bg-slate-800 border-gray-200 dark:border-gray-600">
                {availableSections.map((name) => (
                  <SelectItem
                    key={name}
                    value={name}
                    className="text-black dark:text-white dark:focus:bg-slate-700 dark:focus:text-white"
                  >
                    {name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      ))}
    </div>
  )
}

