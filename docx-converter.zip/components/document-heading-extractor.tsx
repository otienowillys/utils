"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { DragDropContext, Droppable, Draggable, type DropResult } from "react-beautiful-dnd"
import { ChevronDown, ChevronRight, GripVertical, Edit, Trash, Plus, Save, X, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"

// Define types for document headings
export interface DocumentHeading {
  id: string
  text: string
  level: number
  content: string
  children: DocumentHeading[]
  styleName: string
}

interface DocumentHeadingExtractorProps {
  onHeadingsExtracted?: (headings: DocumentHeading[]) => void
  onHeadingsReordered?: (headings: DocumentHeading[]) => void
  onHeadingSelected?: (heading: DocumentHeading) => void
  className?: string
  isDarkMode?: boolean
}

export function DocumentHeadingExtractor({
  onHeadingsExtracted,
  onHeadingsReordered,
  onHeadingSelected,
  className = "",
  isDarkMode = false,
}: DocumentHeadingExtractorProps) {
  const [file, setFile] = useState<File | null>(null)
  const [headings, setHeadings] = useState<DocumentHeading[]>([])
  const [flatHeadings, setFlatHeadings] = useState<DocumentHeading[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [expandedHeadings, setExpandedHeadings] = useState<Record<string, boolean>>({})
  const [editingHeading, setEditingHeading] = useState<string | null>(null)
  const [editText, setEditText] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isDragging, setIsDragging] = useState(false)

  // Convert hierarchical headings to flat list for drag and drop
  useEffect(() => {
    if (headings.length === 0) return

    const flat: DocumentHeading[] = []

    const flattenHeadings = (headingList: DocumentHeading[]) => {
      headingList.forEach((heading) => {
        // Create a copy without children to avoid circular references
        const headingCopy = { ...heading, children: [] }
        flat.push(headingCopy)

        if (heading.children && heading.children.length > 0) {
          flattenHeadings(heading.children)
        }
      })
    }

    flattenHeadings(headings)
    setFlatHeadings(flat)
  }, [headings])

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0]

      // Check if file is a DOCX file
      if (!selectedFile.name.endsWith(".docx")) {
        toast({
          title: "Invalid file type",
          description: "Please select a DOCX file",
          variant: "destructive",
        })
        return
      }

      setFile(selectedFile)
      extractHeadings(selectedFile)
    }
  }

  // Handle file drop
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0]

      // Check if file is a DOCX file
      if (!droppedFile.name.endsWith(".docx")) {
        toast({
          title: "Invalid file type",
          description: "Please select a DOCX file",
          variant: "destructive",
        })
        return
      }

      setFile(droppedFile)
      extractHeadings(droppedFile)
    }
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
  }

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)
  }

  // Extract headings from DOCX file
  const extractHeadings = async (file: File) => {
    setIsLoading(true)
    setError(null)

    try {
      // Create form data to send the file
      const formData = new FormData()
      formData.append("file", file)

      // Send the file to the API
      const response = await fetch("/api/extract-headings", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to extract headings")
      }

      const data = await response.json()
      const extractedHeadings = data.headings

      setHeadings(extractedHeadings)

      // Initialize all top-level headings as expanded
      const expanded: Record<string, boolean> = {}
      extractedHeadings.forEach((heading: DocumentHeading) => {
        expanded[heading.id] = true
      })
      setExpandedHeadings(expanded)

      // Notify parent component
      if (onHeadingsExtracted) {
        onHeadingsExtracted(extractedHeadings)
      }

      toast({
        title: "Headings extracted",
        description: `Successfully extracted ${flattenHeadingCount(extractedHeadings)} headings from the document.`,
      })
    } catch (err) {
      console.error("Error extracting headings:", err)
      setError(err instanceof Error ? err.message : "Failed to extract headings from the document")

      toast({
        title: "Extraction failed",
        description: err instanceof Error ? err.message : "Failed to extract headings from the document",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Count total headings including nested ones
  const flattenHeadingCount = (headingList: DocumentHeading[]): number => {
    let count = headingList.length

    headingList.forEach((heading) => {
      if (heading.children && heading.children.length > 0) {
        count += flattenHeadingCount(heading.children)
      }
    })

    return count
  }

  // Toggle heading expansion
  const toggleHeading = (id: string) => {
    setExpandedHeadings((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  // Start editing a heading
  const startEditHeading = (heading: DocumentHeading) => {
    setEditingHeading(heading.id)
    setEditText(heading.text)
  }

  // Save edited heading
  const saveEditHeading = () => {
    if (!editingHeading) return

    // Update the heading text in the flat list
    const updatedFlatHeadings = flatHeadings.map((heading) => {
      if (heading.id === editingHeading) {
        return { ...heading, text: editText }
      }
      return heading
    })

    setFlatHeadings(updatedFlatHeadings)

    // Update the heading text in the hierarchical structure
    const updateHeadingText = (headingList: DocumentHeading[]): DocumentHeading[] => {
      return headingList.map((heading) => {
        if (heading.id === editingHeading) {
          return { ...heading, text: editText }
        }

        if (heading.children && heading.children.length > 0) {
          return {
            ...heading,
            children: updateHeadingText(heading.children),
          }
        }

        return heading
      })
    }

    const updatedHeadings = updateHeadingText(headings)
    setHeadings(updatedHeadings)

    // Reset editing state
    setEditingHeading(null)
    setEditText("")

    toast({
      title: "Heading updated",
      description: "The heading text has been updated successfully.",
    })
  }

  // Cancel editing
  const cancelEditHeading = () => {
    setEditingHeading(null)
    setEditText("")
  }

  // Delete a heading
  const deleteHeading = (id: string) => {
    // Remove the heading from the flat list
    const updatedFlatHeadings = flatHeadings.filter((heading) => heading.id !== id)
    setFlatHeadings(updatedFlatHeadings)

    // Remove the heading from the hierarchical structure
    const removeHeading = (headingList: DocumentHeading[]): DocumentHeading[] => {
      return headingList.filter((heading) => {
        if (heading.id === id) {
          return false
        }

        if (heading.children && heading.children.length > 0) {
          heading.children = removeHeading(heading.children)
        }

        return true
      })
    }

    const updatedHeadings = removeHeading(headings)
    setHeadings(updatedHeadings)

    toast({
      title: "Heading deleted",
      description: "The heading has been removed from the document structure.",
    })
  }

  // Handle drag end event for reordering headings
  const handleDragEnd = (result: DropResult) => {
    setIsDragging(false)

    if (!result.destination) return

    const items = Array.from(flatHeadings)
    const [reorderedItem] = items.splice(result.source.index, 1)
    items.splice(result.destination.index, 0, reorderedItem)

    setFlatHeadings(items)

    // In a real implementation, you would rebuild the hierarchical structure
    // This is a simplified approach for demonstration

    // Notify parent component
    if (onHeadingsReordered) {
      onHeadingsReordered(items)
    }

    toast({
      title: "Headings reordered",
      description: "The document structure has been updated.",
    })
  }

  // Save the current heading order
  const saveHeadingOrder = () => {
    // In a real implementation, you would send the updated structure to the backend
    toast({
      title: "Order saved",
      description: "The document structure has been saved successfully.",
    })
  }

  // Add a new heading
  const addNewHeading = () => {
    const newHeading: DocumentHeading = {
      id: `new-${Date.now()}`,
      text: "New Heading",
      level: 1,
      content: "",
      styleName: "Heading1",
      children: [],
    }

    setHeadings([...headings, newHeading])

    // Start editing the new heading
    setTimeout(() => {
      startEditHeading(newHeading)
    }, 100)
  }

  // Render the drop zone for file upload
  const renderDropZone = () => (
    <div
      onClick={() => fileInputRef.current?.click()}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      className={`border-2 border-dashed rounded-md p-8 text-center cursor-pointer transition-colors ${
        isDragging
          ? isDarkMode
            ? "border-blue-500 bg-blue-900/20"
            : "border-blue-500 bg-blue-100/50"
          : isDarkMode
            ? "border-gray-600 hover:border-gray-500"
            : "border-gray-300 hover:border-gray-400"
      }`}
    >
      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".docx" className="hidden" />

      {file ? (
        <div>
          <p className="font-semibold mb-2">Selected file:</p>
          <p className="mb-4">
            {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
          </p>
          <Button
            variant="destructive"
            onClick={(e) => {
              e.stopPropagation()
              setFile(null)
              setHeadings([])
              setFlatHeadings([])
            }}
          >
            Remove File
          </Button>
        </div>
      ) : (
        <>
          <p className="mb-4">Drag and drop a DOCX file here, or click to select a file</p>
          <Button>Select DOCX File</Button>
        </>
      )}
    </div>
  )

  // Render loading state
  if (isLoading) {
    return (
      <Card className={`${isDarkMode ? "bg-gray-800 border-gray-700" : ""} ${className}`}>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-8">
            <div
              className={`animate-spin rounded-full h-8 w-8 border-b-2 ${isDarkMode ? "border-blue-400" : "border-blue-600"}`}
            ></div>
            <span className="ml-3">Extracting headings from document...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Render error state
  if (error) {
    return (
      <Card className={`${isDarkMode ? "bg-gray-800 border-gray-700" : ""} ${className}`}>
        <CardHeader>
          <CardTitle className="flex items-center text-red-500">
            <AlertCircle className="mr-2" size={20} />
            Error Extracting Headings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">{error}</p>
          {file && (
            <Button onClick={() => extractHeadings(file)} className="mt-2">
              Try Again
            </Button>
          )}
        </CardContent>
      </Card>
    )
  }

  // Render initial state with drop zone
  if (!file || headings.length === 0) {
    return (
      <Card className={`${isDarkMode ? "bg-gray-800 border-gray-700" : ""} ${className}`}>
        <CardHeader>
          <CardTitle>Document Heading Extractor</CardTitle>
          <CardDescription>Upload a DOCX file to extract and manage its headings</CardDescription>
        </CardHeader>
        <CardContent>{renderDropZone()}</CardContent>
      </Card>
    )
  }

  // Render headings with drag and drop
  return (
    <Card className={`${isDarkMode ? "bg-gray-800 border-gray-700" : ""} ${className}`}>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Document Headings</CardTitle>
            <CardDescription>Drag and drop to reorder headings</CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setFile(null)
              setHeadings([])
              setFlatHeadings([])
            }}
          >
            Change File
          </Button>
        </div>
      </CardHeader>

      <CardContent className="p-2">
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="headings">
            {(provided, snapshot) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className={`space-y-1 p-2 rounded-md ${
                  snapshot.isDraggingOver ? (isDarkMode ? "bg-gray-700/50" : "bg-gray-100") : ""
                }`}
              >
                {flatHeadings.map((heading, index) => (
                  <Draggable key={heading.id} draggableId={heading.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`flex items-center p-2 rounded-md ${
                          snapshot.isDragging
                            ? isDarkMode
                              ? "bg-gray-600 border border-gray-500 shadow-lg"
                              : "bg-gray-50 border border-gray-300 shadow-lg"
                            : isDarkMode
                              ? "hover:bg-gray-700 border border-gray-700"
                              : "hover:bg-gray-50 border border-gray-200"
                        }`}
                      >
                        <div {...provided.dragHandleProps} className="mr-2 cursor-grab">
                          <GripVertical size={16} className={isDarkMode ? "text-gray-400" : "text-gray-500"} />
                        </div>

                        <button
                          onClick={() => toggleHeading(heading.id)}
                          className={`mr-1 p-1 rounded-md ${isDarkMode ? "hover:bg-gray-600" : "hover:bg-gray-200"}`}
                        >
                          {expandedHeadings[heading.id] ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                        </button>

                        <div className="flex-1">
                          {editingHeading === heading.id ? (
                            <div className="flex items-center">
                              <input
                                type="text"
                                value={editText}
                                onChange={(e) => setEditText(e.target.value)}
                                className={`flex-1 px-2 py-1 rounded-md mr-2 ${
                                  isDarkMode ? "bg-gray-700 border-gray-600 text-white" : "bg-white border-gray-300"
                                }`}
                                autoFocus
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") saveEditHeading()
                                  if (e.key === "Escape") cancelEditHeading()
                                }}
                              />
                              <button
                                onClick={saveEditHeading}
                                className={`p-1 rounded-md ${
                                  isDarkMode
                                    ? "bg-green-700 hover:bg-green-600 text-white"
                                    : "bg-green-100 hover:bg-green-200 text-green-700"
                                }`}
                              >
                                <Save size={14} />
                              </button>
                              <button
                                onClick={cancelEditHeading}
                                className={`p-1 rounded-md ml-1 ${
                                  isDarkMode
                                    ? "bg-gray-700 hover:bg-gray-600 text-white"
                                    : "bg-gray-100 hover:bg-gray-200 text-gray-700"
                                }`}
                              >
                                <X size={14} />
                              </button>
                            </div>
                          ) : (
                            <div
                              className={`${
                                heading.level === 1 ? "font-semibold" : heading.level === 2 ? "font-medium" : ""
                              }`}
                              style={{ paddingLeft: `${(heading.level - 1) * 1.5}rem` }}
                              onClick={() => onHeadingSelected && onHeadingSelected(heading)}
                            >
                              {heading.text}
                              <Badge
                                variant="outline"
                                className={`ml-2 ${
                                  heading.level === 1
                                    ? "bg-blue-100 text-blue-800 border-blue-200"
                                    : heading.level === 2
                                      ? "bg-green-100 text-green-800 border-green-200"
                                      : "bg-amber-100 text-amber-800 border-amber-200"
                                }`}
                              >
                                H{heading.level}
                              </Badge>
                            </div>
                          )}
                        </div>

                        {editingHeading !== heading.id && (
                          <div className="flex space-x-1">
                            <button
                              onClick={() => startEditHeading(heading)}
                              className={`p-1 rounded-md ${
                                isDarkMode ? "hover:bg-gray-600 text-amber-400" : "hover:bg-gray-200 text-amber-600"
                              }`}
                              title="Edit heading"
                            >
                              <Edit size={14} />
                            </button>
                            <button
                              onClick={() => deleteHeading(heading.id)}
                              className={`p-1 rounded-md ${
                                isDarkMode ? "hover:bg-gray-600 text-red-400" : "hover:bg-gray-200 text-red-600"
                              }`}
                              title="Delete heading"
                            >
                              <Trash size={14} />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </CardContent>

      <CardFooter className="flex justify-between">
        <Button variant="outline" size="sm" onClick={addNewHeading} className="flex items-center">
          <Plus size={16} className="mr-1" />
          Add Heading
        </Button>

        <Button size="sm" onClick={saveHeadingOrder} className="flex items-center">
          <Save size={16} className="mr-1" />
          Save Order
        </Button>
      </CardFooter>
    </Card>
  )
}

