"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getAnalyticsEvents } from "@/components/analytics"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export function AnalyticsWidget() {
  const [analyticsData, setAnalyticsData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadAnalytics = async () => {
      try {
        // Use the local analytics data instead of fetching from API
        const events = getAnalyticsEvents()

        // Process events for display
        const pageViews = events
          .filter((event) => event.name === "page_view")
          .reduce(
            (acc, event) => {
              const path = (event.properties?.path as string) || "unknown"
              acc[path] = (acc[path] || 0) + 1
              return acc
            },
            {} as Record<string, number>,
          )

        const chartData = Object.entries(pageViews).map(([path, count]) => ({
          path: path === "/" ? "Home" : path.replace(/^\//, "").charAt(0).toUpperCase() + path.slice(2),
          views: count,
        }))

        setAnalyticsData(chartData)
      } catch (error) {
        console.error("Error loading analytics:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadAnalytics()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Page Views</CardTitle>
        <CardDescription>Analytics for your document conversions</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <p>Loading analytics...</p>
          </div>
        ) : analyticsData.length === 0 ? (
          <div className="flex justify-center items-center h-64">
            <p>No analytics data available yet</p>
          </div>
        ) : (
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="path" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="views" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

