"use client"

import { CheckCircle2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { useState, useEffect } from "react"

interface Step {
  number: number
  label: string
}

interface AnimatedStepIndicatorProps {
  steps: Step[]
  currentStep: number
  className?: string
}

export function AnimatedStepIndicator({ steps, currentStep, className }: AnimatedStepIndicatorProps) {
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  // For server-side rendering, return a minimal placeholder
  if (!isMounted) {
    return <div className={cn("relative mb-8", className)}>Loading steps...</div>
  }

  return (
    <div className={cn("relative mb-8", className)}>
      {/* Horizontal line connecting steps */}
      <div className="absolute top-4 left-0 right-0 h-0.5 bg-muted" />

      {/* Progress line */}
      <div
        className="absolute top-4 left-0 h-0.5 bg-brand-500 transition-all duration-500"
        style={{ width: `${(Math.max(0, currentStep - 1) / (steps.length - 1)) * 100}%` }}
      />

      {/* Steps */}
      <div className="relative flex justify-between">
        {steps.map((step) => {
          const isActive = step.number === currentStep
          const isCompleted = step.number < currentStep

          return (
            <div key={step.number} className="flex flex-col items-center">
              {/* Step circle */}
              <div
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full border-2 z-10 transition-colors",
                  isActive
                    ? "border-brand-500 bg-brand-500 text-white"
                    : isCompleted
                      ? "border-brand-500 bg-brand-500 text-white"
                      : "border-muted bg-background text-muted-foreground",
                )}
              >
                {isCompleted ? <CheckCircle2 className="h-5 w-5" /> : <span>{step.number}</span>}
              </div>

              {/* Step label */}
              <span
                className={cn(
                  "mt-2 text-sm font-medium transition-colors",
                  isActive || isCompleted ? "text-brand-500" : "text-muted-foreground",
                )}
              >
                {step.label}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

