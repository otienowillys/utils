"use client"

import { useState, useEffect } from "react"
import { Settings, Plus, Edit, Trash2, Save } from "lucide-react"
import type { PredefinedMapping } from "@/lib/types"
import { PREDEFINED_MAPPINGS } from "./predefined-mappings"

interface DarkMappingManagerProps {
  onMappingsUpdated: () => void
}

export function DarkMappingManager({ onMappingsUpdated }: DarkMappingManagerProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [isOpen, setIsOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("view")
  const [customMappings, setCustomMappings] = useState<PredefinedMapping[]>([])
  const [allMappings, setAllMappings] = useState<PredefinedMapping[]>([])
  const [selectedMapping, setSelectedMapping] = useState<PredefinedMapping | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [isCreating, setIsCreating] = useState(false)
  const [editedMapping, setEditedMapping] = useState<PredefinedMapping | null>(null)
  const [mappingPairs, setMappingPairs] = useState<{ docSection: string; templateSection: string }[]>([])
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [mappingToDelete, setMappingToDelete] = useState<string | null>(null)

  // Ensure hydration safety
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Load custom mappings from localStorage
  useEffect(() => {
    if (!isMounted) return

    const storedMappings = localStorage.getItem("customPredefinedMappings")
    if (storedMappings) {
      try {
        const parsedMappings = JSON.parse(storedMappings) as PredefinedMapping[]
        setCustomMappings(parsedMappings)
      } catch (error) {
        console.error("Error parsing custom mappings:", error)
        setCustomMappings([])
      }
    }
  }, [isMounted])

  // Combine built-in and custom mappings
  useEffect(() => {
    const combined = [...PREDEFINED_MAPPINGS, ...customMappings.map((mapping) => ({ ...mapping, isCustom: true }))]
    setAllMappings(combined)
  }, [customMappings])

  // Convert mapping object to array of pairs for editing
  useEffect(() => {
    if (editedMapping) {
      const pairs = Object.entries(editedMapping.mapping).map(([docSection, templateSection]) => ({
        docSection,
        templateSection,
      }))
      setMappingPairs(pairs)
    }
  }, [editedMapping])

  const handleViewMapping = (mapping: PredefinedMapping) => {
    setSelectedMapping(mapping)
    setIsEditing(false)
    setIsCreating(false)
  }

  const handleEditMapping = (mapping: PredefinedMapping) => {
    setEditedMapping({ ...mapping })
    setIsEditing(true)
    setIsCreating(false)
    setActiveTab("edit")
  }

  const handleCreateMapping = () => {
    const newMapping: PredefinedMapping = {
      id: `custom-${Date.now()}`,
      name: "",
      description: "",
      mapping: {},
      isCustom: true,
    }
    setEditedMapping(newMapping)
    setMappingPairs([{ docSection: "", templateSection: "" }])
    setIsEditing(false)
    setIsCreating(true)
    setActiveTab("create")
  }

  const handleDeleteMapping = (mappingId: string) => {
    const updatedMappings = customMappings.filter((m) => m.id !== mappingId)
    setCustomMappings(updatedMappings)
    localStorage.setItem("customPredefinedMappings", JSON.stringify(updatedMappings))
    onMappingsUpdated()
    setDeleteConfirmOpen(false)
    setMappingToDelete(null)
  }

  const handleAddMappingPair = () => {
    setMappingPairs([...mappingPairs, { docSection: "", templateSection: "" }])
  }

  const handleRemoveMappingPair = (index: number) => {
    const updatedPairs = [...mappingPairs]
    updatedPairs.splice(index, 1)
    setMappingPairs(updatedPairs)
  }

  const handleMappingPairChange = (index: number, field: "docSection" | "templateSection", value: string) => {
    const updatedPairs = [...mappingPairs]
    updatedPairs[index][field] = value
    setMappingPairs(updatedPairs)
  }

  const handleSaveMapping = () => {
    if (!editedMapping) return

    // Convert pairs back to mapping object
    const mapping: Record<string, string> = {}
    mappingPairs.forEach((pair) => {
      if (pair.docSection && pair.templateSection) {
        mapping[pair.docSection] = pair.templateSection
      }
    })

    const updatedMapping: PredefinedMapping = {
      ...editedMapping,
      mapping,
    }

    if (isCreating) {
      // Add new mapping
      const updatedMappings = [...customMappings, updatedMapping]
      setCustomMappings(updatedMappings)
      localStorage.setItem("customPredefinedMappings", JSON.stringify(updatedMappings))
    } else {
      // Update existing mapping
      const updatedMappings = customMappings.map((m) => (m.id === updatedMapping.id ? updatedMapping : m))
      setCustomMappings(updatedMappings)
      localStorage.setItem("customPredefinedMappings", JSON.stringify(updatedMappings))
    }

    setIsEditing(false)
    setIsCreating(false)
    setSelectedMapping(updatedMapping)
    setActiveTab("view")
    onMappingsUpdated()
  }

  // Don't render anything during SSR or before hydration
  if (!isMounted) {
    return null
  }

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        style={{
          display: "flex",
          alignItems: "center",
          gap: "0.25rem",
          padding: "0.25rem 0.5rem",
          backgroundColor: "#334155", // slate-700
          color: "white",
          borderRadius: "0.25rem",
          border: "1px solid #475569", // slate-600
          cursor: "pointer",
          fontSize: "0.75rem",
        }}
      >
        <Settings style={{ width: "0.75rem", height: "0.75rem" }} />
        <span>Manage Mappings</span>
      </button>
    )
  }

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.75)",
        zIndex: 50,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "1rem",
      }}
    >
      <div
        style={{
          backgroundColor: "#0f172a", // slate-900
          borderRadius: "0.5rem",
          width: "100%",
          maxWidth: "900px",
          maxHeight: "90vh",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          border: "1px solid #334155", // slate-700
        }}
      >
        <div
          style={{
            padding: "1rem",
            borderBottom: "1px solid #334155", // slate-700
          }}
        >
          <h2 style={{ fontSize: "1.25rem", fontWeight: "600", color: "white", margin: 0 }}>
            Manage Predefined Mappings
          </h2>
          <p style={{ fontSize: "0.875rem", color: "#94a3b8", margin: "0.5rem 0 0 0" }}>
            View, edit, or create new predefined mapping templates for document conversion.
          </p>
        </div>

        <div
          style={{
            display: "flex",
            borderBottom: "1px solid #334155", // slate-700
          }}
        >
          <button
            onClick={() => setActiveTab("view")}
            style={{
              padding: "0.75rem 1rem",
              backgroundColor: activeTab === "view" ? "#1e293b" : "transparent", // slate-800 if active
              color: "white",
              border: "none",
              borderRight: "1px solid #334155", // slate-700
              cursor: "pointer",
              flex: 1,
              textAlign: "center",
            }}
          >
            View Mappings
          </button>
          {isEditing && (
            <button
              onClick={() => setActiveTab("edit")}
              style={{
                padding: "0.75rem 1rem",
                backgroundColor: activeTab === "edit" ? "#1e293b" : "transparent", // slate-800 if active
                color: "white",
                border: "none",
                borderRight: "1px solid #334155", // slate-700
                cursor: "pointer",
                flex: 1,
                textAlign: "center",
              }}
            >
              Edit Mapping
            </button>
          )}
          {isCreating && (
            <button
              onClick={() => setActiveTab("create")}
              style={{
                padding: "0.75rem 1rem",
                backgroundColor: activeTab === "create" ? "#1e293b" : "transparent", // slate-800 if active
                color: "white",
                border: "none",
                borderRight: "1px solid #334155", // slate-700
                cursor: "pointer",
                flex: 1,
                textAlign: "center",
              }}
            >
              Create Mapping
            </button>
          )}
          {!isEditing && !isCreating && (
            <button
              onClick={handleCreateMapping}
              style={{
                padding: "0.75rem 1rem",
                backgroundColor: activeTab === "create" ? "#1e293b" : "transparent", // slate-800 if active
                color: "white",
                border: "none",
                borderRight: "1px solid #334155", // slate-700
                cursor: "pointer",
                flex: 1,
                textAlign: "center",
              }}
            >
              Create New
            </button>
          )}
          <button
            onClick={() => setActiveTab("about")}
            style={{
              padding: "0.75rem 1rem",
              backgroundColor: activeTab === "about" ? "#1e293b" : "transparent", // slate-800 if active
              color: "white",
              border: "none",
              cursor: "pointer",
              flex: 1,
              textAlign: "center",
            }}
          >
            About
          </button>
        </div>

        <div
          style={{
            padding: "1rem",
            overflowY: "auto",
            flex: 1,
          }}
        >
          {activeTab === "view" && (
            <div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  marginBottom: "1rem",
                }}
              >
                <button
                  onClick={handleCreateMapping}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "0.25rem",
                    padding: "0.5rem 1rem",
                    backgroundColor: "#2563eb", // blue-600
                    color: "white",
                    borderRadius: "0.25rem",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  <Plus style={{ width: "0.875rem", height: "0.875rem" }} />
                  <span>Create New Mapping</span>
                </button>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
                  gap: "1rem",
                }}
              >
                {allMappings.map((mapping) => (
                  <div
                    key={mapping.id}
                    style={{
                      backgroundColor: "#1e293b", // slate-800
                      borderRadius: "0.5rem",
                      border: mapping.isCustom ? "1px solid #3b82f6" : "1px solid #334155", // blue-500 for custom, slate-700 for built-in
                      overflow: "hidden",
                      marginBottom: "0.75rem",
                    }}
                  >
                    <div
                      style={{
                        padding: "1rem",
                        borderBottom: "1px solid #334155", // slate-700
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "flex-start",
                        }}
                      >
                        <div>
                          <h3 style={{ fontSize: "1rem", fontWeight: "600", color: "white", margin: 0 }}>
                            {mapping.name}
                          </h3>
                          {mapping.isCustom && (
                            <span
                              style={{
                                fontSize: "0.625rem",
                                backgroundColor: "#1e40af", // blue-800
                                color: "#93c5fd", // blue-300
                                padding: "0.125rem 0.5rem",
                                borderRadius: "9999px",
                                display: "inline-block",
                                marginTop: "0.25rem",
                              }}
                            >
                              Custom
                            </span>
                          )}
                        </div>
                        <div style={{ display: "flex", gap: "0.25rem" }}>
                          <button
                            onClick={() => handleViewMapping(mapping)}
                            style={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              width: "1.75rem",
                              height: "1.75rem",
                              backgroundColor: "#334155", // slate-700
                              color: "white",
                              borderRadius: "0.25rem",
                              border: "none",
                              cursor: "pointer",
                            }}
                            title="View Details"
                          >
                            <Settings style={{ width: "0.875rem", height: "0.875rem" }} />
                          </button>
                          {mapping.isCustom && (
                            <>
                              <button
                                onClick={() => handleEditMapping(mapping)}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  width: "1.75rem",
                                  height: "1.75rem",
                                  backgroundColor: "#78350f", // amber-900
                                  color: "#fcd34d", // amber-300
                                  borderRadius: "0.25rem",
                                  border: "none",
                                  cursor: "pointer",
                                }}
                                title="Edit Mapping"
                              >
                                <Edit style={{ width: "0.875rem", height: "0.875rem" }} />
                              </button>
                              <button
                                onClick={() => {
                                  setMappingToDelete(mapping.id)
                                  setDeleteConfirmOpen(true)
                                }}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  width: "1.75rem",
                                  height: "1.75rem",
                                  backgroundColor: "#7f1d1d", // red-900
                                  color: "#fca5a5", // red-300
                                  borderRadius: "0.25rem",
                                  border: "none",
                                  cursor: "pointer",
                                }}
                                title="Delete Mapping"
                              >
                                <Trash2 style={{ width: "0.875rem", height: "0.875rem" }} />
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                      <p style={{ fontSize: "0.75rem", color: "#94a3b8", margin: "0.5rem 0 0 0" }}>
                        {mapping.description}
                      </p>
                    </div>
                    <div style={{ padding: "0.75rem 1rem" }}>
                      <p style={{ fontSize: "0.75rem", color: "#94a3b8", margin: 0 }}>
                        {Object.keys(mapping.mapping).length} section mappings
                      </p>
                    </div>
                    {mapping.isCustom && (
                      <div
                        style={{
                          padding: "0.75rem 1rem",
                          borderTop: "1px solid #334155", // slate-700
                          display: "flex",
                          justifyContent: "flex-end",
                          gap: "0.5rem",
                        }}
                      >
                        <button
                          onClick={() => handleEditMapping(mapping)}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "0.25rem",
                            padding: "0.375rem 0.75rem",
                            backgroundColor: "#334155", // slate-700
                            color: "white",
                            borderRadius: "0.25rem",
                            border: "none",
                            cursor: "pointer",
                            fontSize: "0.75rem",
                          }}
                        >
                          <Edit style={{ width: "0.75rem", height: "0.75rem" }} />
                          <span>Edit</span>
                        </button>
                        <button
                          onClick={() => {
                            setMappingToDelete(mapping.id)
                            setDeleteConfirmOpen(true)
                          }}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "0.25rem",
                            padding: "0.375rem 0.75rem",
                            backgroundColor: "#7f1d1d", // red-900
                            color: "#fca5a5", // red-300
                            borderRadius: "0.25rem",
                            border: "none",
                            cursor: "pointer",
                            fontSize: "0.75rem",
                          }}
                        >
                          <Trash2 style={{ width: "0.75rem", height: "0.75rem" }} />
                          <span>Delete</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {selectedMapping && (
                <div
                  style={{
                    backgroundColor: "#1e293b", // slate-800
                    borderRadius: "0.5rem",
                    border: "1px solid #334155", // slate-700
                    marginTop: "1.5rem",
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      padding: "1rem",
                      borderBottom: "1px solid #334155", // slate-700
                    }}
                  >
                    <h3 style={{ fontSize: "1.125rem", fontWeight: "600", color: "white", margin: 0 }}>
                      {selectedMapping.name}
                    </h3>
                    <p style={{ fontSize: "0.875rem", color: "#94a3b8", margin: "0.5rem 0 0 0" }}>
                      {selectedMapping.description}
                    </p>
                  </div>
                  <div style={{ padding: "1rem" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                      <thead>
                        <tr>
                          <th
                            style={{
                              textAlign: "left",
                              padding: "0.5rem",
                              color: "white",
                              borderBottom: "1px solid #334155",
                            }}
                          >
                            Document Section
                          </th>
                          <th
                            style={{
                              textAlign: "left",
                              padding: "0.5rem",
                              color: "white",
                              borderBottom: "1px solid #334155",
                            }}
                          >
                            Template Section
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {Object.entries(selectedMapping.mapping).map(([docSection, templateSection]) => (
                          <tr key={docSection}>
                            <td style={{ padding: "0.5rem", color: "white", borderBottom: "1px solid #334155" }}>
                              {docSection}
                            </td>
                            <td style={{ padding: "0.5rem", color: "white", borderBottom: "1px solid #334155" }}>
                              {templateSection}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {selectedMapping.isCustom && (
                    <div
                      style={{
                        padding: "1rem",
                        borderTop: "1px solid #334155", // slate-700
                        display: "flex",
                        justifyContent: "flex-end",
                        gap: "0.5rem",
                      }}
                    >
                      <button
                        onClick={() => handleEditMapping(selectedMapping)}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "0.25rem",
                          padding: "0.5rem 1rem",
                          backgroundColor: "#334155", // slate-700
                          color: "white",
                          borderRadius: "0.25rem",
                          border: "none",
                          cursor: "pointer",
                        }}
                      >
                        <Edit style={{ width: "0.875rem", height: "0.875rem" }} />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => {
                          setMappingToDelete(selectedMapping.id)
                          setDeleteConfirmOpen(true)
                        }}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "0.25rem",
                          padding: "0.5rem 1rem",
                          backgroundColor: "#7f1d1d", // red-900
                          color: "#fca5a5", // red-300
                          borderRadius: "0.25rem",
                          border: "none",
                          cursor: "pointer",
                        }}
                      >
                        <Trash2 style={{ width: "0.875rem", height: "0.875rem" }} />
                        <span>Delete</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {(activeTab === "edit" || activeTab === "create") && editedMapping && (
            <div
              style={{
                backgroundColor: "#1e293b", // slate-800
                borderRadius: "0.5rem",
                border: "1px solid #334155", // slate-700
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "1rem",
                  borderBottom: "1px solid #334155", // slate-700
                }}
              >
                <h3 style={{ fontSize: "1.125rem", fontWeight: "600", color: "white", margin: 0 }}>
                  {activeTab === "edit" ? "Edit Mapping" : "Create New Mapping"}
                </h3>
                <p style={{ fontSize: "0.875rem", color: "#94a3b8", margin: "0.5rem 0 0 0" }}>
                  {activeTab === "edit"
                    ? "Modify the mapping details and section pairs"
                    : "Create a new custom mapping template"}
                </p>
              </div>
              <div style={{ padding: "1rem" }}>
                <div style={{ marginBottom: "1rem" }}>
                  <label
                    style={{
                      display: "block",
                      fontSize: "0.875rem",
                      fontWeight: "500",
                      color: "white",
                      marginBottom: "0.25rem",
                    }}
                  >
                    Mapping Name
                  </label>
                  <input
                    value={editedMapping.name}
                    onChange={(e) => setEditedMapping({ ...editedMapping, name: e.target.value })}
                    placeholder="e.g., Technical Report"
                    style={{
                      width: "100%",
                      padding: "0.5rem",
                      backgroundColor: "#0f172a", // slate-900
                      color: "white",
                      border: "1px solid #334155", // slate-700
                      borderRadius: "0.25rem",
                      outline: "none",
                    }}
                  />
                </div>

                <div style={{ marginBottom: "1rem" }}>
                  <label
                    style={{
                      display: "block",
                      fontSize: "0.875rem",
                      fontWeight: "500",
                      color: "white",
                      marginBottom: "0.25rem",
                    }}
                  >
                    Description
                  </label>
                  <textarea
                    value={editedMapping.description}
                    onChange={(e) => setEditedMapping({ ...editedMapping, description: e.target.value })}
                    placeholder="Describe what this mapping is used for"
                    rows={2}
                    style={{
                      width: "100%",
                      padding: "0.5rem",
                      backgroundColor: "#0f172a", // slate-900
                      color: "white",
                      border: "1px solid #334155", // slate-700
                      borderRadius: "0.25rem",
                      outline: "none",
                      resize: "vertical",
                    }}
                  />
                </div>

                <div style={{ marginBottom: "1rem" }}>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      marginBottom: "0.5rem",
                    }}
                  >
                    <label
                      style={{
                        fontSize: "0.875rem",
                        fontWeight: "500",
                        color: "white",
                      }}
                    >
                      Section Mappings
                    </label>
                    <button
                      onClick={handleAddMappingPair}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "0.25rem",
                        padding: "0.25rem 0.5rem",
                        backgroundColor: "#334155", // slate-700
                        color: "white",
                        borderRadius: "0.25rem",
                        border: "none",
                        cursor: "pointer",
                        fontSize: "0.75rem",
                      }}
                    >
                      <Plus style={{ width: "0.75rem", height: "0.75rem" }} />
                      <span>Add Mapping</span>
                    </button>
                  </div>

                  <div
                    style={{
                      maxHeight: "300px",
                      overflowY: "auto",
                      padding: "0.25rem",
                    }}
                  >
                    {mappingPairs.map((pair, index) => (
                      <div
                        key={index}
                        style={{
                          display: "flex",
                          gap: "0.5rem",
                          alignItems: "center",
                          marginBottom: "0.5rem",
                        }}
                      >
                        <div style={{ flex: 1 }}>
                          <input
                            value={pair.docSection}
                            onChange={(e) => handleMappingPairChange(index, "docSection", e.target.value)}
                            placeholder="Document Section"
                            style={{
                              width: "100%",
                              padding: "0.5rem",
                              backgroundColor: "#0f172a", // slate-900
                              color: "white",
                              border: "1px solid #334155", // slate-700
                              borderRadius: "0.25rem",
                              outline: "none",
                            }}
                          />
                        </div>
                        <div style={{ flex: 1 }}>
                          <input
                            value={pair.templateSection}
                            onChange={(e) => handleMappingPairChange(index, "templateSection", e.target.value)}
                            placeholder="Template Section"
                            style={{
                              width: "100%",
                              padding: "0.5rem",
                              backgroundColor: "#0f172a", // slate-900
                              color: "white",
                              border: "1px solid #334155", // slate-700
                              borderRadius: "0.25rem",
                              outline: "none",
                            }}
                          />
                        </div>
                        <button
                          onClick={() => handleRemoveMappingPair(index)}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            width: "1.5rem",
                            height: "1.5rem",
                            backgroundColor: "transparent",
                            color: "#ef4444", // red-500
                            borderRadius: "0.25rem",
                            border: "none",
                            cursor: "pointer",
                          }}
                        >
                          <Trash2 style={{ width: "0.75rem", height: "0.75rem" }} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div
                style={{
                  padding: "1rem",
                  borderTop: "1px solid #334155", // slate-700
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "0.5rem",
                }}
              >
                <button
                  onClick={() => {
                    setIsEditing(false)
                    setIsCreating(false)
                    setActiveTab("view")
                  }}
                  style={{
                    padding: "0.5rem 1rem",
                    backgroundColor: "#334155", // slate-700
                    color: "white",
                    borderRadius: "0.25rem",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveMapping}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "0.25rem",
                    padding: "0.5rem 1rem",
                    backgroundColor: "#2563eb", // blue-600
                    color: "white",
                    borderRadius: "0.25rem",
                    border: "none",
                    cursor: "pointer",
                  }}
                >
                  <Save style={{ width: "0.875rem", height: "0.875rem" }} />
                  <span>Save Mapping</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === "about" && (
            <div
              style={{
                backgroundColor: "#1e293b", // slate-800
                borderRadius: "0.5rem",
                border: "1px solid #334155", // slate-700
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "1rem",
                  borderBottom: "1px solid #334155", // slate-700
                }}
              >
                <h3 style={{ fontSize: "1.125rem", fontWeight: "600", color: "white", margin: 0 }}>
                  About Predefined Mappings
                </h3>
              </div>
              <div style={{ padding: "1rem", color: "white" }}>
                <p style={{ margin: "0 0 1rem 0" }}>
                  Predefined mappings help you quickly map document sections to template sections based on common
                  document types.
                </p>
                <h4 style={{ fontSize: "1rem", fontWeight: "600", margin: "1rem 0 0.5rem 0" }}>Built-in Mappings</h4>
                <p style={{ margin: "0 0 1rem 0" }}>
                  The application comes with several built-in mappings for common document types. These cannot be
                  modified but provide a good starting point.
                </p>
                <h4 style={{ fontSize: "1rem", fontWeight: "600", margin: "1rem 0 0.5rem 0" }}>Custom Mappings</h4>
                <p style={{ margin: "0 0 1rem 0" }}>
                  You can create your own custom mappings tailored to your specific document types. Custom mappings can
                  be edited or deleted as needed.
                </p>
                <h4 style={{ fontSize: "1rem", fontWeight: "600", margin: "1rem 0 0.5rem 0" }}>How Mappings Work</h4>
                <p style={{ margin: "0 0 1rem 0" }}>
                  Each mapping contains pairs of document section names and template section names. When you apply a
                  mapping, the application looks for matching template sections and automatically maps them to the
                  corresponding document sections.
                </p>
              </div>
            </div>
          )}
        </div>

        <div
          style={{
            padding: "1rem",
            borderTop: "1px solid #334155", // slate-700
            display: "flex",
            justifyContent: "flex-end",
          }}
        >
          <button
            onClick={() => setIsOpen(false)}
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: "#334155", // slate-700
              color: "white",
              borderRadius: "0.25rem",
              border: "none",
              cursor: "pointer",
            }}
          >
            Close
          </button>
        </div>
      </div>

      {deleteConfirmOpen && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: "rgba(0, 0, 0, 0.75)",
            zIndex: 60,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "1rem",
          }}
        >
          <div
            style={{
              backgroundColor: "#0f172a", // slate-900
              borderRadius: "0.5rem",
              width: "100%",
              maxWidth: "400px",
              overflow: "hidden",
              display: "flex",
              flexDirection: "column",
              border: "1px solid #334155", // slate-700
            }}
          >
            <div
              style={{
                padding: "1rem",
                borderBottom: "1px solid #334155", // slate-700
              }}
            >
              <h2 style={{ fontSize: "1.25rem", fontWeight: "600", color: "white", margin: 0 }}>Delete Mapping</h2>
              <p style={{ fontSize: "0.875rem", color: "#94a3b8", margin: "0.5rem 0 0 0" }}>
                Are you sure you want to delete this mapping? This action cannot be undone.
              </p>
            </div>
            <div
              style={{
                padding: "1rem",
                display: "flex",
                justifyContent: "flex-end",
                gap: "0.5rem",
              }}
            >
              <button
                onClick={() => {
                  setDeleteConfirmOpen(false)
                  setMappingToDelete(null)
                }}
                style={{
                  padding: "0.5rem 1rem",
                  backgroundColor: "#334155", // slate-700
                  color: "white",
                  borderRadius: "0.25rem",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                Cancel
              </button>
              <button
                onClick={() => mappingToDelete && handleDeleteMapping(mappingToDelete)}
                style={{
                  padding: "0.5rem 1rem",
                  backgroundColor: "#ef4444", // red-500
                  color: "white",
                  borderRadius: "0.25rem",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

