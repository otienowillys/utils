"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Template } from "@/lib/types"

interface TemplateSelectorProps {
  templates: Template[]
  selectedTemplateId: string
  onTemplateChange: (templateId: string) => void
  className?: string
}

export function TemplateSelector({
  templates,
  selectedTemplateId,
  onTemplateChange,
  className,
}: TemplateSelectorProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null)

  // Ensure hydration safety
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Update selected template when selectedTemplateId changes
  useEffect(() => {
    if (isMounted && selectedTemplateId) {
      const template = templates.find((t) => t.id === selectedTemplateId)
      setSelectedTemplate(template || null)
    }
  }, [selectedTemplateId, templates, isMounted])

  // For server-side rendering, return a minimal placeholder
  if (!isMounted) {
    return <div className={className}>Loading template selector...</div>
  }

  return (
    <div className={className}>
      <div className="space-y-2">
        <label className="text-base font-medium">Template</label>
        <Select value={selectedTemplateId} onValueChange={onTemplateChange}>
          <SelectTrigger className="w-full bg-background border-input">
            <SelectValue placeholder="Select a template" />
          </SelectTrigger>
          <SelectContent>
            {templates.map((template) => (
              <SelectItem key={template.id} value={template.id}>
                {template.name} ({template.sections.length} sections)
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-sm text-muted-foreground">{templates.length} templates available</p>
      </div>

      {selectedTemplate && (
        <div className="mt-6">
          <h3 className="text-base font-medium mb-3">Template Preview</h3>
          <Card className="border bg-muted/20">
            <CardContent className="p-0">
              <div className="divide-y">
                {selectedTemplate.sections.map((section) => (
                  <div key={section.id} className="p-3 text-primary">
                    {section.name}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

