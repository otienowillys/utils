"use client"

import { useEffect } from "react"
import { usePathname } from "next/navigation"

// Simple in-memory analytics storage
const analyticsEvents = []

// Mock function to send analytics data
const sendAnalyticsData = async (eventName, properties) => {
  // In a real implementation, this would send data to an analytics service
  // For now, we'll just log to console and store in memory
  console.log(`[Analytics] ${eventName}`, properties)

  analyticsEvents.push({
    name: eventName,
    properties,
    timestamp: new Date(),
  })

  // Return a successful response instead of making a network request
  return { success: true }
}

export function Analytics() {
  const pathname = usePathname()

  useEffect(() => {
    // Track page views
    const handlePageView = async () => {
      try {
        await sendAnalyticsData("page_view", {
          path: pathname,
          timestamp: Date.now(),
        })
      } catch (error) {
        // Silently handle errors to prevent breaking the UI
        console.error("Analytics error (non-critical):", error)
      }
    }

    if (pathname) {
      handlePageView()
    }
  }, [pathname])

  return null
}

// Analytics API
export const trackEvent = async (eventName, properties) => {
  try {
    return await sendAnalyticsData(eventName, properties)
  } catch (error) {
    // Silently handle errors to prevent breaking the UI
    console.error("Analytics error (non-critical):", error)
    return { success: false, error: "Failed to send analytics" }
  }
}

// Function to get analytics data (for admin dashboard)
export const getAnalyticsEvents = () => {
  return [...analyticsEvents]
}

