"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import { AlertCircle, FileText } from "lucide-react"

// Define types for document headings
export interface DocumentHeading {
  id: string
  text: string
  level: number
  content: string
  styleName: string
}

interface HeadingExtractorProps {
  onHeadingsExtracted?: (headings: DocumentHeading[]) => void
  className?: string
}

export function HeadingExtractor({ onHeadingsExtracted, className = "" }: HeadingExtractorProps) {
  const [file, setFile] = useState<File | null>(null)
  const [headings, setHeadings] = useState<DocumentHeading[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0]

      // Check if file is a DOCX file
      if (!selectedFile.name.endsWith(".docx")) {
        toast({
          title: "Invalid file type",
          description: "Please select a DOCX file",
          variant: "destructive",
        })
        return
      }

      setFile(selectedFile)
      extractHeadings(selectedFile)
    }
  }

  // Handle file drop
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0]

      // Check if file is a DOCX file
      if (!droppedFile.name.endsWith(".docx")) {
        toast({
          title: "Invalid file type",
          description: "Please select a DOCX file",
          variant: "destructive",
        })
        return
      }

      setFile(droppedFile)
      extractHeadings(droppedFile)
    }
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
  }

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)
  }

  // Extract headings from DOCX file
  const extractHeadings = async (file: File) => {
    setIsLoading(true)
    setError(null)

    try {
      // Create form data to send the file
      const formData = new FormData()
      formData.append("file", file)

      // In a real implementation, you would send the file to the API
      // For demonstration, we'll simulate the API response

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Mock extracted headings
      const extractedHeadings: DocumentHeading[] = [
        {
          id: "1",
          text: "Introduction",
          level: 1,
          content: "This is the introduction content...",
          styleName: "Heading1",
        },
        {
          id: "2",
          text: "Background",
          level: 2,
          content: "Background information goes here...",
          styleName: "Heading2",
        },
        {
          id: "3",
          text: "Objectives",
          level: 2,
          content: "The objectives of this document are...",
          styleName: "Heading2",
        },
        {
          id: "4",
          text: "Methodology",
          level: 1,
          content: "The methodology section describes...",
          styleName: "Heading1",
        },
        {
          id: "5",
          text: "Data Collection",
          level: 2,
          content: "Data was collected through...",
          styleName: "Heading2",
        },
        {
          id: "6",
          text: "Survey Design",
          level: 3,
          content: "The survey was designed to...",
          styleName: "Heading3",
        },
        {
          id: "7",
          text: "Results",
          level: 1,
          content: "The results of the analysis show...",
          styleName: "Heading1",
        },
        {
          id: "8",
          text: "Conclusion",
          level: 1,
          content: "In conclusion, we found that...",
          styleName: "Heading1",
        },
      ]

      setHeadings(extractedHeadings)

      // Notify parent component
      if (onHeadingsExtracted) {
        onHeadingsExtracted(extractedHeadings)
      }

      toast({
        title: "Headings extracted",
        description: `Successfully extracted ${extractedHeadings.length} headings from the document.`,
      })
    } catch (err) {
      console.error("Error extracting headings:", err)
      setError(err instanceof Error ? err.message : "Failed to extract headings from the document")

      toast({
        title: "Extraction failed",
        description: err instanceof Error ? err.message : "Failed to extract headings from the document",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Render the drop zone for file upload
  const renderDropZone = () => (
    <div
      onClick={() => fileInputRef.current?.click()}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      className={`border-2 border-dashed rounded-md p-8 text-center cursor-pointer transition-colors ${
        isDragging ? "border-blue-500 bg-blue-100/50" : "border-gray-300 hover:border-gray-400"
      }`}
    >
      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept=".docx" className="hidden" />

      {file ? (
        <div>
          <p className="font-semibold mb-2">Selected file:</p>
          <p className="mb-4">
            {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
          </p>
          <Button
            variant="destructive"
            onClick={(e) => {
              e.stopPropagation()
              setFile(null)
              setHeadings([])
            }}
          >
            Remove File
          </Button>
        </div>
      ) : (
        <>
          <div className="flex justify-center mb-4">
            <FileText size={48} className="text-gray-400" />
          </div>
          <p className="mb-4">Drag and drop a DOCX file here, or click to select a file</p>
          <Button>Select DOCX File</Button>
        </>
      )}
    </div>
  )

  // Render loading state
  if (isLoading) {
    return (
      <Card className={className}>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-3">Extracting headings from document...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Render error state
  if (error) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center text-red-500">
            <AlertCircle className="mr-2" size={20} />
            Error Extracting Headings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">{error}</p>
          {file && (
            <Button onClick={() => extractHeadings(file)} className="mt-2">
              Try Again
            </Button>
          )}
        </CardContent>
      </Card>
    )
  }

  // Render initial state with drop zone
  if (!file || headings.length === 0) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle>Phase 1: Document Heading Extractor</CardTitle>
          <CardDescription>Upload a DOCX file to extract its headings</CardDescription>
        </CardHeader>
        <CardContent>{renderDropZone()}</CardContent>
      </Card>
    )
  }

  // Render extracted headings
  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Phase 1: Extracted Headings</CardTitle>
            <CardDescription>
              {headings.length} headings found in {file.name}
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setFile(null)
              setHeadings([])
            }}
          >
            Change File
          </Button>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-2">
          {headings.map((heading) => (
            <div key={heading.id} className="p-2 border border-gray-200 rounded-md hover:bg-gray-50">
              <div
                className={`${heading.level === 1 ? "font-semibold" : heading.level === 2 ? "font-medium" : ""}`}
                style={{ paddingLeft: `${(heading.level - 1) * 1.5}rem` }}
              >
                {heading.text}
                <Badge
                  variant="outline"
                  className={`ml-2 ${
                    heading.level === 1
                      ? "bg-blue-100 text-blue-800 border-blue-200"
                      : heading.level === 2
                        ? "bg-green-100 text-green-800 border-green-200"
                        : "bg-amber-100 text-amber-800 border-amber-200"
                  }`}
                >
                  H{heading.level}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>

      <CardFooter>
        <Button
          onClick={() => {
            toast({
              title: "Headings ready for Phase 2",
              description: "Proceed to Phase 2 to reorder and organize the headings.",
            })
          }}
          className="w-full"
        >
          Proceed to Phase 2: Drag-and-Drop Reordering
        </Button>
      </CardFooter>
    </Card>
  )
}

