"use client"

import { useState, useEffect } from "react"
import { DragDropContext, Droppable, Draggable, type DropResult } from "react-beautiful-dnd"
import { ChevronDown, ChevronRight, GripVertical, Edit, Trash, Plus, Save, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"
import type { DocumentHeading } from "./phase1-heading-extractor"

interface HeadingOrganizerProps {
  headings: DocumentHeading[]
  onHeadingsReordered?: (headings: DocumentHeading[]) => void
  onHeadingSelected?: (heading: DocumentHeading) => void
  className?: string
}

export function HeadingOrganizer({
  headings: initialHeadings,
  onHeadingsReordered,
  onHeadingSelected,
  className = "",
}: HeadingOrganizerProps) {
  const [headings, setHeadings] = useState<DocumentHeading[]>([])
  const [expandedHeadings, setExpandedHeadings] = useState<Record<string, boolean>>({})
  const [editingHeading, setEditingHeading] = useState<string | null>(null)
  const [editText, setEditText] = useState("")

  // Initialize headings from props
  useEffect(() => {
    setHeadings(initialHeadings)

    // Initialize all headings as expanded
    const expanded: Record<string, boolean> = {}
    initialHeadings.forEach((heading) => {
      expanded[heading.id] = true
    })
    setExpandedHeadings(expanded)
  }, [initialHeadings])

  // Toggle heading expansion
  const toggleHeading = (id: string) => {
    setExpandedHeadings((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  // Start editing a heading
  const startEditHeading = (heading: DocumentHeading) => {
    setEditingHeading(heading.id)
    setEditText(heading.text)
  }

  // Save edited heading
  const saveEditHeading = () => {
    if (!editingHeading) return

    const updatedHeadings = headings.map((heading) => {
      if (heading.id === editingHeading) {
        return { ...heading, text: editText }
      }
      return heading
    })

    setHeadings(updatedHeadings)

    // Reset editing state
    setEditingHeading(null)
    setEditText("")

    toast({
      title: "Heading updated",
      description: "The heading text has been updated successfully.",
    })
  }

  // Cancel editing
  const cancelEditHeading = () => {
    setEditingHeading(null)
    setEditText("")
  }

  // Delete a heading
  const deleteHeading = (id: string) => {
    const updatedHeadings = headings.filter((heading) => heading.id !== id)
    setHeadings(updatedHeadings)

    toast({
      title: "Heading deleted",
      description: "The heading has been removed from the document structure.",
    })
  }

  // Handle drag end event for reordering headings
  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return

    const items = Array.from(headings)
    const [reorderedItem] = items.splice(result.source.index, 1)
    items.splice(result.destination.index, 0, reorderedItem)

    setHeadings(items)

    // Notify parent component
    if (onHeadingsReordered) {
      onHeadingsReordered(items)
    }

    toast({
      title: "Headings reordered",
      description: "The document structure has been updated.",
    })
  }

  // Save the current heading order
  const saveHeadingOrder = () => {
    // In a real implementation, you would send the updated structure to the backend
    toast({
      title: "Order saved",
      description: "The document structure has been saved successfully.",
    })

    // Notify parent component
    if (onHeadingsReordered) {
      onHeadingsReordered(headings)
    }
  }

  // Add a new heading
  const addNewHeading = () => {
    const newHeading: DocumentHeading = {
      id: `new-${Date.now()}`,
      text: "New Heading",
      level: 1,
      content: "",
      styleName: "Heading1",
    }

    setHeadings([...headings, newHeading])

    // Start editing the new heading
    setTimeout(() => {
      startEditHeading(newHeading)
    }, 100)
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Phase 2: Drag-and-Drop Heading Organizer</CardTitle>
        <CardDescription>Drag and drop to reorder headings</CardDescription>
      </CardHeader>

      <CardContent>
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="headings">
            {(provided, snapshot) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className={`space-y-1 p-2 rounded-md ${snapshot.isDraggingOver ? "bg-gray-100" : ""}`}
              >
                {headings.map((heading, index) => (
                  <Draggable key={heading.id} draggableId={heading.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`flex items-center p-2 rounded-md ${
                          snapshot.isDragging
                            ? "bg-gray-50 border border-gray-300 shadow-lg"
                            : "hover:bg-gray-50 border border-gray-200"
                        }`}
                      >
                        <div {...provided.dragHandleProps} className="mr-2 cursor-grab">
                          <GripVertical size={16} className="text-gray-500" />
                        </div>

                        <button
                          onClick={() => toggleHeading(heading.id)}
                          className="mr-1 p-1 rounded-md hover:bg-gray-200"
                        >
                          {expandedHeadings[heading.id] ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                        </button>

                        <div className="flex-1">
                          {editingHeading === heading.id ? (
                            <div className="flex items-center">
                              <input
                                type="text"
                                value={editText}
                                onChange={(e) => setEditText(e.target.value)}
                                className="flex-1 px-2 py-1 rounded-md mr-2 bg-white border-gray-300"
                                autoFocus
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") saveEditHeading()
                                  if (e.key === "Escape") cancelEditHeading()
                                }}
                              />
                              <button
                                onClick={saveEditHeading}
                                className="p-1 rounded-md bg-green-100 hover:bg-green-200 text-green-700"
                              >
                                <Save size={14} />
                              </button>
                              <button
                                onClick={cancelEditHeading}
                                className="p-1 rounded-md ml-1 bg-gray-100 hover:bg-gray-200 text-gray-700"
                              >
                                <X size={14} />
                              </button>
                            </div>
                          ) : (
                            <div
                              className={`${
                                heading.level === 1 ? "font-semibold" : heading.level === 2 ? "font-medium" : ""
                              }`}
                              style={{ paddingLeft: `${(heading.level - 1) * 1.5}rem` }}
                              onClick={() => onHeadingSelected && onHeadingSelected(heading)}
                            >
                              {heading.text}
                              <Badge
                                variant="outline"
                                className={`ml-2 ${
                                  heading.level === 1
                                    ? "bg-blue-100 text-blue-800 border-blue-200"
                                    : heading.level === 2
                                      ? "bg-green-100 text-green-800 border-green-200"
                                      : "bg-amber-100 text-amber-800 border-amber-200"
                                }`}
                              >
                                H{heading.level}
                              </Badge>
                            </div>
                          )}
                        </div>

                        {editingHeading !== heading.id && (
                          <div className="flex space-x-1">
                            <button
                              onClick={() => startEditHeading(heading)}
                              className="p-1 rounded-md hover:bg-gray-200 text-amber-600"
                              title="Edit heading"
                            >
                              <Edit size={14} />
                            </button>
                            <button
                              onClick={() => deleteHeading(heading.id)}
                              className="p-1 rounded-md hover:bg-gray-200 text-red-600"
                              title="Delete heading"
                            >
                              <Trash size={14} />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </CardContent>

      <CardFooter className="flex justify-between">
        <Button variant="outline" size="sm" onClick={addNewHeading} className="flex items-center">
          <Plus size={16} className="mr-1" />
          Add Heading
        </Button>

        <Button size="sm" onClick={saveHeadingOrder} className="flex items-center">
          <Save size={16} className="mr-1" />
          Save Order
        </Button>
      </CardFooter>
    </Card>
  )
}

