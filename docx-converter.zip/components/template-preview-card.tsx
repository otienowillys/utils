"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Template } from "@/lib/types"
import Link from "next/link"

interface TemplatePreviewCardProps {
  template: Template
  onDelete: (id: string) => void
}

export function TemplatePreviewCard({ template, onDelete }: TemplatePreviewCardProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <Card className="h-full overflow-hidden transition-all hover:shadow-md">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl">{template.name}</CardTitle>
          <Badge variant="outline" className="ml-2">
            {template.sections.length} sections
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {template.description || "No description provided"}
        </p>
      </CardHeader>

      <CardContent className="pb-0">
        <div className="flex justify-between items-center mb-2">
          <p className="text-xs text-muted-foreground">Created: {new Date(template.createdAt).toLocaleDateString()}</p>
          <Button variant="ghost" size="sm" className="h-8 px-2" onClick={() => setIsExpanded(!isExpanded)}>
            {isExpanded ? (
              <>
                <ChevronUp className="h-4 w-4 mr-1" />
                <span className="text-xs">Hide sections</span>
              </>
            ) : (
              <>
                <ChevronDown className="h-4 w-4 mr-1" />
                <span className="text-xs">Show sections</span>
              </>
            )}
          </Button>
        </div>

        {isExpanded && (
          <div className="overflow-hidden transition-all duration-300">
            <div className="border rounded-md overflow-hidden mb-4">
              <div className="max-h-48 overflow-y-auto">
                {template.sections.map((section, index) => (
                  <div
                    key={section.id}
                    className={`px-3 py-2 text-sm ${index !== template.sections.length - 1 ? "border-b" : ""}`}
                  >
                    <span className="font-medium">{index + 1}.</span> {section.name}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="flex justify-between pt-4">
        <Button variant="outline" size="sm" asChild>
          <Link href={`/templates/${template.id}`}>
            <Edit className="mr-2 h-4 w-4" /> Edit
          </Link>
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
          onClick={() => onDelete(template.id)}
        >
          <Trash2 className="mr-2 h-4 w-4" /> Delete
        </Button>
      </CardFooter>
    </Card>
  )
}

