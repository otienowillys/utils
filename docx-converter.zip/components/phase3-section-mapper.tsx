"use client"

import { useState, useEffect } from "react"
import type { DocumentHeading } from "./phase1-heading-extractor"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { ArrowRight, Save, RefreshCw, CheckCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import type { Template } from "@/lib/types"

interface SectionMappingItem {
  templateSectionId: string
  documentHeadingId: string
}

interface Phase3SectionMapperProps {
  headings: DocumentHeading[]
  templates: Template[]
  onMappingComplete?: (mapping: SectionMappingItem[], templateId: string) => void
  className?: string
}

export function Phase3SectionMapper({
  headings,
  templates,
  onMappingComplete,
  className = "",
}: Phase3SectionMapperProps) {
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("")
  const [mapping, setMapping] = useState<SectionMappingItem[]>([])
  const [autoMappingApplied, setAutoMappingApplied] = useState(false)
  const [mappingComplete, setMappingComplete] = useState(false)
  const { toast } = useToast()

  // Reset mapping when template or headings change
  useEffect(() => {
    if (selectedTemplateId) {
      // Initialize with empty mapping
      const selectedTemplate = templates.find((t) => t.id === selectedTemplateId)
      if (selectedTemplate) {
        const initialMapping: SectionMappingItem[] = selectedTemplate.sections.map((section) => ({
          templateSectionId: section.id,
          documentHeadingId: "",
        }))
        setMapping(initialMapping)
        setAutoMappingApplied(false)
        setMappingComplete(false)
      }
    }
  }, [selectedTemplateId, templates])

  const selectedTemplate = templates.find((t) => t.id === selectedTemplateId)

  // Handle template selection
  const handleTemplateChange = (templateId: string) => {
    setSelectedTemplateId(templateId)
  }

  // Handle mapping change
  const handleMappingChange = (templateSectionId: string, documentHeadingId: string) => {
    setMapping((prevMapping) =>
      prevMapping.map((item) => (item.templateSectionId === templateSectionId ? { ...item, documentHeadingId } : item)),
    )
  }

  // Apply automatic mapping based on heading text similarity
  const applyAutoMapping = () => {
    if (!selectedTemplate) return

    const newMapping: SectionMappingItem[] = [...mapping]

    // Simple algorithm to match headings to template sections based on text similarity
    selectedTemplate.sections.forEach((section, sIndex) => {
      const sectionName = section.name.toLowerCase()

      // Find the best matching heading
      let bestMatch: { headingId: string; score: number } = { headingId: "", score: 0 }

      headings.forEach((heading) => {
        const headingText = heading.text.toLowerCase()

        // Calculate simple similarity score (contains words)
        const sectionWords = sectionName.split(/\s+/)
        const headingWords = headingText.split(/\s+/)

        let matchScore = 0
        sectionWords.forEach((word) => {
          if (word.length > 3 && headingText.includes(word)) {
            matchScore += 1
          }
        })

        headingWords.forEach((word) => {
          if (word.length > 3 && sectionName.includes(word)) {
            matchScore += 1
          }
        })

        // Exact match gets high score
        if (headingText === sectionName) {
          matchScore = 100
        }

        // If this is a better match than what we have
        if (matchScore > bestMatch.score) {
          bestMatch = { headingId: heading.id, score: matchScore }
        }
      })

      // If we found a decent match
      if (bestMatch.score > 0) {
        newMapping[sIndex].documentHeadingId = bestMatch.headingId
      }
    })

    setMapping(newMapping)
    setAutoMappingApplied(true)

    toast({
      title: "Auto-mapping applied",
      description: "Sections have been automatically mapped based on content similarity.",
    })
  }

  // Save the mapping
  const saveMapping = () => {
    if (!selectedTemplateId) {
      toast({
        title: "Error",
        description: "Please select a template first",
        variant: "destructive",
      })
      return
    }

    // Check if all template sections are mapped
    const unmappedSections = mapping.filter((item) => !item.documentHeadingId)
    if (unmappedSections.length > 0) {
      toast({
        title: "Warning",
        description: `${unmappedSections.length} template sections are not mapped. Continue anyway?`,
        variant: "destructive",
        action: (
          <Button
            variant="outline"
            onClick={() => {
              if (onMappingComplete) {
                onMappingComplete(mapping, selectedTemplateId)
              }
              setMappingComplete(true)
              toast({
                title: "Mapping saved",
                description: "Your section mapping has been saved successfully.",
              })
            }}
          >
            Continue
          </Button>
        ),
      })
      return
    }

    // All sections are mapped, proceed
    if (onMappingComplete) {
      onMappingComplete(mapping, selectedTemplateId)
    }

    setMappingComplete(true)
    toast({
      title: "Mapping saved",
      description: "Your section mapping has been saved successfully.",
    })
  }

  // Get heading by ID
  const getHeadingById = (id: string) => {
    return headings.find((h) => h.id === id)
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Phase 3: Map Sections to Template</span>
          {mappingComplete && (
            <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
              <CheckCircle size={14} />
              <span>Mapping Complete</span>
            </Badge>
          )}
        </CardTitle>
        <CardDescription>Map your document headings to template sections</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Template selector */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Select Template</label>
          <Select value={selectedTemplateId} onValueChange={handleTemplateChange}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Choose a template" />
            </SelectTrigger>
            <SelectContent>
              {templates.map((template) => (
                <SelectItem key={template.id} value={template.id}>
                  {template.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedTemplate ? (
          <>
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-medium">Section Mapping</h3>
              <Button variant="outline" size="sm" onClick={applyAutoMapping} className="flex items-center">
                <RefreshCw size={14} className="mr-1" />
                Auto-Map
              </Button>
            </div>

            <div className="space-y-3">
              {mapping.map((item, index) => {
                const templateSection = selectedTemplate.sections.find((s) => s.id === item.templateSectionId)

                if (!templateSection) return null

                return (
                  <div key={item.templateSectionId} className="p-3 border rounded-md bg-gray-50">
                    <div className="flex items-center mb-2">
                      <div className="font-medium">{templateSection.name}</div>
                      <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700 border-blue-200">
                        Template Section
                      </Badge>
                    </div>

                    <div className="flex items-center">
                      <Select
                        value={item.documentHeadingId || "none"}
                        onValueChange={(value) =>
                          handleMappingChange(item.templateSectionId, value === "none" ? "" : value)
                        }
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select a document heading" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">-- None --</SelectItem>
                          {headings.map((heading) => (
                            <SelectItem key={heading.id} value={heading.id}>
                              {heading.text} (H{heading.level})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <ArrowRight size={20} className="mx-2 text-gray-400" />

                      <div className="flex-1 p-2 min-h-[40px] border rounded bg-white">
                        {item.documentHeadingId ? (
                          <div className="flex items-center">
                            <span>{getHeadingById(item.documentHeadingId)?.text}</span>
                            <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
                              H{getHeadingById(item.documentHeadingId)?.level}
                            </Badge>
                          </div>
                        ) : (
                          <span className="text-gray-400">No heading selected</span>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </>
        ) : (
          <div className="text-center py-8 text-gray-500">Please select a template to start mapping sections</div>
        )}

        {mappingComplete && (
          <div className="bg-green-50 border border-green-200 rounded-md p-4 text-green-800">
            <h3 className="font-medium mb-2 flex items-center">
              <CheckCircle size={16} className="mr-2" />
              Mapping Complete
            </h3>
            <p className="text-sm">
              Your document sections have been successfully mapped to the template. You can now proceed with the
              document conversion.
            </p>
            <div className="mt-3">
              <Button
                variant="outline"
                className="bg-white text-green-700 border-green-300 hover:bg-green-50"
                onClick={() => {
                  toast({
                    title: "Starting conversion",
                    description: "Your document is being converted based on the mapping.",
                  })
                }}
              >
                Convert Document
              </Button>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="flex justify-end">
        {!mappingComplete && (
          <Button onClick={saveMapping} disabled={!selectedTemplateId} className="flex items-center">
            <Save size={16} className="mr-1" />
            Save Mapping
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

