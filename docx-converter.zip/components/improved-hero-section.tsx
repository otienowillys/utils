"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowRight, FileText, Zap, CheckCircle, LayoutTemplate, GitMerge, Settings, FileOutput } from "lucide-react"

export function ImprovedHeroSection() {
  const [isMounted, setIsMounted] = useState(false)
  const [showDetails, setShowDetails] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Prevent hydration mismatch by not rendering anything until client-side
  if (!isMounted) {
    return null
  }

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-background to-background/80 dark:from-background dark:to-background/80 py-20 sm:py-32">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-slate-200/50 dark:bg-grid-slate-800/20 bg-[bottom_1px_center] [mask-image:linear-gradient(to_bottom,transparent,black,transparent)]" />

      <div className="relative container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-indigo-500/10 px-3 py-1 text-sm text-indigo-500 dark:bg-indigo-500/20">
                Introducing DOCX Converter
              </div>

              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                Transform your documents <br className="hidden sm:inline" />
                <span className="text-indigo-500">with precision and ease</span>
              </h1>

              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Convert, reformat, and restructure your DOCX files with our powerful template-based system. Save time
                and ensure consistency across all your documents.
              </p>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row mt-6">
              {/* Get Started Button */}
              <Link
                href="/login"
                className="inline-flex items-center justify-center rounded-md bg-indigo-600 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200 group"
              >
                Get Started
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>

              {/* Learn More Button */}
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="inline-flex items-center justify-center rounded-md bg-white px-6 py-3 text-base font-medium text-gray-700 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200 dark:bg-gray-800 dark:text-gray-200 dark:ring-gray-700 dark:hover:bg-gray-700"
              >
                Learn More
              </button>
            </div>

            <div className="flex items-center gap-4 text-sm mt-4">
              <div className="flex items-center gap-1">
                <Zap className="h-4 w-4 text-indigo-500" />
                <span>Lightning fast</span>
              </div>
              <div className="flex items-center gap-1">
                <FileText className="h-4 w-4 text-indigo-500" />
                <span>Template-based</span>
              </div>
            </div>
          </div>

          <div className="mx-auto flex items-center justify-center lg:justify-end">
            <div className="relative w-full max-w-[500px] aspect-square">
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 opacity-20 blur-3xl" />
              <div className="relative rounded-xl overflow-hidden border shadow-2xl">
                <img
                  src="/placeholder.svg?height=600&width=600"
                  alt="DOCX Converter Dashboard"
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Features Section */}
      {showDetails && (
        <div className="relative container px-4 md:px-6 mt-16 animate-fadeIn">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {/* Feature 1: Templates */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 transition-all hover:shadow-xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
                  <LayoutTemplate className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
                </div>
                <h3 className="text-xl font-semibold">Customizable Templates</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Pre-built templates for reports, proposals, and academic papers</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Create and save your own custom templates</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Define sections, styles, and formatting rules</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Share templates with your team for consistent documents</span>
                </li>
              </ul>
            </div>

            {/* Feature 2: Section Mapping */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 transition-all hover:shadow-xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                  <GitMerge className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                </div>
                <h3 className="text-xl font-semibold">Intelligent Mapping</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Automatically identify document sections</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Predefined mappings for common document types</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Custom mapping rules for specialized documents</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Save and reuse mappings for similar documents</span>
                </li>
              </ul>
            </div>

            {/* Feature 3: Advanced Capabilities */}
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 transition-all hover:shadow-xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                  <Settings className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold">Advanced Features</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Batch processing for multiple documents</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Style preservation and transformation</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Content extraction and reorganization</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Export to multiple formats (DOCX, PDF, HTML)</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Output Formats */}
          <div className="mt-12 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30 rounded-xl p-6 shadow-lg border border-indigo-100 dark:border-indigo-900">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
                <FileOutput className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
              </div>
              <h3 className="text-xl font-semibold">Supported Output Formats</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center shadow border border-gray-200 dark:border-gray-700">
                <span className="font-medium">DOCX</span>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center shadow border border-gray-200 dark:border-gray-700">
                <span className="font-medium">PDF</span>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center shadow border border-gray-200 dark:border-gray-700">
                <span className="font-medium">HTML</span>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center shadow border border-gray-200 dark:border-gray-700">
                <span className="font-medium">Markdown</span>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="mt-12 text-center">
            <Link
              href="/login"
              className="inline-flex items-center justify-center rounded-md bg-indigo-600 px-8 py-4 text-lg font-medium text-white shadow-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200 group"
            >
              Start Converting Now
              <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}

