"use client"

import type React from "react"

import { useState, useRef, useCallback, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { FileText, Upload, X, AlertCircle, CheckCircle2 } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"

interface AnimatedFileUploaderProps {
  multiple?: boolean
  onChange: (files: File[]) => void
  accept?: string
  maxFiles?: number
  maxSize?: number // in MB
  onUploadProgress?: (progress: number) => void
}

export function AnimatedFileUploader({
  multiple = false,
  onChange,
  accept = ".docx",
  maxFiles = 10,
  maxSize = 25,
  onUploadProgress,
}: AnimatedFileUploaderProps) {
  const [files, setFiles] = useState<File[]>([])
  const [isDragging, setIsDragging] = useState(false)
  const [fileErrors, setFileErrors] = useState<Record<string, string>>({})
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({})
  const [isMounted, setIsMounted] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const validateFile = useCallback(
    (file: File): string | null => {
      // Check file type
      if (!file.name.endsWith(".docx")) {
        return "Only DOCX files are allowed"
      }

      // Check file size
      if (file.size > maxSize * 1024 * 1024) {
        return `File size exceeds the ${maxSize}MB limit`
      }

      return null
    },
    [maxSize],
  )

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return

    const newFiles = Array.from(e.target.files)
    processFiles(newFiles)
  }, [])

  const processFiles = useCallback(
    (newFiles: File[]) => {
      const errors: Record<string, string> = {}
      const validFiles: File[] = []
      const progressMap: Record<string, number> = {}

      // Validate each file
      newFiles.forEach((file) => {
        const error = validateFile(file)
        if (error) {
          errors[file.name] = error
        } else {
          validFiles.push(file)
          progressMap[file.name] = 0
        }
      })

      // Handle single file mode
      if (!multiple) {
        if (validFiles.length > 0) {
          setFiles([validFiles[0]])
          setUploadProgress({ [validFiles[0].name]: 0 })
          onChange([validFiles[0]])
        }
      } else {
        // Handle multiple files mode
        const combinedFiles = [...files, ...validFiles]
        if (combinedFiles.length > maxFiles) {
          errors["tooMany"] = `Maximum ${maxFiles} files allowed`
          return
        }

        setFiles(combinedFiles)
        setUploadProgress((prev) => ({ ...prev, ...progressMap }))
        onChange(combinedFiles)
      }

      setFileErrors(errors)
    },
    [files, maxFiles, multiple, onChange, validateFile],
  )

  // Simulate upload progress for demonstration
  const simulateProgress = useCallback(
    (fileName: string) => {
      let progress = 0
      const interval = setInterval(() => {
        progress += Math.random() * 10
        if (progress > 100) {
          progress = 100
          clearInterval(interval)
        }

        setUploadProgress((prev) => ({
          ...prev,
          [fileName]: Math.floor(progress),
        }))

        if (onUploadProgress) {
          const avgProgress =
            Object.values(uploadProgress).reduce((sum, val) => sum + val, 0) / Object.values(uploadProgress).length
          onUploadProgress(avgProgress)
        }
      }, 300)
    },
    [onUploadProgress, uploadProgress],
  )

  useEffect(() => {
    if (isMounted) {
      // Start simulating progress when files change
      files.forEach((file) => {
        if (uploadProgress[file.name] === 0) {
          simulateProgress(file.name)
        }
      })
    }
  }, [files, simulateProgress, uploadProgress, isMounted])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback(() => {
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)

      if (!e.dataTransfer.files?.length) return

      const newFiles = Array.from(e.dataTransfer.files)
      processFiles(newFiles)
    },
    [processFiles],
  )

  const removeFile = useCallback(
    (index: number) => {
      const newFiles = [...files]
      const removedFile = newFiles[index]
      newFiles.splice(index, 1)

      setFiles(newFiles)
      onChange(newFiles)

      // Remove from progress tracking
      setUploadProgress((prev) => {
        const updated = { ...prev }
        delete updated[removedFile.name]
        return updated
      })

      // Remove from errors if present
      setFileErrors((prev) => {
        const updated = { ...prev }
        delete updated[removedFile.name]
        return updated
      })
    },
    [files, onChange],
  )

  const clearFiles = useCallback(() => {
    setFiles([])
    setUploadProgress({})
    setFileErrors({})
    onChange([])
    if (inputRef.current) {
      inputRef.current.value = ""
    }
  }, [onChange])

  // For server-side rendering, return a minimal placeholder
  if (!isMounted) {
    return <div className="space-y-4">Loading file uploader...</div>
  }

  return (
    <div className="space-y-4">
      <div
        className={cn(
          "border-2 border-dashed rounded-lg p-6 text-center transition-colors hover:border-brand-500 hover:bg-brand-500/5",
          isDragging ? "border-brand-500 bg-brand-500/5" : "border-muted-foreground/25",
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <Input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          onChange={handleFileChange}
          className="hidden"
          id="file-upload"
        />
        <div className="flex flex-col items-center justify-center gap-2">
          <Upload className="h-10 w-10 text-muted-foreground" />
          <h3 className="text-lg font-medium">Drag and drop your file{multiple ? "s" : ""} here</h3>
          <p className="text-sm text-muted-foreground">or click to browse</p>
          <Button variant="secondary" onClick={() => inputRef.current?.click()} className="mt-2">
            Select File{multiple ? "s" : ""}
          </Button>
          <p className="text-xs text-muted-foreground mt-2">
            Only .docx files are supported. Maximum file size: {maxSize}MB
          </p>
        </div>
      </div>

      {files.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium">
              {files.length} file{files.length > 1 ? "s" : ""} selected
            </h4>
            <Button variant="ghost" size="sm" onClick={clearFiles} className="h-8 px-2 text-xs">
              Clear all
            </Button>
          </div>
          <div className="space-y-2 max-h-60 overflow-y-auto p-2 border rounded-md">
            {files.map((file, index) => (
              <div key={`${file.name}-${index}`} className="flex flex-col p-2 bg-muted/50 rounded-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 truncate">
                    <FileText className="h-4 w-4 flex-shrink-0" />
                    <span className="text-sm truncate">{file.name}</span>
                    <span className="text-xs text-muted-foreground">({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeFile(index)} className="h-6 w-6">
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="mt-2">
                  <Progress value={uploadProgress[file.name] || 0} className="h-1" />
                </div>
                {uploadProgress[file.name] === 100 && (
                  <div className="flex items-center gap-1 text-xs text-success-600 mt-1">
                    <CheckCircle2 className="h-3 w-3" />
                    <span>Upload complete</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {Object.keys(fileErrors).length > 0 && (
            <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-md">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="h-4 w-4 text-destructive" />
                <h4 className="text-sm font-medium text-destructive">File errors</h4>
              </div>
              <ul className="space-y-1 text-sm">
                {Object.entries(fileErrors).map(([fileName, error]) => (
                  <li key={fileName} className="flex items-start gap-2">
                    <span className="font-medium">{fileName !== "tooMany" ? fileName : ""}:</span>
                    <span>{error}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

