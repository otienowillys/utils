"use client"
import type { Template } from "@/lib/types"

interface DarkTemplatePreviewProps {
  template: Template | null
}

export function DarkTemplatePreview({ template }: DarkTemplatePreviewProps) {
  if (!template) {
    return null
  }

  return (
    <div
      style={{
        backgroundColor: "#1e293b", // slate-800
        borderRadius: "0.5rem",
        padding: "1rem",
        marginBottom: "2rem",
        border: "1px solid #334155", // slate-700
      }}
    >
      <h3
        style={{
          fontSize: "1rem",
          marginBottom: "0.75rem",
          color: "white",
          fontWeight: "500",
        }}
      >
        Template Preview
      </h3>
      <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
        {template.sections.map((section) => (
          <div
            key={section.id}
            style={{
              padding: "0.75rem",
              backgroundColor: "#334155", // slate-700
              borderRadius: "0.25rem",
              border: "1px solid #475569", // slate-600
              color: "white",
              fontWeight: "400",
            }}
          >
            {section.name}
          </div>
        ))}
      </div>
    </div>
  )
}

