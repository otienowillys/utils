"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"

export function RecentConversions() {
  const [conversions, setConversions] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Fetch recent conversions from localStorage
    const fetchConversions = async () => {
      try {
        // Simulate network delay
        await new Promise((resolve) => setTimeout(resolve, 300))

        // Get conversions from localStorage
        const storedConversionsJSON = localStorage.getItem("recentConversions")

        if (storedConversionsJSON) {
          try {
            const storedConversions = JSON.parse(storedConversionsJSON)
            if (Array.isArray(storedConversions) && storedConversions.length > 0) {
              // Format dates for display
              const formattedConversions = storedConversions.map((conv) => ({
                ...conv,
                date: new Date(conv.date).toLocaleDateString(),
              }))
              setConversions(formattedConversions)
            } else {
              // Fall back to mock data if no conversions found
              setConversions([
                { id: "1", filename: "report.docx", status: "completed", date: "2023-12-15" },
                { id: "2", filename: "contract.docx", status: "completed", date: "2023-12-12" },
                { id: "3", filename: "proposal.docx", status: "failed", date: "2023-12-10" },
              ])
            }
          } catch (error) {
            console.error("Error parsing conversions from localStorage:", error)
            // Fall back to mock data
            setConversions([
              { id: "1", filename: "report.docx", status: "completed", date: "2023-12-15" },
              { id: "2", filename: "contract.docx", status: "completed", date: "2023-12-12" },
              { id: "3", filename: "proposal.docx", status: "failed", date: "2023-12-10" },
            ])
          }
        } else {
          // Fall back to mock data if no conversions in localStorage
          setConversions([
            { id: "1", filename: "report.docx", status: "completed", date: "2023-12-15" },
            { id: "2", filename: "contract.docx", status: "completed", date: "2023-12-12" },
            { id: "3", filename: "proposal.docx", status: "failed", date: "2023-12-10" },
          ])
        }
      } catch (error) {
        console.error("Error fetching conversions:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchConversions()
  }, [])

  const handleDelete = (id) => {
    // Get current conversions from localStorage
    const storedConversionsJSON = localStorage.getItem("recentConversions")
    let storedConversions = []

    try {
      storedConversions = storedConversionsJSON ? JSON.parse(storedConversionsJSON) : []
    } catch (error) {
      console.error("Error parsing conversions:", error)
    }

    // Filter out the conversion to delete
    const updatedConversions = storedConversions.filter((conv) => conv.id !== id)

    // Save back to localStorage
    localStorage.setItem("recentConversions", JSON.stringify(updatedConversions))

    // Update state
    setConversions((prev) => prev.filter((conv) => conv.id !== id))
  }

  if (loading) {
    return (
      <div className="flex justify-center py-4">
        <div className="animate-spin h-6 w-6 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    )
  }

  if (conversions.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-sm text-muted-foreground">No recent conversions found.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {conversions.map((conversion) => (
        <div key={conversion.id} className="flex items-center justify-between p-3 bg-muted/40 rounded-md">
          <div>
            <p className="font-medium">{conversion.filename}</p>
            <p className="text-sm text-muted-foreground">{conversion.date}</p>
          </div>
          <div className="flex items-center gap-3">
            <span
              className={`text-xs px-2 py-1 rounded-full ${
                conversion.status === "completed"
                  ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                  : "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300"
              }`}
            >
              {conversion.status}
            </span>
            <Button
              variant="ghost"
              size="sm"
              className="text-destructive hover:text-destructive/80 hover:bg-background"
              onClick={() => handleDelete(conversion.id)}
            >
              Delete
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}

