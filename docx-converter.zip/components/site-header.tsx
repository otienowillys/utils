"use client"

import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"

export function SiteHeader() {
  const router = useRouter()
  // Initialize with a default value to avoid hydration mismatch
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)

    // Check authentication status after mount
    try {
      setIsAuthenticated(localStorage?.getItem("isAuthenticated") === "true")
    } catch (e) {
      console.error("Failed to access localStorage:", e)
    }

    // Listen for auth changes
    const handleStorageChange = () => {
      try {
        setIsAuthenticated(localStorage?.getItem("isAuthenticated") === "true")
      } catch (e) {
        console.error("Failed to access localStorage:", e)
      }
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("auth-change", handleStorageChange)

    // Improved cleanup function
    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("auth-change", handleStorageChange)
    }
  }, [])

  const handleLogout = () => {
    try {
      localStorage.removeItem("isAuthenticated")
      setIsAuthenticated(false)

      // Use setTimeout to ensure state updates complete before navigation
      setTimeout(() => {
        window.dispatchEvent(new Event("auth-change"))
        router.push("/login")
      }, 0)
    } catch (e) {
      console.error("Failed to logout:", e)
    }
  }

  // Render a simplified header for SSR
  if (!isMounted) {
    return (
      <header className="sticky top-0 z-50 w-full border-b bg-background">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="font-bold text-xl">DOCX Converter</span>
          </div>
          <div className="flex items-center gap-4">
            <ThemeToggle />
          </div>
        </div>
      </header>
    )
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="font-bold text-xl">
            DOCX Converter
          </Link>
          <nav className="hidden md:flex gap-6">
            {isAuthenticated ? (
              <>
                <Link href="/dashboard" className="text-sm font-medium hover:underline">
                  Dashboard
                </Link>
                <Link href="/convert" className="text-sm font-medium hover:underline">
                  Convert
                </Link>
                <Link href="/templates" className="text-sm font-medium hover:underline">
                  Templates
                </Link>
              </>
            ) : (
              <>
                <Link href="/features" className="text-sm font-medium hover:underline">
                  Features
                </Link>
                <Link href="/about" className="text-sm font-medium hover:underline">
                  About
                </Link>
              </>
            )}
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <ThemeToggle />

          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg" alt="User" />
                    <AvatarFallback>U</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/dashboard">Dashboard</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/profile">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>Log out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild size="sm">
              <Link href="/login">Sign In</Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  )
}

