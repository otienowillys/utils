"use client"

import { useEffect } from "react"
import { useToast } from "@/components/ui/use-toast"

export default function ServiceWorkerRegistration() {
  const { toast } = useToast()

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("/sw.js").then(
          (registration) => {
            console.log("ServiceWorker registration successful with scope: ", registration.scope)

            // Check for updates
            registration.addEventListener("updatefound", () => {
              const newWorker = registration.installing
              if (newWorker) {
                newWorker.addEventListener("statechange", () => {
                  if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
                    toast({
                      title: "New version available",
                      description: "Refresh the page to update to the latest version",
                      action: (
                        <button
                          onClick={() => window.location.reload()}
                          className="bg-primary text-white px-3 py-1 rounded-md text-sm"
                        >
                          Refresh
                        </button>
                      ),
                      duration: 10000,
                    })
                  }
                })
              }
            })
          },
          (err) => {
            console.log("ServiceWorker registration failed: ", err)
          },
        )
      })
    }
  }, [toast])

  return null
}

