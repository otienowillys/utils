"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, FileText, Zap } from "lucide-react"
import Link from "next/link"

export function HeroSection() {
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Prevent hydration mismatch by not rendering anything until client-side
  if (!isMounted) {
    return null
  }

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-background to-background/80 dark:from-background dark:to-background/80 py-20 sm:py-32">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-slate-200/50 dark:bg-grid-slate-800/20 bg-[bottom_1px_center] [mask-image:linear-gradient(to_bottom,transparent,black,transparent)]" />

      <div className="relative container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-brand-500/10 px-3 py-1 text-sm text-brand-500 dark:bg-brand-500/20">
                Introducing DOCX Converter
              </div>

              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                Transform your documents <br className="hidden sm:inline" />
                <span className="text-brand-500">with precision and ease</span>
              </h1>

              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                Convert, reformat, and restructure your DOCX files with our powerful template-based system. Save time
                and ensure consistency across all your documents.
              </p>
            </div>

            <div className="flex flex-col gap-2 min-[400px]:flex-row mt-6">
              <Button
                size="lg"
                className="group bg-indigo-600 hover:bg-indigo-700 text-white font-medium px-6 py-3 rounded-md shadow-lg hover:shadow-xl transition-all duration-200"
                asChild
              >
                <Link href="/login">
                  Get Started
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-gray-300 dark:border-gray-700 hover:border-indigo-600 dark:hover:border-indigo-500 font-medium px-6 py-3 rounded-md transition-all duration-200"
                asChild
              >
                <Link href="/theme-demo">Learn More</Link>
              </Button>
            </div>

            <div className="flex items-center gap-4 text-sm mt-4">
              <div className="flex items-center gap-1">
                <Zap className="h-4 w-4 text-brand-500" />
                <span>Lightning fast</span>
              </div>
              <div className="flex items-center gap-1">
                <FileText className="h-4 w-4 text-brand-500" />
                <span>Template-based</span>
              </div>
            </div>
          </div>

          <div className="mx-auto flex items-center justify-center lg:justify-end">
            <div className="relative w-full max-w-[500px] aspect-square">
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-brand-500 to-purple-500 opacity-20 blur-3xl" />
              <div className="relative rounded-xl overflow-hidden border shadow-2xl">
                <img
                  src="/placeholder.svg?height=600&width=600"
                  alt="DOCX Converter Dashboard"
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

