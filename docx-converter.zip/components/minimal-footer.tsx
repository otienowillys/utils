export function MinimalFooter() {
  return (
    <footer className="py-6 md:py-0 md:h-14 border-t bg-background">
      <div className="container flex h-full items-center justify-center">
        <p className="text-sm text-muted-foreground">© 2025 DOCX Converter</p>
      </div>
    </footer>
  )
}

