"use client"

import { useState, useEffect } from "react"
import type { Section } from "@/lib/types"
import { DarkPredefinedMappings } from "./dark-predefined-mappings"

interface DarkSectionMapperProps {
  templateSections: Section[]
  onChange: (mapping: Record<string, string>) => void
}

export function DarkSectionMapper({ templateSections, onChange }: DarkSectionMapperProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [mapping, setMapping] = useState<Record<string, string>>({})
  const [availableSections] = useState<string[]>([
    "Introduction",
    "Background",
    "Methodology",
    "Results",
    "Discussion",
    "Conclusion",
    "References",
    "Appendix",
    "Executive Summary",
    "Literature Review",
    "Methods",
    "Findings",
    "Recommendations",
    "Abstract",
    "Overview",
    "Requirements",
    "Architecture",
    "Implementation",
    "API Reference",
    "Examples",
    "Company Overview",
    "Market Analysis",
    "Competitive Analysis",
    "Products and Services",
    "Marketing Strategy",
    "Financial Projections",
    "Funding Request",
  ])

  // Ensure hydration safety
  useEffect(() => {
    setIsMounted(true)
  }, [])

  const handleMappingChange = (sectionId: string, value: string) => {
    const newMapping = { ...mapping, [sectionId]: value }
    setMapping(newMapping)
    onChange(newMapping)
  }

  const handleApplyPredefinedMapping = (newMapping: Record<string, string>) => {
    setMapping(newMapping)
    onChange(newMapping)
  }

  // Don't render anything during SSR or before hydration
  if (!isMounted) {
    return null
  }

  return (
    <div className="space-y-4">
      <DarkPredefinedMappings templateSections={templateSections} onApplyMapping={handleApplyPredefinedMapping} />

      {templateSections.map((section) => (
        <div
          key={section.id}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            backgroundColor: "#334155", // slate-700
            borderRadius: "0.375rem",
            height: "4rem",
            border: "1px solid #475569", // slate-600
            boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)",
            marginBottom: "1rem",
          }}
        >
          <div
            style={{
              flex: "1",
              paddingLeft: "1rem",
              fontWeight: "500",
              color: "white",
            }}
          >
            {section.name}
          </div>
          <div style={{ width: "20rem", paddingRight: "1rem" }}>
            <select
              value={mapping[section.id] || ""}
              onChange={(e) => handleMappingChange(section.id, e.target.value)}
              style={{
                width: "100%",
                padding: "0.5rem",
                borderRadius: "0.25rem",
                backgroundColor: "#1e293b", // slate-800
                color: "white",
                border: "1px solid #475569", // slate-600
                outline: "none",
              }}
            >
              <option value="" style={{ backgroundColor: "#1e293b", color: "white" }}>
                Select section
              </option>
              {availableSections.map((name) => (
                <option key={name} value={name} style={{ backgroundColor: "#1e293b", color: "white" }}>
                  {name}
                </option>
              ))}
            </select>
          </div>
        </div>
      ))}
    </div>
  )
}

