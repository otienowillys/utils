"use client"

import { useState } from "react"
import { AlertCircle, CheckCircle2, Download, FileText, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { ConversionResult } from "@/lib/types"

interface ConversionResultsProps {
  results: ConversionResult[]
  isProcessing: boolean
  progress: number
}

export function ConversionResults({ results, isProcessing, progress }: ConversionResultsProps) {
  const [downloadingFiles, setDownloadingFiles] = useState<Record<string, boolean>>({})

  // Update the handleDownload function to handle different file types appropriately
  const handleDownload = async (result: ConversionResult) => {
    if (!result.downloadUrl) return

    // Set downloading state
    setDownloadingFiles((prev) => ({ ...prev, [result.id]: true }))

    try {
      // In a real app, you'd fetch the file here
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Create a temporary anchor element
      const a = document.createElement("a")
      a.href = result.downloadUrl

      // Set the correct filename with extension
      const filename = result.convertedFilename || `converted-file.${result.format}`
      a.download = filename

      // For HTML files, we might want to open in a new tab instead
      if (result.format === "html") {
        a.target = "_blank"
      }

      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
    } catch (error) {
      console.error("Download error:", error)
    } finally {
      // Reset downloading state
      setDownloadingFiles((prev) => ({ ...prev, [result.id]: false }))
    }
  }

  return (
    <Card className="overflow-hidden mt-6">
      <CardHeader className="bg-muted/50">
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-brand-500" />
          Conversion Results
        </CardTitle>
      </CardHeader>

      <CardContent className="p-0">
        {isProcessing && (
          <div className="p-6 space-y-4">
            <div className="flex items-center gap-3">
              <Loader2 className="h-5 w-5 animate-spin text-brand-500" />
              <p className="font-medium">Processing your document{results.length > 1 ? "s" : ""}...</p>
            </div>

            <div className="space-y-1">
              <Progress value={progress} className="h-2" />
              <p className="text-xs text-right text-muted-foreground">{progress}% complete</p>
            </div>
          </div>
        )}

        {results.length > 0 && (
          <div className="divide-y">
            {results.map((result) => (
              <div key={result.id} className="flex items-center justify-between p-4">
                <div className="flex items-center gap-3">
                  {result.status === "success" || result.status === "completed" ? (
                    <div className="h-10 w-10 rounded-full bg-success-50 flex items-center justify-center">
                      <CheckCircle2 className="h-5 w-5 text-success-600" />
                    </div>
                  ) : (
                    <div className="h-10 w-10 rounded-full bg-destructive/10 flex items-center justify-center">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                    </div>
                  )}

                  <div>
                    <p className="font-medium">{result.convertedFilename || result.filename}</p>
                    {result.message && <p className="text-sm text-muted-foreground">{result.message}</p>}
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-muted rounded-full text-xs font-medium">
                        {result.format.toUpperCase()}
                      </span>
                      <span>{(result.size / (1024 * 1024)).toFixed(2)} MB</span>
                    </div>
                  </div>
                </div>

                {(result.status === "success" || result.status === "completed") && result.downloadUrl && (
                  <Button size="sm" onClick={() => handleDownload(result)} disabled={downloadingFiles[result.id]}>
                    {downloadingFiles[result.id] ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Downloading...
                      </>
                    ) : (
                      <>
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </>
                    )}
                  </Button>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

