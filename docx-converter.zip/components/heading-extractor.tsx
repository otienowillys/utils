"use client"

import { useState, useEffect } from "react"
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd"
import { ChevronDown, ChevronRight, GripVertical, Edit, Trash, Plus, Save } from "lucide-react"

// Define types for document headings
interface DocumentHeading {
  id: string
  text: string
  level: number
  content: string
  children: DocumentHeading[]
  styleName: string
}

interface HeadingExtractorProps {
  docxFile: File | null
  onHeadingsExtracted?: (headings: DocumentHeading[]) => void
  onHeadingsReordered?: (headings: DocumentHeading[]) => void
  className?: string
  isDarkMode?: boolean
}

export function HeadingExtractor({
  docxFile,
  onHeadingsExtracted,
  onHeadingsReordered,
  className = "",
  isDarkMode = false,
}: HeadingExtractorProps) {
  const [headings, setHeadings] = useState<DocumentHeading[]>([])
  const [flatHeadings, setFlatHeadings] = useState<DocumentHeading[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [expandedHeadings, setExpandedHeadings] = useState<Record<string, boolean>>({})

  // Extract headings when docxFile changes
  useEffect(() => {
    if (docxFile) {
      extractHeadings(docxFile)
    }
  }, [docxFile])

  // Convert hierarchical headings to flat list for drag and drop
  useEffect(() => {
    const flat: DocumentHeading[] = []

    const flattenHeadings = (headingList: DocumentHeading[], level = 0) => {
      headingList.forEach((heading) => {
        // Create a copy without children to avoid circular references
        const headingCopy = { ...heading, children: [] }
        flat.push(headingCopy)

        if (heading.children && heading.children.length > 0) {
          flattenHeadings(heading.children, level + 1)
        }
      })
    }

    flattenHeadings(headings)
    setFlatHeadings(flat)
  }, [headings])

  // Extract headings from DOCX file
  const extractHeadings = async (file: File) => {
    setIsLoading(true)
    setError(null)

    try {
      // Create form data to send the file
      const formData = new FormData()
      formData.append("file", file)

      // Simulate API call for now (in a real app, this would call the backend)
      // For demo purposes, we'll create some mock headings
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Mock headings for demonstration
      const mockHeadings: DocumentHeading[] = [
        {
          id: "1",
          text: "Introduction",
          level: 1,
          content: "This is the introduction content...",
          styleName: "Heading1",
          children: [
            {
              id: "2",
              text: "Background",
              level: 2,
              content: "Background information goes here...",
              styleName: "Heading2",
              children: [],
            },
            {
              id: "3",
              text: "Objectives",
              level: 2,
              content: "The objectives of this document are...",
              styleName: "Heading2",
              children: [],
            },
          ],
        },
        {
          id: "4",
          text: "Methodology",
          level: 1,
          content: "The methodology section describes...",
          styleName: "Heading1",
          children: [
            {
              id: "5",
              text: "Data Collection",
              level: 2,
              content: "Data was collected through...",
              styleName: "Heading2",
              children: [
                {
                  id: "6",
                  text: "Survey Design",
                  level: 3,
                  content: "The survey was designed to...",
                  styleName: "Heading3",
                  children: [],
                },
              ],
            },
          ],
        },
        {
          id: "7",
          text: "Results",
          level: 1,
          content: "The results of the analysis show...",
          styleName: "Heading1",
          children: [],
        },
        {
          id: "8",
          text: "Conclusion",
          level: 1,
          content: "In conclusion, we found that...",
          styleName: "Heading1",
          children: [],
        },
      ]

      setHeadings(mockHeadings)

      // Initialize all top-level headings as expanded
      const expanded: Record<string, boolean> = {}
      mockHeadings.forEach((heading) => {
        expanded[heading.id] = true
      })
      setExpandedHeadings(expanded)

      // Notify parent component
      if (onHeadingsExtracted) {
        onHeadingsExtracted(mockHeadings)
      }
    } catch (err) {
      console.error("Error extracting headings:", err)
      setError("Failed to extract headings from the document. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  // Toggle heading expansion
  const toggleHeading = (id: string) => {
    setExpandedHeadings((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  // Handle drag end event
  const handleDragEnd = (result: any) => {
    if (!result.destination) return

    const items = Array.from(flatHeadings)
    const [reorderedItem] = items.splice(result.source.index, 1)
    items.splice(result.destination.index, 0, reorderedItem)

    setFlatHeadings(items)

    // Rebuild the hierarchical structure
    // This is a simplified approach - in a real app, you'd need to handle the hierarchy properly
    const newHeadings = items.filter((item) => item.level === 1)

    // Notify parent component
    if (onHeadingsReordered) {
      onHeadingsReordered(newHeadings)
    }
  }

  // Render loading state
  if (isLoading) {
    return (
      <div
        className={`p-4 border rounded-md ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} ${className}`}
      >
        <div className="flex items-center justify-center py-8">
          <div
            className={`animate-spin rounded-full h-8 w-8 border-b-2 ${isDarkMode ? "border-blue-400" : "border-blue-600"}`}
          ></div>
          <span className="ml-3">Extracting headings...</span>
        </div>
      </div>
    )
  }

  // Render error state
  if (error) {
    return (
      <div
        className={`p-4 border rounded-md ${isDarkMode ? "bg-gray-800 border-red-700" : "bg-white border-red-300"} ${className}`}
      >
        <div className="text-red-500 mb-2">Error:</div>
        <div>{error}</div>
        {docxFile && (
          <button
            onClick={() => extractHeadings(docxFile)}
            className={`mt-4 px-4 py-2 rounded-md ${
              isDarkMode ? "bg-blue-600 hover:bg-blue-700" : "bg-blue-500 hover:bg-blue-600"
            } text-white`}
          >
            Try Again
          </button>
        )}
      </div>
    )
  }

  // Render empty state
  if (!docxFile) {
    return (
      <div
        className={`p-4 border rounded-md ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} ${className}`}
      >
        <div className="text-center py-8">
          <p className={`mb-4 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
            Upload a DOCX file to extract headings
          </p>
        </div>
      </div>
    )
  }

  // Render headings with drag and drop
  return (
    <div
      className={`border rounded-md ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} ${className}`}
    >
      <div className={`p-3 border-b ${isDarkMode ? "border-gray-700 bg-gray-900" : "border-gray-200 bg-gray-50"}`}>
        <h3 className="font-medium">Document Headings</h3>
        <p className={`text-sm ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>Drag and drop to reorder headings</p>
      </div>

      <div className="p-2">
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="headings">
            {(provided) => (
              <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-1">
                {flatHeadings.map((heading, index) => (
                  <Draggable key={heading.id} draggableId={heading.id} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`flex items-center p-2 rounded-md ${
                          isDarkMode
                            ? "hover:bg-gray-700 border border-gray-700"
                            : "hover:bg-gray-50 border border-gray-200"
                        }`}
                      >
                        <div {...provided.dragHandleProps} className="mr-2 cursor-grab">
                          <GripVertical size={16} className={isDarkMode ? "text-gray-400" : "text-gray-500"} />
                        </div>

                        {heading.children && heading.children.length > 0 && (
                          <button
                            onClick={() => toggleHeading(heading.id)}
                            className={`mr-1 p-1 rounded-md ${isDarkMode ? "hover:bg-gray-600" : "hover:bg-gray-200"}`}
                          >
                            {expandedHeadings[heading.id] ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                          </button>
                        )}

                        <div
                          className={`flex-1 ${
                            heading.level === 1 ? "font-semibold" : heading.level === 2 ? "font-medium pl-4" : "pl-8"
                          }`}
                          style={{ paddingLeft: `${(heading.level - 1) * 1.5}rem` }}
                        >
                          {heading.text}
                        </div>

                        <div className="flex space-x-1">
                          <button
                            className={`p-1 rounded-md ${
                              isDarkMode ? "hover:bg-gray-600 text-amber-400" : "hover:bg-gray-200 text-amber-600"
                            }`}
                            title="Edit heading"
                          >
                            <Edit size={14} />
                          </button>
                          <button
                            className={`p-1 rounded-md ${
                              isDarkMode ? "hover:bg-gray-600 text-red-400" : "hover:bg-gray-200 text-red-600"
                            }`}
                            title="Delete heading"
                          >
                            <Trash size={14} />
                          </button>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </div>

      <div className={`p-3 border-t ${isDarkMode ? "border-gray-700" : "border-gray-200"}`}>
        <div className="flex justify-between">
          <button
            className={`px-3 py-1 rounded-md flex items-center ${
              isDarkMode ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-blue-500 hover:bg-blue-600 text-white"
            }`}
          >
            <Plus size={16} className="mr-1" />
            Add Heading
          </button>

          <button
            className={`px-3 py-1 rounded-md ${
              isDarkMode ? "bg-green-600 hover:bg-green-700 text-white" : "bg-green-500 hover:bg-green-600 text-white"
            }`}
          >
            <Save size={16} className="mr-1 inline-block" />
            Save Order
          </button>
        </div>
      </div>
    </div>
  )
}

