"use client"

import { useState, useEffect } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Settings, Plus, Edit, Trash2, Save } from "lucide-react"
import type { PredefinedMapping } from "@/lib/types"
import { PREDEFINED_MAPPINGS } from "./predefined-mappings"

interface MappingManagerProps {
  onMappingsUpdated: () => void
}

export function MappingManager({ onMappingsUpdated }: MappingManagerProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [customMappings, setCustomMappings] = useState<PredefinedMapping[]>([])
  const [allMappings, setAllMappings] = useState<PredefinedMapping[]>([])
  const [selectedMapping, setSelectedMapping] = useState<PredefinedMapping | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [isCreating, setIsCreating] = useState(false)
  const [editedMapping, setEditedMapping] = useState<PredefinedMapping | null>(null)
  const [mappingPairs, setMappingPairs] = useState<{ docSection: string; templateSection: string }[]>([])
  const [activeTab, setActiveTab] = useState("view")

  // Ensure hydration safety
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Load custom mappings from localStorage
  useEffect(() => {
    if (!isMounted) return

    try {
      const storedMappings = localStorage.getItem("customPredefinedMappings")
      if (storedMappings) {
        const parsedMappings = JSON.parse(storedMappings) as PredefinedMapping[]
        setCustomMappings(parsedMappings)
      }
    } catch (error) {
      console.error("Error parsing custom mappings:", error)
      setCustomMappings([])
    }
  }, [isMounted])

  // Combine built-in and custom mappings
  useEffect(() => {
    const combined = [...PREDEFINED_MAPPINGS, ...customMappings.map((mapping) => ({ ...mapping, isCustom: true }))]
    setAllMappings(combined)
  }, [customMappings])

  // Convert mapping object to array of pairs for editing
  useEffect(() => {
    if (editedMapping) {
      const pairs = Object.entries(editedMapping.mapping).map(([docSection, templateSection]) => ({
        docSection,
        templateSection,
      }))
      setMappingPairs(pairs.length > 0 ? pairs : [{ docSection: "", templateSection: "" }])
    }
  }, [editedMapping])

  const handleViewMapping = (mapping: PredefinedMapping) => {
    setSelectedMapping(mapping)
    setIsEditing(false)
    setIsCreating(false)
    setActiveTab("view")
  }

  const handleEditMapping = (mapping: PredefinedMapping) => {
    setEditedMapping({ ...mapping })
    setIsEditing(true)
    setIsCreating(false)
    setActiveTab("edit")
  }

  const handleCreateMapping = () => {
    const newMapping: PredefinedMapping = {
      id: `custom-${Date.now()}`,
      name: "",
      description: "",
      mapping: {},
      isCustom: true,
    }
    setEditedMapping(newMapping)
    setMappingPairs([{ docSection: "", templateSection: "" }])
    setIsEditing(false)
    setIsCreating(true)
    setActiveTab("create")
  }

  const handleDeleteMapping = (mappingId: string) => {
    try {
      const updatedMappings = customMappings.filter((m) => m.id !== mappingId)
      setCustomMappings(updatedMappings)
      localStorage.setItem("customPredefinedMappings", JSON.stringify(updatedMappings))

      // If the deleted mapping was selected, clear the selection
      if (selectedMapping && selectedMapping.id === mappingId) {
        setSelectedMapping(null)
      }

      onMappingsUpdated()
    } catch (error) {
      console.error("Error deleting mapping:", error)
    }
  }

  const handleAddMappingPair = () => {
    setMappingPairs([...mappingPairs, { docSection: "", templateSection: "" }])
  }

  const handleRemoveMappingPair = (index: number) => {
    if (mappingPairs.length <= 1) {
      // Always keep at least one mapping pair
      setMappingPairs([{ docSection: "", templateSection: "" }])
      return
    }

    const updatedPairs = [...mappingPairs]
    updatedPairs.splice(index, 1)
    setMappingPairs(updatedPairs)
  }

  const handleMappingPairChange = (index: number, field: "docSection" | "templateSection", value: string) => {
    const updatedPairs = [...mappingPairs]
    updatedPairs[index][field] = value
    setMappingPairs(updatedPairs)
  }

  const handleSaveMapping = () => {
    if (!editedMapping) return

    try {
      // Validate mapping name
      if (!editedMapping.name.trim()) {
        alert("Please enter a mapping name")
        return
      }

      // Convert pairs back to mapping object
      const mapping: Record<string, string> = {}
      let hasValidPair = false

      mappingPairs.forEach((pair) => {
        if (pair.docSection && pair.templateSection) {
          mapping[pair.docSection] = pair.templateSection
          hasValidPair = true
        }
      })

      if (!hasValidPair) {
        alert("Please add at least one valid mapping pair")
        return
      }

      const updatedMapping: PredefinedMapping = {
        ...editedMapping,
        mapping,
      }

      let updatedMappings: PredefinedMapping[]

      if (isCreating) {
        // Add new mapping
        updatedMappings = [...customMappings, updatedMapping]
      } else {
        // Update existing mapping
        updatedMappings = customMappings.map((m) => (m.id === updatedMapping.id ? updatedMapping : m))
      }

      setCustomMappings(updatedMappings)
      localStorage.setItem("customPredefinedMappings", JSON.stringify(updatedMappings))

      setIsEditing(false)
      setIsCreating(false)
      setSelectedMapping(updatedMapping)
      setActiveTab("view")
      onMappingsUpdated()
    } catch (error) {
      console.error("Error saving mapping:", error)
      alert("Failed to save mapping. Please try again.")
    }
  }

  // Don't render anything during SSR or before hydration
  if (!isMounted) {
    return null
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1">
          <Settings className="h-4 w-4" />
          <span>Manage Mappings</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Predefined Mappings</DialogTitle>
          <DialogDescription>
            View, edit, or create new predefined mapping templates for document conversion.
          </DialogDescription>
        </DialogHeader>

        <div className="flex h-full">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="view">View Mappings</TabsTrigger>
              {isEditing && <TabsTrigger value="edit">Edit Mapping</TabsTrigger>}
              {isCreating && <TabsTrigger value="create">Create Mapping</TabsTrigger>}
              {!isEditing && !isCreating && (
                <TabsTrigger value="create" onClick={handleCreateMapping}>
                  Create New
                </TabsTrigger>
              )}
              <TabsTrigger value="about">About</TabsTrigger>
            </TabsList>

            <TabsContent value="view" className="space-y-4 mt-4">
              <div className="flex justify-end">
                <Button onClick={handleCreateMapping} className="gap-1">
                  <Plus className="h-4 w-4" />
                  <span>Create New Mapping</span>
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {allMappings.map((mapping) => (
                  <Card key={mapping.id} className={mapping.isCustom ? "border-blue-200 dark:border-blue-800" : ""}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{mapping.name}</CardTitle>
                          {mapping.isCustom && (
                            <span className="text-xs bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 px-2 py-0.5 rounded-full">
                              Custom
                            </span>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleViewMapping(mapping)}
                            title="View Details"
                          >
                            <Settings className="h-4 w-4" />
                          </Button>
                          {mapping.isCustom && (
                            <>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEditMapping(mapping)}
                                title="Edit Mapping"
                                className="text-amber-500 hover:text-amber-600 hover:bg-amber-100 dark:hover:bg-amber-900/20"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="text-red-500 hover:text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20"
                                    title="Delete Mapping"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Delete Mapping</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to delete this mapping? This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDeleteMapping(mapping.id)}
                                      className="bg-red-500 hover:bg-red-600"
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </>
                          )}
                        </div>
                      </div>
                      <CardDescription>{mapping.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="text-sm text-muted-foreground">
                        {Object.keys(mapping.mapping).length} section mappings
                      </div>
                    </CardContent>
                    <CardFooter className="pt-0 flex justify-end gap-2">
                      {mapping.isCustom && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditMapping(mapping)}
                            className="gap-1"
                          >
                            <Edit className="h-3.5 w-3.5" />
                            <span>Edit</span>
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="gap-1 border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600 dark:border-red-800 dark:hover:bg-red-950"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                <span>Delete</span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Mapping</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete this mapping? This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteMapping(mapping.id)}
                                  className="bg-red-500 hover:bg-red-600"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>

              {selectedMapping && (
                <Card>
                  <CardHeader>
                    <CardTitle>{selectedMapping.name}</CardTitle>
                    <CardDescription>{selectedMapping.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Document Section</TableHead>
                          <TableHead>Template Section</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {Object.entries(selectedMapping.mapping).map(([docSection, templateSection]) => (
                          <TableRow key={docSection}>
                            <TableCell>{docSection}</TableCell>
                            <TableCell>{templateSection}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                  <CardFooter className="flex justify-end gap-2">
                    {selectedMapping.isCustom && (
                      <>
                        <Button onClick={() => handleEditMapping(selectedMapping)} className="gap-1">
                          <Edit className="h-4 w-4" />
                          <span>Edit</span>
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="outline"
                              className="gap-1 border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600 dark:border-red-800 dark:hover:bg-red-950"
                            >
                              <Trash2 className="h-4 w-4" />
                              <span>Delete</span>
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Mapping</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete this mapping? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDeleteMapping(selectedMapping.id)}
                                className="bg-red-500 hover:bg-red-600"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </>
                    )}
                  </CardFooter>
                </Card>
              )}
            </TabsContent>

            {(isEditing || isCreating) && editedMapping && (
              <TabsContent value={isEditing ? "edit" : "create"} className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>{isEditing ? "Edit Mapping" : "Create New Mapping"}</CardTitle>
                    <CardDescription>
                      {isEditing
                        ? "Modify the mapping details and section pairs"
                        : "Create a new custom mapping template"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="mapping-name">Mapping Name</Label>
                        <Input
                          id="mapping-name"
                          value={editedMapping.name}
                          onChange={(e) => setEditedMapping({ ...editedMapping, name: e.target.value })}
                          placeholder="e.g., Technical Report"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="mapping-description">Description</Label>
                        <Textarea
                          id="mapping-description"
                          value={editedMapping.description}
                          onChange={(e) => setEditedMapping({ ...editedMapping, description: e.target.value })}
                          placeholder="Describe what this mapping is used for"
                          rows={2}
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <Label>Section Mappings</Label>
                          <Button variant="outline" size="sm" onClick={handleAddMappingPair} className="gap-1">
                            <Plus className="h-3 w-3" />
                            <span>Add Mapping</span>
                          </Button>
                        </div>

                        <div className="space-y-2 max-h-[300px] overflow-y-auto p-1">
                          {mappingPairs.map((pair, index) => (
                            <div key={index} className="flex gap-2 items-center">
                              <div className="flex-1">
                                <Input
                                  value={pair.docSection}
                                  onChange={(e) => handleMappingPairChange(index, "docSection", e.target.value)}
                                  placeholder="Document Section"
                                />
                              </div>
                              <div className="flex-1">
                                <Input
                                  value={pair.templateSection}
                                  onChange={(e) => handleMappingPairChange(index, "templateSection", e.target.value)}
                                  placeholder="Template Section"
                                />
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleRemoveMappingPair(index)}
                                className="flex-shrink-0"
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsEditing(false)
                        setIsCreating(false)
                        setActiveTab("view")
                      }}
                    >
                      Cancel
                    </Button>
                    <Button onClick={handleSaveMapping} className="gap-1">
                      <Save className="h-4 w-4" />
                      <span>Save Mapping</span>
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            )}

            <TabsContent value="about" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>About Predefined Mappings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>
                    Predefined mappings help you quickly map document sections to template sections based on common
                    document types.
                  </p>
                  <h3 className="text-lg font-medium">Built-in Mappings</h3>
                  <p>
                    The application comes with several built-in mappings for common document types. These cannot be
                    modified but provide a good starting point.
                  </p>
                  <h3 className="text-lg font-medium">Custom Mappings</h3>
                  <p>
                    You can create your own custom mappings tailored to your specific document types. Custom mappings
                    can be edited or deleted as needed.
                  </p>
                  <h3 className="text-lg font-medium">How Mappings Work</h3>
                  <p>
                    Each mapping contains pairs of document section names and template section names. When you apply a
                    mapping, the application looks for matching template sections and automatically maps them to the
                    corresponding document sections.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <DialogFooter>
          <Button variant="outline" type="button">
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

