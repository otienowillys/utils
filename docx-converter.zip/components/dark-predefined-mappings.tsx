"use client"

import { useState, useEffect } from "react"
import { Info } from "lucide-react"
import type { Section, PredefinedMapping } from "@/lib/types"
import { PREDEFINED_MAPPINGS } from "./predefined-mappings"
import { DarkMappingManager } from "./dark-mapping-manager"

interface DarkPredefinedMappingsProps {
  templateSections: Section[]
  onApplyMapping: (mapping: Record<string, string>) => void
}

export function DarkPredefinedMappings({ templateSections, onApplyMapping }: DarkPredefinedMappingsProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [selectedMappingId, setSelectedMappingId] = useState<string>("")
  const [showInfo, setShowInfo] = useState(false)
  const [allMappings, setAllMappings] = useState<PredefinedMapping[]>(PREDEFINED_MAPPINGS)
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  // Ensure hydration safety
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Load custom mappings from localStorage
  useEffect(() => {
    if (!isMounted) return

    const storedMappings = localStorage.getItem("customPredefinedMappings")
    if (storedMappings) {
      try {
        const customMappings = JSON.parse(storedMappings) as PredefinedMapping[]
        setAllMappings([...PREDEFINED_MAPPINGS, ...customMappings])
      } catch (error) {
        console.error("Error parsing custom mappings:", error)
        setAllMappings(PREDEFINED_MAPPINGS)
      }
    } else {
      setAllMappings(PREDEFINED_MAPPINGS)
    }
  }, [isMounted, refreshTrigger])

  const handleApplyMapping = () => {
    if (!selectedMappingId) return

    const selectedTemplate = allMappings.find((t) => t.id === selectedMappingId)
    if (!selectedTemplate) return

    // Create a mapping from template section IDs to document section names
    const newMapping: Record<string, string> = {}

    templateSections.forEach((section) => {
      // Find a matching section in the predefined mapping
      const matchingDocSection = Object.entries(selectedTemplate.mapping).find(
        ([docSection, templateSection]) => templateSection === section.name,
      )

      if (matchingDocSection) {
        newMapping[section.id] = matchingDocSection[0]
      }
    })

    onApplyMapping(newMapping)
  }

  const handleMappingsUpdated = () => {
    setRefreshTrigger((prev) => prev + 1)
  }

  // Don't render anything during SSR or before hydration
  if (!isMounted) {
    return null
  }

  return (
    <div style={{ marginBottom: "1.5rem" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "0.5rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <h3 style={{ fontSize: "1rem", fontWeight: "500", color: "white" }}>Predefined Mappings</h3>
          <button
            onClick={() => setShowInfo(!showInfo)}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: "1.5rem",
              height: "1.5rem",
              borderRadius: "9999px",
              backgroundColor: "transparent",
              border: "none",
              cursor: "pointer",
              color: "#94a3b8", // slate-400
            }}
          >
            <Info style={{ width: "1rem", height: "1rem" }} />
          </button>
        </div>
        <DarkMappingManager onMappingsUpdated={handleMappingsUpdated} />
      </div>

      {showInfo && (
        <div
          style={{
            marginBottom: "1rem",
            padding: "1rem",
            backgroundColor: "#1e293b", // slate-800
            borderRadius: "0.375rem",
            border: "1px solid #334155", // slate-700
          }}
        >
          <div style={{ marginBottom: "0.5rem" }}>
            <h4 style={{ fontSize: "0.875rem", fontWeight: "500", color: "white", marginBottom: "0.25rem" }}>
              About Predefined Mappings
            </h4>
            <p style={{ fontSize: "0.75rem", color: "#94a3b8" /* slate-400 */ }}>
              Predefined mappings automatically map common document sections to template sections.
            </p>
          </div>
          <p style={{ fontSize: "0.75rem", color: "white" }}>
            Select a mapping template that matches your document type, then click "Apply Mapping" to automatically fill
            in the section mappings. You can still adjust individual mappings after applying a predefined template.
          </p>
          <p style={{ fontSize: "0.75rem", color: "white", marginTop: "0.5rem" }}>
            Use the "Manage Mappings" button to view, edit, or create custom mapping templates.
          </p>
        </div>
      )}

      <div style={{ display: "flex", gap: "0.75rem" }}>
        <select
          value={selectedMappingId}
          onChange={(e) => setSelectedMappingId(e.target.value)}
          style={{
            flex: "1",
            padding: "0.5rem",
            borderRadius: "0.25rem",
            backgroundColor: "#1e293b", // slate-800
            color: "white",
            border: "1px solid #475569", // slate-600
            outline: "none",
          }}
        >
          <option value="" style={{ backgroundColor: "#1e293b", color: "white" }}>
            Select a mapping template
          </option>
          {allMappings.map((mapping) => (
            <option key={mapping.id} value={mapping.id} style={{ backgroundColor: "#1e293b", color: "white" }}>
              {mapping.name} {mapping.isCustom ? "(Custom)" : ""}
            </option>
          ))}
        </select>

        <button
          onClick={handleApplyMapping}
          disabled={!selectedMappingId}
          style={{
            padding: "0.5rem 1rem",
            borderRadius: "0.25rem",
            backgroundColor: "#334155", // slate-700
            color: "white",
            border: "none",
            cursor: selectedMappingId ? "pointer" : "not-allowed",
            opacity: selectedMappingId ? 1 : 0.5,
          }}
        >
          Apply Mapping
        </button>
      </div>

      {selectedMappingId && (
        <p style={{ fontSize: "0.75rem", color: "#94a3b8", marginTop: "0.5rem" }}>
          {allMappings.find((m) => m.id === selectedMappingId)?.description}
        </p>
      )}
    </div>
  )
}

