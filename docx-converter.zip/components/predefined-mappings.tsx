"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Info } from "lucide-react"
import type { Section, PredefinedMapping } from "@/lib/types"
import { MappingManager } from "./mapping-manager"

// Define the predefined mapping templates
export const PREDEFINED_MAPPINGS: PredefinedMapping[] = [
  {
    id: "standard-report",
    name: "Standard Report",
    description: "Maps common report sections like Executive Summary, Introduction, etc.",
    mapping: {
      "Executive Summary": "Executive Summary",
      Introduction: "Introduction",
      Background: "Introduction",
      Methodology: "Methodology",
      Methods: "Methodology",
      Findings: "Findings",
      Results: "Findings",
      Discussion: "Findings",
      Recommendations: "Recommendations",
      Conclusion: "Conclusion",
      References: "Appendices",
      Appendix: "Appendices",
    },
  },
  {
    id: "technical-doc",
    name: "Technical Documentation",
    description: "Maps technical documentation sections like Overview, Requirements, etc.",
    mapping: {
      Overview: "Overview",
      Introduction: "Overview",
      Requirements: "Requirements",
      Specifications: "Requirements",
      Architecture: "Architecture",
      Design: "Architecture",
      Implementation: "Implementation",
      Development: "Implementation",
      API: "API Reference",
      "API Reference": "API Reference",
      Examples: "Examples",
      "Sample Code": "Examples",
    },
  },
  {
    id: "business-proposal",
    name: "Business Proposal",
    description: "Maps business proposal sections like Executive Summary, Market Analysis, etc.",
    mapping: {
      "Executive Summary": "Executive Summary",
      "Company Overview": "Company Overview",
      "Business Description": "Company Overview",
      "Market Analysis": "Market Analysis",
      "Industry Overview": "Market Analysis",
      "Competitive Analysis": "Competitive Analysis",
      Competition: "Competitive Analysis",
      "Products and Services": "Products and Services",
      Offerings: "Products and Services",
      "Marketing Strategy": "Marketing Strategy",
      "Marketing Plan": "Marketing Strategy",
      "Financial Projections": "Financial Projections",
      Financials: "Financial Projections",
      "Funding Request": "Funding Request",
      "Investment Opportunity": "Funding Request",
    },
  },
  {
    id: "academic-paper",
    name: "Academic Paper",
    description: "Maps academic paper sections like Abstract, Literature Review, etc.",
    mapping: {
      Abstract: "Abstract",
      Summary: "Abstract",
      Introduction: "Introduction",
      Background: "Introduction",
      "Literature Review": "Literature Review",
      "Related Work": "Literature Review",
      Methodology: "Methodology",
      Methods: "Methodology",
      Results: "Results",
      Findings: "Results",
      Discussion: "Discussion",
      Analysis: "Discussion",
      Conclusion: "Conclusion",
      References: "References",
      Bibliography: "References",
      Appendices: "Appendices",
      Appendix: "Appendices",
    },
  },
]

interface PredefinedMappingsProps {
  templateSections: Section[]
  onApplyMapping: (mapping: Record<string, string>) => void
}

export function PredefinedMappings({ templateSections, onApplyMapping }: PredefinedMappingsProps) {
  const [isMounted, setIsMounted] = useState(false)
  const [selectedMappingId, setSelectedMappingId] = useState<string>("")
  const [showInfo, setShowInfo] = useState(false)
  const [allMappings, setAllMappings] = useState<PredefinedMapping[]>(PREDEFINED_MAPPINGS)
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  // Ensure hydration safety
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Load custom mappings from localStorage
  useEffect(() => {
    if (!isMounted) return

    try {
      const storedMappings = localStorage.getItem("customPredefinedMappings")
      if (storedMappings) {
        const customMappings = JSON.parse(storedMappings) as PredefinedMapping[]
        setAllMappings([...PREDEFINED_MAPPINGS, ...customMappings])
      } else {
        setAllMappings(PREDEFINED_MAPPINGS)
      }
    } catch (error) {
      console.error("Error parsing custom mappings:", error)
      setAllMappings(PREDEFINED_MAPPINGS)
    }
  }, [isMounted, refreshTrigger])

  const handleApplyMapping = () => {
    if (!selectedMappingId) return

    const selectedTemplate = allMappings.find((t) => t.id === selectedMappingId)
    if (!selectedTemplate) return

    // Create a mapping from template section IDs to document section names
    const newMapping: Record<string, string> = {}

    templateSections.forEach((section) => {
      // Find a matching section in the predefined mapping
      const matchingDocSection = Object.entries(selectedTemplate.mapping).find(
        ([docSection, templateSection]) => templateSection === section.name,
      )

      if (matchingDocSection) {
        newMapping[section.id] = matchingDocSection[0]
      }
    })

    onApplyMapping(newMapping)
  }

  const handleMappingsUpdated = () => {
    setRefreshTrigger((prev) => prev + 1)
  }

  // Don't render anything during SSR or before hydration
  if (!isMounted) {
    return <div className="mb-6">Loading predefined mappings...</div>
  }

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <h3 className="text-base font-medium">Predefined Mappings</h3>
          <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full" onClick={() => setShowInfo(!showInfo)}>
            <Info className="h-4 w-4" />
          </Button>
        </div>
        <MappingManager onMappingsUpdated={handleMappingsUpdated} />
      </div>

      {showInfo && (
        <Card className="mb-4">
          <CardHeader className="py-3">
            <CardTitle className="text-sm">About Predefined Mappings</CardTitle>
            <CardDescription>
              Predefined mappings automatically map common document sections to template sections.
            </CardDescription>
          </CardHeader>
          <CardContent className="py-2 text-sm">
            <p>
              Select a mapping template that matches your document type, then click "Apply Mapping" to automatically
              fill in the section mappings. You can still adjust individual mappings after applying a predefined
              template.
            </p>
            <p className="mt-2">Use the "Manage Mappings" button to view, edit, or create custom mapping templates.</p>
          </CardContent>
        </Card>
      )}

      <div className="flex gap-3">
        <Select value={selectedMappingId} onValueChange={setSelectedMappingId}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select a mapping template" />
          </SelectTrigger>
          <SelectContent>
            {allMappings.map((mapping) => (
              <SelectItem key={mapping.id} value={mapping.id}>
                {mapping.name} {mapping.isCustom ? "(Custom)" : ""}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button variant="secondary" onClick={handleApplyMapping} disabled={!selectedMappingId}>
          Apply Mapping
        </Button>
      </div>

      {selectedMappingId && (
        <p className="text-sm text-muted-foreground mt-2">
          {allMappings.find((m) => m.id === selectedMappingId)?.description}
        </p>
      )}
    </div>
  )
}

