"use client"

import { useTheme } from "next-themes"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ThemeTest() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // Only show the UI after mounting to avoid hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div>Loading...</div>
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-8">Theme Test Page</h1>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Current Theme</CardTitle>
          <CardDescription>This shows your current theme settings</CardDescription>
        </CardHeader>
        <CardContent>
          <p>
            Current theme: <strong>{theme}</strong>
          </p>
          <div className="flex gap-4 mt-4">
            <Button onClick={() => setTheme("light")}>Light</Button>
            <Button onClick={() => setTheme("dark")}>Dark</Button>
            <Button onClick={() => setTheme("system")}>System</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Theme Toggle Component</CardTitle>
          <CardDescription>Test the ThemeToggle component</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div>
            <h3 className="text-lg font-medium mb-2">Dropdown Variant</h3>
            <ThemeToggle variant="dropdown" />
          </div>
          <div>
            <h3 className="text-lg font-medium mb-2">Tabs Variant</h3>
            <ThemeToggle variant="tabs" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

