"use client"

import { useState } from "react"
import { Phase3SectionMapper } from "@/components/phase3-section-mapper"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import type { Template } from "@/lib/types"
import type { DocumentHeading } from "@/components/phase1-heading-extractor"

// Mock templates for demonstration
const mockTemplates: Template[] = [
  {
    id: "template-1",
    name: "Research Paper",
    description: "Standard academic research paper template",
    sections: [
      { id: "section-1", name: "Abstract", type: "text", order: 1 },
      { id: "section-2", name: "Introduction", type: "text", order: 2 },
      { id: "section-3", name: "Literature Review", type: "text", order: 3 },
      { id: "section-4", name: "Methodology", type: "text", order: 4 },
      { id: "section-5", name: "Results", type: "text", order: 5 },
      { id: "section-6", name: "Discussion", type: "text", order: 6 },
      { id: "section-7", name: "Conclusion", type: "text", order: 7 },
      { id: "section-8", name: "References", type: "text", order: 8 },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "template-2",
    name: "Business Report",
    description: "Standard business report template",
    sections: [
      { id: "section-1", name: "Executive Summary", type: "text", order: 1 },
      { id: "section-2", name: "Introduction", type: "text", order: 2 },
      { id: "section-3", name: "Company Overview", type: "text", order: 3 },
      { id: "section-4", name: "Market Analysis", type: "text", order: 4 },
      { id: "section-5", name: "Recommendations", type: "text", order: 5 },
      { id: "section-6", name: "Implementation Plan", type: "text", order: 6 },
      { id: "section-7", name: "Conclusion", type: "text", order: 7 },
      { id: "section-8", name: "Appendices", type: "text", order: 8 },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
]

// Mock extracted headings for demonstration
const mockHeadings: DocumentHeading[] = [
  { id: "h1", text: "Research on AI Applications", level: 1, content: "<p>Main title content</p>", order: 1 },
  {
    id: "h2",
    text: "Abstract",
    level: 2,
    content: "<p>This research explores various AI applications...</p>",
    order: 2,
  },
  {
    id: "h3",
    text: "Introduction to AI",
    level: 2,
    content: "<p>Artificial Intelligence has evolved...</p>",
    order: 3,
  },
  { id: "h4", text: "Background", level: 3, content: "<p>The history of AI development...</p>", order: 4 },
  { id: "h5", text: "Literature Review", level: 2, content: "<p>Previous studies have shown...</p>", order: 5 },
  { id: "h6", text: "Methodology", level: 2, content: "<p>We used a mixed-methods approach...</p>", order: 6 },
  { id: "h7", text: "Data Collection", level: 3, content: "<p>Data was collected through surveys...</p>", order: 7 },
  { id: "h8", text: "Results", level: 2, content: "<p>Our findings indicate that...</p>", order: 8 },
  { id: "h9", text: "Discussion", level: 2, content: "<p>These results suggest that...</p>", order: 9 },
  { id: "h10", text: "Conclusion", level: 2, content: "<p>In conclusion, our research demonstrates...</p>", order: 10 },
  { id: "h11", text: "References", level: 2, content: "<p>1. Smith, J. (2022)...</p>", order: 11 },
]

export default function SectionMappingPage() {
  const [headings, setHeadings] = useState<DocumentHeading[]>(mockHeadings)
  const [templates, setTemplates] = useState<Template[]>(mockTemplates)
  const [sectionMapping, setSectionMapping] = useState<any[]>([])
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("")
  const { toast } = useToast()

  const handleMappingComplete = (mapping: any[], templateId: string) => {
    setSectionMapping(mapping)
    setSelectedTemplateId(templateId)

    toast({
      title: "Mapping complete",
      description: "Your document sections have been mapped to the template. Ready for conversion!",
      action: (
        <Button
          onClick={() => {
            // In a real app, this would navigate to the conversion page
            toast({
              title: "Starting conversion",
              description: "Your document is being converted based on the mapping.",
            })
          }}
        >
          Convert Now
        </Button>
      ),
    })
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Section Mapping</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Map Document Sections to Template</CardTitle>
              <CardDescription>
                This page demonstrates how to map extracted document sections to a template. For this demo, we're using
                mock data to simulate extracted headings.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                In a real implementation, you would first extract headings from a document (Phase 1) and organize them
                (Phase 2) before mapping them to a template (Phase 3).
              </p>
              <p>
                For this demonstration, we've pre-populated the page with mock headings that represent what would be
                extracted from a research paper.
              </p>
            </CardContent>
          </Card>

          <Phase3SectionMapper headings={headings} templates={templates} onMappingComplete={handleMappingComplete} />
        </div>

        <div>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Extracted Headings</CardTitle>
              <CardDescription>These headings would normally be extracted from your document</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {headings.map((heading) => (
                  <li key={heading.id} className="flex items-center">
                    <span
                      className={`inline-block w-8 text-center rounded-full px-2 text-xs 
                      ${
                        heading.level === 1
                          ? "bg-blue-100 text-blue-800"
                          : heading.level === 2
                            ? "bg-green-100 text-green-800"
                            : "bg-purple-100 text-purple-800"
                      }`}
                    >
                      H{heading.level}
                    </span>
                    <span className="ml-2">{heading.text}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {sectionMapping.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Mapping Summary</CardTitle>
                <CardDescription>
                  {templates.find((t) => t.id === selectedTemplateId)?.name || "Template"} mapping
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {sectionMapping.map((item, index) => {
                    const templateSection = templates
                      .find((t) => t.id === selectedTemplateId)
                      ?.sections.find((s) => s.id === item.templateSectionId)

                    const documentHeading = headings.find((h) => h.id === item.documentHeadingId)

                    return (
                      <li key={index} className="text-sm">
                        <span className="font-medium">{templateSection?.name || "Unknown section"}</span>
                        {documentHeading ? (
                          <span className="text-green-600"> ➔ {documentHeading.text}</span>
                        ) : (
                          <span className="text-gray-400"> ➔ Not mapped</span>
                        )}
                      </li>
                    )
                  })}
                </ul>

                <div className="mt-4 pt-4 border-t">
                  <Button
                    className="w-full"
                    onClick={() => {
                      toast({
                        title: "Starting conversion",
                        description: "Your document is being converted based on the mapping.",
                      })
                    }}
                  >
                    Convert Document Using This Mapping
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

