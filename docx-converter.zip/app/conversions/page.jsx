"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"

export default function Conversions() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [conversions, setConversions] = useState([])

  useEffect(() => {
    // Check if user is authenticated
    const isAuthenticated = localStorage.getItem("isAuthenticated") === "true"

    if (!isAuthenticated) {
      router.push("/login")
    } else {
      // Load mock conversions
      loadMockConversions()
      setIsLoading(false)
    }
  }, [router])

  const loadMockConversions = () => {
    // Get conversions from localStorage
    const storedConversionsJSON = localStorage.getItem("recentConversions")

    if (storedConversionsJSON) {
      try {
        const storedConversions = JSON.parse(storedConversionsJSON)
        if (Array.isArray(storedConversions) && storedConversions.length > 0) {
          // Format dates for display
          const formattedConversions = storedConversions.map((conv) => ({
            ...conv,
            date: new Date(conv.date).toLocaleDateString(),
          }))
          setConversions(formattedConversions)
          return
        }
      } catch (error) {
        console.error("Error parsing conversions from localStorage:", error)
      }
    }

    // Fall back to mock data if no conversions in localStorage or error
    const mockConversions = [
      {
        id: "1",
        filename: "report.docx",
        convertedFilename: "report_converted.docx",
        template: "Business Report",
        status: "completed",
        date: "2023-12-15",
        size: 2.4,
      },
      {
        id: "2",
        filename: "contract.docx",
        convertedFilename: "contract_converted.docx",
        template: "Legal Contract",
        status: "completed",
        date: "2023-12-12",
        size: 1.8,
      },
      {
        id: "3",
        filename: "proposal.docx",
        convertedFilename: null,
        template: "Project Proposal",
        status: "failed",
        date: "2023-12-10",
        size: 3.2,
        error: "Missing required sections",
      },
      {
        id: "4",
        filename: "meeting_notes.docx",
        convertedFilename: "meeting_notes_converted.docx",
        template: "Business Report",
        status: "completed",
        date: "2023-12-05",
        size: 1.1,
      },
      {
        id: "5",
        filename: "budget.docx",
        convertedFilename: "budget_converted.docx",
        template: "Project Proposal",
        status: "completed",
        date: "2023-12-01",
        size: 0.9,
      },
    ]
    setConversions(mockConversions)
  }

  if (isLoading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <p>Loading...</p>
      </div>
    )
  }

  return (
    <div style={{ padding: "2rem", maxWidth: "1000px", margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <h1 style={{ fontSize: "2rem", margin: 0 }}>Conversion History</h1>
        <div>
          <Link
            href="/convert"
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: "#0070f3",
              color: "white",
              borderRadius: "0.25rem",
              textDecoration: "none",
              marginRight: "1rem",
            }}
          >
            New Conversion
          </Link>
          <Link
            href="/dashboard"
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: "#f5f5f5",
              color: "#333",
              borderRadius: "0.25rem",
              textDecoration: "none",
            }}
          >
            Back to Dashboard
          </Link>
        </div>
      </div>

      {conversions.length === 0 ? (
        <div
          style={{
            padding: "3rem",
            textAlign: "center",
            backgroundColor: "#f9f9f9",
            borderRadius: "0.5rem",
          }}
        >
          <p style={{ marginBottom: "1rem", color: "#666" }}>No conversion history found.</p>
          <Link
            href="/convert"
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: "#0070f3",
              color: "white",
              borderRadius: "0.25rem",
              textDecoration: "none",
            }}
          >
            Convert Your First Document
          </Link>
        </div>
      ) : (
        <div
          style={{
            border: "1px solid #eaeaea",
            borderRadius: "0.5rem",
            overflow: "hidden",
          }}
        >
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ backgroundColor: "#f9f9f9", borderBottom: "1px solid #eaeaea" }}>
                <th style={{ padding: "1rem", textAlign: "left" }}>Document</th>
                <th style={{ padding: "1rem", textAlign: "left" }}>Template</th>
                <th style={{ padding: "1rem", textAlign: "left" }}>Date</th>
                <th style={{ padding: "1rem", textAlign: "left" }}>Size</th>
                <th style={{ padding: "1rem", textAlign: "left" }}>Status</th>
                <th style={{ padding: "1rem", textAlign: "left" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {conversions.map((conversion) => (
                <tr key={conversion.id} style={{ borderBottom: "1px solid #eaeaea" }}>
                  <td style={{ padding: "1rem" }}>
                    <div style={{ fontWeight: "500" }}>{conversion.filename}</div>
                    {conversion.convertedFilename && (
                      <div style={{ fontSize: "0.75rem", color: "#666" }}>
                        Converted to: {conversion.convertedFilename}
                      </div>
                    )}
                    {conversion.error && (
                      <div style={{ fontSize: "0.75rem", color: "#f44336" }}>Error: {conversion.error}</div>
                    )}
                  </td>
                  <td style={{ padding: "1rem" }}>{conversion.template}</td>
                  <td style={{ padding: "1rem" }}>{conversion.date}</td>
                  <td style={{ padding: "1rem" }}>{conversion.size} MB</td>
                  <td style={{ padding: "1rem" }}>
                    <span
                      style={{
                        padding: "0.25rem 0.5rem",
                        borderRadius: "1rem",
                        fontSize: "0.75rem",
                        backgroundColor: conversion.status === "completed" ? "#e6f7ff" : "#fff2e8",
                        color: conversion.status === "completed" ? "#0070f3" : "#fa541c",
                      }}
                    >
                      {conversion.status}
                    </span>
                  </td>
                  <td style={{ padding: "1rem" }}>
                    <div style={{ display: "flex", gap: "0.5rem" }}>
                      {conversion.status === "completed" && (
                        <button
                          onClick={() => {
                            // Create a simple text file as a placeholder for the converted document
                            const blob = new Blob(
                              [`This is a simulated converted document for ${conversion.filename}`],
                              {
                                type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                              },
                            )
                            const url = URL.createObjectURL(blob)

                            // Create a temporary anchor element
                            const a = document.createElement("a")
                            a.href = url
                            a.download = conversion.convertedFilename
                            document.body.appendChild(a)
                            a.click()
                            document.body.removeChild(a)

                            // Clean up
                            URL.revokeObjectURL(url)
                          }}
                          style={{
                            padding: "0.25rem 0.5rem",
                            backgroundColor: "#52c41a",
                            color: "white",
                            borderRadius: "0.25rem",
                            border: "none",
                            cursor: "pointer",
                            fontSize: "0.75rem",
                          }}
                        >
                          Download
                        </button>
                      )}
                      <button
                        onClick={(e) => {
                          e.preventDefault() // Prevent any default behavior
                          e.stopPropagation() // Stop event propagation

                          console.log("Delete button clicked for conversion:", conversion.id)

                          // Use a simple confirm dialog with a clear message
                          if (confirm(`Delete conversion "${conversion.filename}"?`)) {
                            console.log("Deletion confirmed for conversion:", conversion.id)

                            try {
                              // Get current conversions from localStorage
                              const storedConversionsJSON = localStorage.getItem("recentConversions")
                              const storedConversions = storedConversionsJSON ? JSON.parse(storedConversionsJSON) : []

                              console.log("Current conversions:", storedConversions)

                              // Filter out the conversion to delete
                              const updatedConversions = storedConversions.filter((conv) => conv.id !== conversion.id)

                              console.log("Updated conversions:", updatedConversions)

                              // Save back to localStorage
                              localStorage.setItem("recentConversions", JSON.stringify(updatedConversions))

                              // Update state to reflect the change
                              setConversions((prevConversions) =>
                                prevConversions.filter((conv) => conv.id !== conversion.id),
                              )

                              console.log("Conversion deleted successfully")
                              alert("Conversion deleted successfully")
                            } catch (error) {
                              console.error("Error deleting conversion:", error)
                              alert("Failed to delete conversion: " + error.message)
                            }
                          } else {
                            console.log("Deletion cancelled for conversion:", conversion.id)
                          }
                        }}
                        style={{
                          padding: "0.25rem 0.5rem",
                          backgroundColor: "#f44336",
                          color: "white",
                          borderRadius: "0.25rem",
                          border: "none",
                          cursor: "pointer",
                          fontSize: "0.75rem",
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

