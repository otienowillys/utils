import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export const metadata = {
  title: "About | DOCX Converter",
  description: "Learn about our document conversion platform and our mission",
}

export default function AboutPage() {
  return (
    <div className="container py-12 space-y-16">
      <section className="space-y-6 text-center">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">About DOCX Converter</h1>
        <p className="max-w-[700px] mx-auto text-lg text-muted-foreground">
          Our mission is to simplify document conversion and make it accessible to everyone
        </p>
      </section>

      <section className="grid gap-12 lg:grid-cols-2 items-center">
        <div className="relative aspect-square rounded-xl overflow-hidden border shadow-xl">
          <Image src="/placeholder.svg?height=800&width=800" alt="Our team" fill className="object-cover" />
        </div>
        <div className="space-y-6">
          <h2 className="text-3xl font-bold tracking-tight">Our Story</h2>
          <p className="text-lg text-muted-foreground">
            DOCX Converter was born out of frustration with existing document conversion tools. We found that most
            solutions were either too complex, too expensive, or simply didn't produce the quality results we needed.
          </p>
          <p className="text-lg text-muted-foreground">
            Founded in 2023, our team of document format experts and software engineers set out to create a solution
            that would make document conversion simple, affordable, and high-quality.
          </p>
          <p className="text-lg text-muted-foreground">
            Today, DOCX Converter is used by thousands of individuals and businesses around the world to streamline
            their document workflows and save time.
          </p>
        </div>
      </section>

      <section className="py-12">
        <h2 className="text-3xl font-bold tracking-tight text-center mb-12">Our Values</h2>
        <div className="grid gap-8 md:grid-cols-3">
          <ValueCard
            title="Simplicity"
            description="We believe that powerful tools don't have to be complicated. Our platform is designed to be intuitive and easy to use."
          />
          <ValueCard
            title="Quality"
            description="We're committed to providing the highest quality document conversions, preserving formatting and ensuring accuracy."
          />
          <ValueCard
            title="Accessibility"
            description="We believe that everyone should have access to powerful document conversion tools, regardless of technical expertise."
          />
        </div>
      </section>

      <section className="py-12 bg-muted rounded-xl p-8">
        <div className="space-y-6 text-center">
          <h2 className="text-3xl font-bold tracking-tight">Our Technology</h2>
          <p className="max-w-[700px] mx-auto text-lg">
            DOCX Converter is built on modern web technologies, utilizing the power of Next.js, React, and the OpenXML
            SDK to provide a fast, reliable, and secure document conversion experience.
          </p>
          <div className="flex flex-wrap justify-center gap-8 pt-6">
            {["Next.js", "React", "OpenXML SDK", "Tailwind CSS", "Node.js", ".NET Core"].map((tech) => (
              <div key={tech} className="px-4 py-2 bg-background rounded-full shadow-sm">
                {tech}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 text-center space-y-8">
        <h2 className="text-3xl font-bold tracking-tight">Join us on our mission</h2>
        <p className="text-lg text-muted-foreground max-w-[700px] mx-auto">
          We're just getting started. Join us as we continue to improve and expand our document conversion platform.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg">
            <Link href="/register">Get Started</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/features">Explore Features</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

function ValueCard({ title, description }) {
  return (
    <div className="space-y-4 text-center">
      <h3 className="text-xl font-bold">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  )
}

