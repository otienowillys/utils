"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { ImprovedHeroSection } from "@/components/improved-hero-section"

export default function Home() {
  // Initialize to null to avoid hydration mismatch
  const [isAuthenticated, setIsAuthenticated] = useState(null)

  useEffect(() => {
    // Initial check after mount
    setIsAuthenticated(localStorage?.getItem("isAuthenticated") === "true")

    // Set up event listener for storage changes
    const handleStorageChange = () => {
      setIsAuthenticated(localStorage?.getItem("isAuthenticated") === "true")
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("auth-change", handleStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("auth-change", handleStorageChange)
    }
  }, [])

  // Don't render until after hydration
  if (isAuthenticated === null) {
    return null
  }

  return (
    <div>
      <ImprovedHeroSection />

      <div className="container mx-auto max-w-4xl py-12 px-4 text-center">
        <div className="space-y-6">
          <div className="flex justify-center gap-4">
            {isAuthenticated ? (
              <Button asChild size="lg">
                <Link href="/dashboard">Go to Dashboard</Link>
              </Button>
            ) : (
              <Button asChild size="lg">
                <Link href="/login">Get Started</Link>
              </Button>
            )}
            <Button asChild variant="outline" size="lg">
              <Link href="/theme-demo">Theme Demo</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

