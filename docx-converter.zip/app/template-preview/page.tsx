"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Template } from "@/lib/types"

export default function TemplatePreviewPage() {
  const [templates, setTemplates] = useState<Template[]>([])
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("")
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Load templates
    const loadTemplates = async () => {
      try {
        // Try to get templates from localStorage
        const storedTemplatesJSON = localStorage.getItem("templates")
        let templatesData: Template[] = []

        if (storedTemplatesJSON) {
          try {
            const parsed = JSON.parse(storedTemplatesJSON)
            if (Array.isArray(parsed) && parsed.length > 0) {
              templatesData = parsed
            }
          } catch (error) {
            console.error("Error parsing templates:", error)
          }
        }

        // If no templates found, use mock data
        if (templatesData.length === 0) {
          templatesData = [
            {
              id: "1",
              name: "Business Report",
              description: "Standard template for business reports",
              sections: [
                { id: "s1", name: "Executive Summary", order: 0 },
                { id: "s2", name: "Introduction", order: 1 },
                { id: "s3", name: "Methodology", order: 2 },
                { id: "s4", name: "Findings", order: 3 },
                { id: "s5", name: "Recommendations", order: 4 },
                { id: "s6", name: "Conclusion", order: 5 },
                { id: "s7", name: "Appendices", order: 6 },
              ],
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
            {
              id: "2",
              name: "Legal Contract",
              description: "Template for legal contracts",
              sections: [
                { id: "s1", name: "Parties", order: 0 },
                { id: "s2", name: "Recitals", order: 1 },
                { id: "s3", name: "Definitions", order: 2 },
                { id: "s4", name: "Terms and Conditions", order: 3 },
                { id: "s5", name: "Obligations", order: 4 },
                { id: "s6", name: "Representations and Warranties", order: 5 },
                { id: "s7", name: "Termination", order: 6 },
                { id: "s8", name: "Governing Law", order: 7 },
              ],
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            },
          ]
        }

        setTemplates(templatesData)

        // Select the first template by default
        if (templatesData.length > 0) {
          setSelectedTemplateId(templatesData[0].id)
          setSelectedTemplate(templatesData[0])
        }

        setIsLoading(false)
      } catch (error) {
        console.error("Error loading templates:", error)
        setIsLoading(false)
      }
    }

    loadTemplates()
  }, [])

  // Update selected template when selectedTemplateId changes
  useEffect(() => {
    if (selectedTemplateId) {
      const template = templates.find((t) => t.id === selectedTemplateId)
      setSelectedTemplate(template || null)
    } else {
      setSelectedTemplate(null)
    }
  }, [selectedTemplateId, templates])

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-3xl">
      <h1 className="text-3xl font-bold mb-8">Template Preview</h1>

      <div className="space-y-6">
        <div className="space-y-2">
          <label className="text-base font-medium">Template</label>
          <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
            <SelectTrigger className="w-full bg-background border-input">
              <SelectValue placeholder="Select a template" />
            </SelectTrigger>
            <SelectContent>
              {templates.map((template) => (
                <SelectItem key={template.id} value={template.id}>
                  {template.name} ({template.sections.length} sections)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-sm text-muted-foreground">{templates.length} templates available</p>
        </div>

        {selectedTemplate && (
          <div>
            <h2 className="text-xl font-medium mb-4">Template Preview</h2>
            <Card className="border bg-muted/20">
              <CardContent className="p-0">
                <div className="divide-y">
                  {selectedTemplate.sections.map((section) => (
                    <div key={section.id} className="p-3 text-primary">
                      {section.name}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

