"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Login() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  // Initialize with a default value to avoid hydration mismatch
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  // Check if already authenticated after mount
  useEffect(() => {
    setIsMounted(true)
    try {
      setIsAuthenticated(localStorage?.getItem("isAuthenticated") === "true")
    } catch (e) {
      console.error("Failed to access localStorage:", e)
    }
  }, [])

  // Redirect if authenticated
  useEffect(() => {
    if (!isMounted) return

    let isCurrent = true
    if (isCurrent && isAuthenticated) {
      // Use setTimeout to ensure state updates complete before navigation
      const redirectTimer = setTimeout(() => {
        router.push("/dashboard")
      }, 0)

      return () => {
        isCurrent = false
        clearTimeout(redirectTimer)
      }
    }

    return () => {
      isCurrent = false
    }
  }, [isAuthenticated, router, isMounted])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Simple validation
      if (email === "admin@example.com" && password === "password123") {
        localStorage.setItem("isAuthenticated", "true")
        setIsAuthenticated(true)

        // Use setTimeout to ensure state updates complete before event dispatch
        setTimeout(() => {
          window.dispatchEvent(new Event("auth-change"))
        }, 0)
      } else {
        setError("Invalid email or password")
      }
    } catch (err) {
      setError("An error occurred during login")
    } finally {
      setIsLoading(false)
    }
  }

  // For server-side rendering, return a minimal placeholder
  if (!isMounted) {
    return (
      <div className="container mx-auto max-w-md p-6">
        <h1 className="text-2xl font-bold mb-6 text-center">Login</h1>
        <div className="text-center">Loading login form...</div>
      </div>
    )
  }

  // Don't render form if we're already authenticated and about to redirect
  if (isAuthenticated) {
    return (
      <div className="container mx-auto max-w-md p-6 text-center">
        <p>You are already logged in. Redirecting to dashboard...</p>
      </div>
    )
  }

  return (
    <div className="container mx-auto max-w-md p-6">
      <h1 className="text-2xl font-bold mb-6 text-center">Login</h1>

      {error && <div className="bg-red-50 text-red-700 p-3 rounded-md mb-4 border border-red-200">{error}</div>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-2 border rounded-md"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-2 border rounded-md"
            required
          />
        </div>

        <Button type="submit" disabled={isLoading} className="w-full">
          {isLoading ? "Logging in..." : "Login"}
        </Button>
      </form>

      <p className="text-center text-sm text-muted-foreground mt-4">
        Use <strong>admin@example.com</strong> / <strong>password123</strong> to login
      </p>

      <div className="text-center mt-4">
        <Link href="/" className="text-primary hover:underline">
          Back to Home
        </Link>
      </div>

      <div className="text-center mt-4 pt-4 border-t">
        <p className="text-muted-foreground mb-2">Don't have an account?</p>
        <Button asChild variant="outline">
          <Link href="/register">Create Account</Link>
        </Button>
      </div>
    </div>
  )
}

