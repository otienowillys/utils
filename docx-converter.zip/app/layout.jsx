import { Analytics } from "@/components/analytics"
import { SiteHeader } from "@/components/site-header"
import { MinimalFooter } from "@/components/minimal-footer"
import { Providers } from "./providers"
import { Toaster } from "@/components/ui/toaster"
import "./globals.css"

export const metadata = {
  title: "DOCX Converter",
  description: "Convert DOCX files with ease",
    generator: 'v0.dev'
}

// Script to initialize theme based on localStorage or system preference
const themeScript = `
(function() {
  try {
    function getThemePreference() {
      if (typeof localStorage !== 'undefined' && localStorage.getItem('theme')) {
        return localStorage.getItem('theme');
      }
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    
    const theme = getThemePreference();
    
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  } catch (e) {
    // Fail gracefully if localStorage is not available
    console.error('Error accessing localStorage:', e);
  }
})();
`

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="min-h-screen bg-background font-sans antialiased">
        <Providers>
          <div className="relative flex min-h-screen flex-col">
            <SiteHeader />
            <main className="flex-1">{children}</main>
            <MinimalFooter />
          </div>
          <Toaster />
          <Analytics />
        </Providers>
      </body>
    </html>
  )
}



import './globals.css'