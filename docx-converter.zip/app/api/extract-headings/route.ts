import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    // Get form data with the file
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Check file type
    if (!file.name.endsWith(".docx")) {
      return NextResponse.json({ error: "Only DOCX files are supported" }, { status: 400 })
    }

    // Convert file to byte array
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    // In a real implementation, you would call the C# OpenXmlService to extract headings
    // For demonstration, we'll simulate the response

    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Mock extracted headings
    const mockHeadings = [
      {
        id: "1",
        text: "Introduction",
        level: 1,
        content: "This is the introduction content...",
        styleName: "Heading1",
      },
      {
        id: "2",
        text: "Background",
        level: 2,
        content: "Background information goes here...",
        styleName: "Heading2",
      },
      {
        id: "3",
        text: "Objectives",
        level: 2,
        content: "The objectives of this document are...",
        styleName: "Heading2",
      },
      {
        id: "4",
        text: "Methodology",
        level: 1,
        content: "The methodology section describes...",
        styleName: "Heading1",
      },
      {
        id: "5",
        text: "Data Collection",
        level: 2,
        content: "Data was collected through...",
        styleName: "Heading2",
      },
      {
        id: "6",
        text: "Survey Design",
        level: 3,
        content: "The survey was designed to...",
        styleName: "Heading3",
      },
      {
        id: "7",
        text: "Results",
        level: 1,
        content: "The results of the analysis show...",
        styleName: "Heading1",
      },
      {
        id: "8",
        text: "Conclusion",
        level: 1,
        content: "In conclusion, we found that...",
        styleName: "Heading1",
      },
    ]

    return NextResponse.json({ headings: mockHeadings })
  } catch (error) {
    console.error("Error extracting headings:", error)
    return NextResponse.json({ error: "Failed to extract headings from document" }, { status: 500 })
  }
}

