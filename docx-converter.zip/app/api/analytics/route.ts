import { NextResponse } from "next/server"
import { getToken } from "next-auth/jwt"

// Simple in-memory analytics storage
const analyticsEvents: Array<{
  name: string
  properties?: Record<string, string | number | boolean>
  userId?: string
  timestamp: Date
}> = []

export async function POST(request: Request) {
  try {
    const token = await getToken({ req: request as any })
    const { name, properties } = await request.json()

    if (!name) {
      return NextResponse.json({ error: "Event name is required" }, { status: 400 })
    }

    // Store the analytics event
    analyticsEvents.push({
      name,
      properties,
      userId: (token?.email as string) || "anonymous",
      timestamp: new Date(),
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error processing analytics:", error)
    return NextResponse.json({ error: "Failed to process analytics" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    // Check if user is admin
    const token = await getToken({ req: request as any })

    if (!token || token.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Return analytics data
    return NextResponse.json({
      events: analyticsEvents,
      count: analyticsEvents.length,
    })
  } catch (error) {
    console.error("Error retrieving analytics:", error)
    return NextResponse.json({ error: "Failed to retrieve analytics" }, { status: 500 })
  }
}

