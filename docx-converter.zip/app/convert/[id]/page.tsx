"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { getTemplate } from "@/lib/api-service"
import type { Template } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SectionMapper } from "@/components/section-mapper"
import LexicalEditor from "@/components/lexical-editor"
import { Loader2, Save } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function EditDocumentPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const [template, setTemplate] = useState<Template | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [activeSection, setActiveSection] = useState<string | null>(null)
  const [sectionMapping, setSectionMapping] = useState<Record<string, string>>({})
  const [sectionContents, setSectionContents] = useState<Record<string, string>>({})
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    const fetchTemplate = async () => {
      try {
        const templateData = await getTemplate(params.id as string)
        setTemplate(templateData)
        if (templateData && templateData.sections.length > 0) {
          setActiveSection(templateData.sections[0].id)

          // Initialize section contents with empty strings
          const initialContents: Record<string, string> = {}
          templateData.sections.forEach((section) => {
            initialContents[section.id] = ""
          })
          setSectionContents(initialContents)
        }
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load template",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchTemplate()
  }, [params.id, toast])

  const handleSectionMappingChange = (mapping: Record<string, string>) => {
    setSectionMapping(mapping)
  }

  const handleSectionContentChange = (sectionId: string, content: string) => {
    setSectionContents((prev) => ({
      ...prev,
      [sectionId]: content,
    }))
  }

  const handleSave = async () => {
    setIsSaving(true)

    try {
      // In a real implementation, you would send the section contents and mapping to the server
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: "Document saved successfully",
      })

      router.push("/convert")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save document",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (!template) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold">Template not found</h2>
        <p className="text-muted-foreground mt-2">The template you are looking for does not exist.</p>
        <Button className="mt-4" onClick={() => router.push("/convert")}>
          Go Back
        </Button>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Edit Document</h1>
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save Document
            </>
          )}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Document Structure</CardTitle>
              <CardDescription>Reorder and map sections</CardDescription>
            </CardHeader>
            <CardContent>
              <SectionMapper templateSections={template.sections} onChange={handleSectionMappingChange} />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Section Content</CardTitle>
              <CardDescription>Edit the content of each section</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeSection || ""} onValueChange={setActiveSection} className="w-full">
                <TabsList className="w-full flex overflow-x-auto">
                  {template.sections.map((section) => (
                    <TabsTrigger key={section.id} value={section.id} className="flex-1">
                      {section.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
                {template.sections.map((section) => (
                  <TabsContent key={section.id} value={section.id}>
                    <LexicalEditor
                      content={sectionContents[section.id]}
                      onChange={(content) => handleSectionContentChange(section.id, content)}
                      placeholder={`Enter content for ${section.name}...`}
                    />
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

