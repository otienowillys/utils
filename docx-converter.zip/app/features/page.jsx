import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata = {
  title: "Features | DOCX Converter",
  description: "Explore the powerful features of our document conversion platform",
}

export default function FeaturesPage() {
  return (
    <div className="container py-12 space-y-16">
      <section className="space-y-6 text-center">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Powerful Document Conversion</h1>
        <p className="max-w-[700px] mx-auto text-lg text-muted-foreground">
          Transform your documents with our advanced conversion tools and templates
        </p>
      </section>

      <section className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        <FeatureCard
          title="Multiple Output Formats"
          description="Convert your documents to DOCX, PDF, or HTML formats with a single click."
          icon="📄"
        />
        <FeatureCard
          title="Custom Templates"
          description="Choose from a variety of templates or create your own to match your brand."
          icon="🎨"
        />
        <FeatureCard
          title="Section Mapping"
          description="Map content from your source document to specific sections in your template."
          icon="🔄"
        />
        <FeatureCard
          title="Batch Processing"
          description="Convert multiple documents at once to save time and effort."
          icon="⚡"
        />
        <FeatureCard
          title="Cloud Storage"
          description="Access your converted documents from anywhere, anytime."
          icon="☁️"
        />
        <FeatureCard
          title="Offline Support"
          description="Continue working even when you're offline with our progressive web app."
          icon="📱"
        />
      </section>

      <section className="py-12">
        <div className="grid gap-12 lg:grid-cols-2 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold tracking-tight">Advanced Document Conversion</h2>
            <p className="text-lg text-muted-foreground">
              Our platform uses cutting-edge technology to ensure your documents are converted with the highest quality
              and accuracy.
            </p>
            <ul className="space-y-3">
              {[
                "Preserve formatting and styles from your original document",
                "Maintain tables, images, and complex layouts",
                "Convert headers, footers, and page numbering",
                "Support for footnotes and endnotes",
                "Handle document metadata and properties",
              ].map((feature, i) => (
                <li key={i} className="flex items-center gap-2">
                  <div className="rounded-full bg-primary/10 p-1">
                    <svg
                      className="h-4 w-4 text-primary"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <Button asChild size="lg" className="mt-4">
              <Link href="/convert">Try It Now</Link>
            </Button>
          </div>
          <div className="relative aspect-video rounded-xl overflow-hidden border shadow-xl">
            <Image
              src="/placeholder.svg?height=600&width=800"
              alt="Document conversion preview"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section className="py-12 text-center space-y-8">
        <h2 className="text-3xl font-bold tracking-tight">Ready to transform your documents?</h2>
        <p className="text-lg text-muted-foreground max-w-[700px] mx-auto">
          Join thousands of users who are already using our platform to streamline their document workflows.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg">
            <Link href="/register">Get Started</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/convert">Try Demo</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

function FeatureCard({ title, description, icon }) {
  return (
    <Card>
      <CardHeader>
        <div className="text-4xl mb-2">{icon}</div>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-base">{description}</CardDescription>
      </CardContent>
    </Card>
  )
}

