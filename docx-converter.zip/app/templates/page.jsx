"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"

export default function Templates() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [templates, setTemplates] = useState([])

  useEffect(() => {
    // Check if user is authenticated
    const isAuthenticated = localStorage.getItem("isAuthenticated") === "true"

    if (!isAuthenticated) {
      router.push("/login")
    } else {
      // Load mock templates
      loadMockTemplates()
      setIsLoading(false)
    }
  }, [router])

  const loadMockTemplates = () => {
    // Try to get templates from localStorage first
    const storedTemplatesJSON = localStorage.getItem("templates")
    let templatesFromStorage = []

    if (storedTemplatesJSON) {
      try {
        const parsed = JSON.parse(storedTemplatesJSON)
        if (Array.isArray(parsed) && parsed.length > 0) {
          templatesFromStorage = parsed
          console.log("Successfully loaded templates from localStorage:", templatesFromStorage.length)
          setTemplates(templatesFromStorage)
          return
        }
      } catch (error) {
        console.error("Error parsing stored templates:", error)
        // Fall back to mock data if there's an error
      }
    }

    // Default mock templates if nothing in localStorage or parsing failed
    const mockTemplates = [
      {
        id: "1",
        name: "Business Report",
        description: "Standard template for business reports with executive summary and recommendations",
        sections: [
          { id: "s1", name: "Executive Summary" },
          { id: "s2", name: "Introduction" },
          { id: "s3", name: "Methodology" },
          { id: "s4", name: "Findings" },
          { id: "s5", name: "Recommendations" },
          { id: "s6", name: "Conclusion" },
          { id: "s7", name: "Appendices" },
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "2",
        name: "Legal Contract",
        description: "Template for legal contracts with standard clauses and sections",
        sections: [
          { id: "s1", name: "Parties" },
          { id: "s2", name: "Recitals" },
          { id: "s3", name: "Definitions" },
          { id: "s4", name: "Terms and Conditions" },
          { id: "s5", name: "Obligations" },
          { id: "s6", name: "Representations and Warranties" },
          { id: "s7", name: "Termination" },
          { id: "s8", name: "Governing Law" },
          { id: "s9", name: "Signatures" },
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "3",
        name: "Project Proposal",
        description: "Template for project proposals with objectives, scope, and budget",
        sections: [
          { id: "s1", name: "Project Overview" },
          { id: "s2", name: "Objectives" },
          { id: "s3", name: "Scope" },
          { id: "s4", name: "Methodology" },
          { id: "s5", name: "Timeline" },
          { id: "s6", name: "Budget" },
          { id: "s7", name: "Team" },
          { id: "s8", name: "Risk Assessment" },
          { id: "s9", name: "Success Criteria" },
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "4",
        name: "Academic Paper",
        description: "Template for academic research papers with standard sections",
        sections: [
          { id: "s1", name: "Abstract" },
          { id: "s2", name: "Introduction" },
          { id: "s3", name: "Literature Review" },
          { id: "s4", name: "Methodology" },
          { id: "s5", name: "Results" },
          { id: "s6", name: "Discussion" },
          { id: "s7", name: "Conclusion" },
          { id: "s8", name: "References" },
          { id: "s9", name: "Appendices" },
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "5",
        name: "Case Study",
        description: "Template for detailed case studies with background, analysis, and recommendations",
        sections: [
          { id: "s1", name: "Executive Summary" },
          { id: "s2", name: "Background" },
          { id: "s3", name: "Problem Statement" },
          { id: "s4", name: "Analysis" },
          { id: "s5", name: "Alternatives" },
          { id: "s6", name: "Recommendations" },
          { id: "s7", name: "Implementation Plan" },
          { id: "s8", name: "Conclusion" },
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "6",
        name: "Marketing Plan",
        description: "Template for comprehensive marketing plans with strategy and execution details",
        sections: [
          { id: "s1", name: "Executive Summary" },
          { id: "s2", name: "Market Analysis" },
          { id: "s3", name: "Target Audience" },
          { id: "s4", name: "Competitive Analysis" },
          { id: "s5", name: "Marketing Strategy" },
          { id: "s6", name: "Tactics and Channels" },
          { id: "s7", name: "Budget" },
          { id: "s8", name: "Timeline" },
          { id: "s9", name: "KPIs and Metrics" },
          { id: "s10", name: "Contingency Plan" },
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "7",
        name: "Technical Documentation",
        description: "Template for technical documentation with system architecture and implementation details",
        sections: [
          { id: "s1", name: "Introduction" },
          { id: "s2", name: "System Overview" },
          { id: "s3", name: "Architecture" },
          { id: "s4", name: "Installation Guide" },
          { id: "s5", name: "Configuration" },
          { id: "s6", name: "API Reference" },
          { id: "s7", name: "Troubleshooting" },
          { id: "s8", name: "FAQ" },
          { id: "s9", name: "Glossary" },
        ],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ]

    // Store the mock templates in localStorage if it's empty
    localStorage.setItem("templates", JSON.stringify(mockTemplates))
    setTemplates(mockTemplates)
  }

  const handleDeleteTemplate = (id) => {
    if (confirm("Are you sure you want to delete this template?")) {
      const updatedTemplates = templates.filter((template) => template.id !== id)
      setTemplates(updatedTemplates)

      // Update localStorage
      localStorage.setItem("templates", JSON.stringify(updatedTemplates))
    }
  }

  if (isLoading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <p>Loading...</p>
      </div>
    )
  }

  return (
    <div style={{ padding: "2rem", maxWidth: "1000px", margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <h1 style={{ fontSize: "2rem", margin: 0 }}>Templates</h1>
        <div>
          <Link
            href="/templates/new"
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: "#0070f3",
              color: "white",
              borderRadius: "0.25rem",
              textDecoration: "none",
              marginRight: "1rem",
            }}
          >
            Create Template
          </Link>
          <Link
            href="/dashboard"
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: "#f5f5f5",
              color: "#333",
              borderRadius: "0.25rem",
              textDecoration: "none",
            }}
          >
            Back to Dashboard
          </Link>
        </div>
      </div>

      {templates.length === 0 ? (
        <div
          style={{
            padding: "3rem",
            textAlign: "center",
            backgroundColor: "#f9f9f9",
            borderRadius: "0.5rem",
          }}
        >
          <p style={{ marginBottom: "1rem", color: "#666" }}>No templates found.</p>
          <Link
            href="/templates/new"
            style={{
              padding: "0.5rem 1rem",
              backgroundColor: "#0070f3",
              color: "white",
              borderRadius: "0.25rem",
              textDecoration: "none",
            }}
          >
            Create Your First Template
          </Link>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1.5rem" }}>
          {templates.map((template) => (
            <div
              key={template.id}
              style={{
                border: "1px solid #eaeaea",
                borderRadius: "0.5rem",
                overflow: "hidden",
                display: "flex",
                flexDirection: "column",
                height: "100%",
              }}
            >
              <div style={{ padding: "1.5rem", flex: "1" }}>
                <h2 style={{ fontSize: "1.25rem", marginBottom: "0.5rem" }}>{template.name}</h2>
                <p style={{ fontSize: "0.875rem", color: "#666", marginBottom: "0.5rem" }}>
                  {template.sections.length} sections
                </p>
                <p style={{ fontSize: "0.875rem", color: "#666", marginBottom: "1rem" }}>
                  Created on {new Date(template.createdAt).toLocaleDateString()}
                </p>
                <p style={{ fontSize: "0.875rem" }}>{template.description}</p>
              </div>
              <div style={{ padding: "1rem", backgroundColor: "#f9f9f9", borderTop: "1px solid #eaeaea" }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <Link
                    href={`/templates/${template.id}`}
                    style={{
                      padding: "0.5rem 1rem",
                      backgroundColor: "#fff",
                      color: "#0070f3",
                      borderRadius: "0.25rem",
                      border: "1px solid #0070f3",
                      textDecoration: "none",
                      fontSize: "0.875rem",
                      display: "inline-block",
                    }}
                  >
                    Edit
                  </Link>
                  <button
                    onClick={() => handleDeleteTemplate(template.id)}
                    style={{
                      padding: "0.5rem 1rem",
                      backgroundColor: "#fff",
                      color: "#f44336",
                      borderRadius: "0.25rem",
                      border: "1px solid #f44336",
                      cursor: "pointer",
                      fontSize: "0.875rem",
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

