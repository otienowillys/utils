"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"

export default function EditTemplate() {
  const router = useRouter()
  const params = useParams()
  const templateId = params.id

  const [isLoading, setIsLoading] = useState(true)
  const [template, setTemplate] = useState(null)
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [sections, setSections] = useState([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    // Check if user is authenticated
    const isAuthenticated = localStorage.getItem("isAuthenticated") === "true"

    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    // Fetch template data
    fetchTemplate(templateId)
  }, [router, templateId])

  const fetchTemplate = (id) => {
    // If the ID is "new", we should redirect to the dedicated new template page
    if (id === "new") {
      router.push("/templates/new")
      return
    }

    // Try to get templates from localStorage
    const storedTemplatesJSON = localStorage.getItem("templates")
    let foundTemplate = null

    if (storedTemplatesJSON) {
      try {
        const storedTemplates = JSON.parse(storedTemplatesJSON)
        foundTemplate = storedTemplates.find((t) => t.id === id)
      } catch (error) {
        console.error("Error parsing stored templates:", error)
      }
    }

    // If not found in localStorage, use mock data
    if (!foundTemplate) {
      const mockTemplates = [
        {
          id: "1",
          name: "Business Report",
          description: "Standard template for business reports with executive summary and recommendations",
          sections: [
            { id: "s1", name: "Executive Summary" },
            { id: "s2", name: "Introduction" },
            { id: "s3", name: "Methodology" },
            { id: "s4", name: "Findings" },
            { id: "s5", name: "Recommendations" },
            { id: "s6", name: "Conclusion" },
            { id: "s7", name: "Appendices" },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: "2",
          name: "Legal Contract",
          description: "Template for legal contracts with standard clauses and sections",
          sections: [
            { id: "s1", name: "Parties" },
            { id: "s2", name: "Recitals" },
            { id: "s3", name: "Definitions" },
            { id: "s4", name: "Terms and Conditions" },
            { id: "s5", name: "Obligations" },
            { id: "s6", name: "Representations and Warranties" },
            { id: "s7", name: "Termination" },
            { id: "s8", name: "Governing Law" },
            { id: "s9", name: "Signatures" },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: "3",
          name: "Project Proposal",
          description: "Template for project proposals with objectives, scope, and budget",
          sections: [
            { id: "s1", name: "Project Overview" },
            { id: "s2", name: "Objectives" },
            { id: "s3", name: "Scope" },
            { id: "s4", name: "Methodology" },
            { id: "s5", name: "Timeline" },
            { id: "s6", name: "Budget" },
            { id: "s7", name: "Team" },
            { id: "s8", name: "Risk Assessment" },
            { id: "s9", name: "Success Criteria" },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: "4",
          name: "Academic Paper",
          description: "Template for academic research papers with standard sections",
          sections: [
            { id: "s1", name: "Abstract" },
            { id: "s2", name: "Introduction" },
            { id: "s3", name: "Literature Review" },
            { id: "s4", name: "Methodology" },
            { id: "s5", name: "Results" },
            { id: "s6", name: "Discussion" },
            { id: "s7", name: "Conclusion" },
            { id: "s8", name: "References" },
            { id: "s9", name: "Appendices" },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: "5",
          name: "Case Study",
          description: "Template for detailed case studies with background, analysis, and recommendations",
          sections: [
            { id: "s1", name: "Executive Summary" },
            { id: "s2", name: "Background" },
            { id: "s3", name: "Problem Statement" },
            { id: "s4", name: "Analysis" },
            { id: "s5", name: "Alternatives" },
            { id: "s6", name: "Recommendations" },
            { id: "s7", name: "Implementation Plan" },
            { id: "s8", name: "Conclusion" },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: "6",
          name: "Marketing Plan",
          description: "Template for comprehensive marketing plans with strategy and execution details",
          sections: [
            { id: "s1", name: "Executive Summary" },
            { id: "s2", name: "Market Analysis" },
            { id: "s3", name: "Target Audience" },
            { id: "s4", name: "Competitive Analysis" },
            { id: "s5", name: "Marketing Strategy" },
            { id: "s6", name: "Tactics and Channels" },
            { id: "s7", name: "Budget" },
            { id: "s8", name: "Timeline" },
            { id: "s9", name: "KPIs and Metrics" },
            { id: "s10", name: "Contingency Plan" },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: "7",
          name: "Technical Documentation",
          description: "Template for technical documentation with system architecture and implementation details",
          sections: [
            { id: "s1", name: "Introduction" },
            { id: "s2", name: "System Overview" },
            { id: "s3", name: "Architecture" },
            { id: "s4", name: "Installation Guide" },
            { id: "s5", name: "Configuration" },
            { id: "s6", name: "API Reference" },
            { id: "s7", name: "Troubleshooting" },
            { id: "s8", name: "FAQ" },
            { id: "s9", name: "Glossary" },
          ],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ]
      foundTemplate = mockTemplates.find((t) => t.id === id)
    }

    if (foundTemplate) {
      setTemplate(foundTemplate)
      setName(foundTemplate.name)
      setDescription(foundTemplate.description || "")
      setSections(foundTemplate.sections.map((s) => ({ ...s })))
    } else {
      setError("Template not found")
    }

    setIsLoading(false)
  }

  const handleAddSection = () => {
    setSections([...sections, { id: `s${Date.now()}`, name: "" }])
  }

  const handleRemoveSection = (id) => {
    if (sections.length > 1) {
      setSections(sections.filter((section) => section.id !== id))
    }
  }

  const handleSectionChange = (id, value) => {
    setSections(sections.map((section) => (section.id === id ? { ...section, name: value } : section)))
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    // Validate form
    if (!name) {
      setError("Please enter a template name")
      return
    }

    if (sections.some((section) => !section.name)) {
      setError("Please fill in all section names")
      return
    }

    setIsSubmitting(true)
    setError("")

    // Create updated template object
    const updatedTemplate = {
      ...template,
      name,
      description,
      sections: sections.map((section, index) => ({
        ...section,
        order: index,
      })),
      updatedAt: new Date().toISOString(),
    }

    // Get existing templates from localStorage
    const existingTemplatesJSON = localStorage.getItem("templates")
    let existingTemplates = []

    try {
      existingTemplates = existingTemplatesJSON ? JSON.parse(existingTemplatesJSON) : []
    } catch (error) {
      console.error("Error parsing stored templates:", error)
    }

    // Update the template in the array
    const updatedTemplates = existingTemplates.map((t) => (t.id === templateId ? updatedTemplate : t))

    // Save back to localStorage
    localStorage.setItem("templates", JSON.stringify(updatedTemplates))

    // Show success message
    alert("Template updated successfully")

    // Navigate back to templates page
    router.push("/templates")
  }

  if (isLoading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <p>Loading...</p>
      </div>
    )
  }

  if (error === "Template not found") {
    return (
      <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto", textAlign: "center" }}>
        <h1 style={{ fontSize: "2rem", marginBottom: "1rem" }}>Template Not Found</h1>
        <p style={{ marginBottom: "2rem" }}>The template you are looking for does not exist or has been deleted.</p>
        <Link
          href="/templates"
          style={{
            padding: "0.5rem 1rem",
            backgroundColor: "#0070f3",
            color: "white",
            borderRadius: "0.25rem",
            textDecoration: "none",
          }}
        >
          Back to Templates
        </Link>
      </div>
    )
  }

  return (
    <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <h1 style={{ fontSize: "2rem", margin: 0 }}>Edit Template</h1>
        <Link
          href="/templates"
          style={{
            padding: "0.5rem 1rem",
            backgroundColor: "#f5f5f5",
            color: "#333",
            borderRadius: "0.25rem",
            textDecoration: "none",
          }}
        >
          Cancel
        </Link>
      </div>

      {error && error !== "Template not found" && (
        <div
          style={{
            padding: "1rem",
            backgroundColor: "#fff2f0",
            borderRadius: "0.25rem",
            marginBottom: "1.5rem",
            border: "1px solid #ffccc7",
            color: "#f5222d",
          }}
        >
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: "2rem" }}>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "500" }}>Template Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter template name"
            style={{
              width: "100%",
              padding: "0.75rem",
              borderRadius: "0.25rem",
              border: "1px solid #d9d9d9",
              fontSize: "1rem",
            }}
            required
          />
        </div>

        <div style={{ marginBottom: "2rem" }}>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "500" }}>Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter template description"
            style={{
              width: "100%",
              padding: "0.75rem",
              borderRadius: "0.25rem",
              border: "1px solid #d9d9d9",
              fontSize: "1rem",
              minHeight: "100px",
              resize: "vertical",
            }}
          />
        </div>

        <div style={{ marginBottom: "2rem" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
            <label style={{ fontWeight: "500" }}>Template Sections</label>
            <button
              type="button"
              onClick={handleAddSection}
              style={{
                padding: "0.25rem 0.5rem",
                backgroundColor: "#0070f3",
                color: "white",
                borderRadius: "0.25rem",
                border: "none",
                cursor: "pointer",
                fontSize: "0.875rem",
              }}
            >
              Add Section
            </button>
          </div>

          {sections.map((section, index) => (
            <div
              key={section.id}
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "0.75rem",
              }}
            >
              <div style={{ marginRight: "0.5rem", color: "#666" }}>{index + 1}.</div>
              <input
                type="text"
                value={section.name}
                onChange={(e) => handleSectionChange(section.id, e.target.value)}
                placeholder="Enter section name"
                style={{
                  flex: "1",
                  padding: "0.5rem",
                  borderRadius: "0.25rem",
                  border: "1px solid #d9d9d9",
                  fontSize: "1rem",
                }}
                required
              />
              <button
                type="button"
                onClick={() => handleRemoveSection(section.id)}
                disabled={sections.length <= 1}
                style={{
                  marginLeft: "0.5rem",
                  padding: "0.25rem 0.5rem",
                  backgroundColor: sections.length <= 1 ? "#f5f5f5" : "#f44336",
                  color: sections.length <= 1 ? "#999" : "white",
                  borderRadius: "0.25rem",
                  border: "none",
                  cursor: sections.length <= 1 ? "not-allowed" : "pointer",
                  fontSize: "0.875rem",
                }}
              >
                Remove
              </button>
            </div>
          ))}
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: "1rem" }}>
          <Link
            href="/templates"
            style={{
              padding: "0.75rem 1.5rem",
              backgroundColor: "#f5f5f5",
              color: "#333",
              borderRadius: "0.25rem",
              textDecoration: "none",
              display: "inline-block",
            }}
          >
            Cancel
          </Link>
          <button
            type="submit"
            disabled={isSubmitting}
            style={{
              padding: "0.75rem 1.5rem",
              backgroundColor: "#0070f3",
              color: "white",
              borderRadius: "0.25rem",
              border: "none",
              cursor: isSubmitting ? "not-allowed" : "pointer",
              fontSize: "1rem",
              opacity: isSubmitting ? 0.7 : 1,
            }}
          >
            {isSubmitting ? "Saving..." : "Save Template"}
          </button>
        </div>
      </form>
    </div>
  )
}

