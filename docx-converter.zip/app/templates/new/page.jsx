"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"

export default function NewTemplate() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [sections, setSections] = useState([{ id: Date.now().toString(), name: "" }])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    // Check if user is authenticated
    const isAuthenticated = localStorage.getItem("isAuthenticated") === "true"

    if (!isAuthenticated) {
      router.push("/login")
    } else {
      // Set loading to false immediately since we don't need to load any data
      setIsLoading(false)
    }
  }, [router])

  const handleAddSection = () => {
    setSections([...sections, { id: Date.now().toString(), name: "" }])
  }

  const handleRemoveSection = (id) => {
    if (sections.length > 1) {
      setSections(sections.filter((section) => section.id !== id))
    }
  }

  const handleSectionChange = (id, value) => {
    setSections(sections.map((section) => (section.id === id ? { ...section, name: value } : section)))
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    // Validate form
    if (!name) {
      setError("Please enter a template name")
      return
    }

    if (sections.some((section) => !section.name)) {
      setError("Please fill in all section names")
      return
    }

    setIsSubmitting(true)
    setError("")

    try {
      // Create a new template object
      const newTemplate = {
        id: Date.now().toString(),
        name,
        description,
        sections: sections.map((section, index) => ({
          ...section,
          order: index,
        })),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      // Get existing templates from localStorage
      const existingTemplatesJSON = localStorage.getItem("templates")
      let existingTemplates = []

      if (existingTemplatesJSON) {
        try {
          const parsed = JSON.parse(existingTemplatesJSON)
          // Ensure we have a valid array
          existingTemplates = Array.isArray(parsed) ? parsed : []
        } catch (parseError) {
          console.error("Error parsing templates from localStorage:", parseError)
          // If parsing fails, start with an empty array
          existingTemplates = []
        }
      }

      // Add the new template
      const updatedTemplates = [...existingTemplates, newTemplate]

      // Save back to localStorage
      localStorage.setItem("templates", JSON.stringify(updatedTemplates))

      // Show success message
      alert("Template created successfully")

      // Navigate back to templates page
      router.push("/templates")
    } catch (error) {
      console.error("Error creating template:", error)
      setError("An error occurred while creating the template. Please try again.")
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <p>Loading...</p>
      </div>
    )
  }

  return (
    <div style={{ padding: "2rem", maxWidth: "800px", margin: "0 auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <h1 style={{ fontSize: "2rem", margin: 0 }}>Create Template</h1>
        <Link
          href="/templates"
          style={{
            padding: "0.5rem 1rem",
            backgroundColor: "#f5f5f5",
            color: "#333",
            borderRadius: "0.25rem",
            textDecoration: "none",
          }}
        >
          Cancel
        </Link>
      </div>

      {error && (
        <div
          style={{
            padding: "1rem",
            backgroundColor: "#fff2f0",
            borderRadius: "0.25rem",
            marginBottom: "1.5rem",
            border: "1px solid #ffccc7",
            color: "#f5222d",
          }}
        >
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: "2rem" }}>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "500" }}>Template Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter template name"
            style={{
              width: "100%",
              padding: "0.75rem",
              borderRadius: "0.25rem",
              border: "1px solid #d9d9d9",
              fontSize: "1rem",
            }}
            required
          />
        </div>

        <div style={{ marginBottom: "2rem" }}>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: "500" }}>Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter template description"
            style={{
              width: "100%",
              padding: "0.75rem",
              borderRadius: "0.25rem",
              border: "1px solid #d9d9d9",
              fontSize: "1rem",
              minHeight: "100px",
              resize: "vertical",
            }}
          />
        </div>

        <div style={{ marginBottom: "2rem" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
            <label style={{ fontWeight: "500" }}>Template Sections</label>
            <button
              type="button"
              onClick={handleAddSection}
              style={{
                padding: "0.25rem 0.5rem",
                backgroundColor: "#0070f3",
                color: "white",
                borderRadius: "0.25rem",
                border: "none",
                cursor: "pointer",
                fontSize: "0.875rem",
              }}
            >
              Add Section
            </button>
          </div>

          {sections.map((section, index) => (
            <div
              key={section.id}
              style={{
                display: "flex",
                alignItems: "center",
                marginBottom: "0.75rem",
              }}
            >
              <div style={{ marginRight: "0.5rem", color: "#666" }}>{index + 1}.</div>
              <input
                type="text"
                value={section.name}
                onChange={(e) => handleSectionChange(section.id, e.target.value)}
                placeholder="Enter section name"
                style={{
                  flex: "1",
                  padding: "0.5rem",
                  borderRadius: "0.25rem",
                  border: "1px solid #d9d9d9",
                  fontSize: "1rem",
                }}
                required
              />
              <button
                type="button"
                onClick={() => handleRemoveSection(section.id)}
                disabled={sections.length <= 1}
                style={{
                  marginLeft: "0.5rem",
                  padding: "0.25rem 0.5rem",
                  backgroundColor: sections.length <= 1 ? "#f5f5f5" : "#f44336",
                  color: sections.length <= 1 ? "#999" : "white",
                  borderRadius: "0.25rem",
                  border: "none",
                  cursor: sections.length <= 1 ? "not-allowed" : "pointer",
                  fontSize: "0.875rem",
                }}
              >
                Remove
              </button>
            </div>
          ))}
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: "1rem" }}>
          <Link
            href="/templates"
            style={{
              padding: "0.75rem 1.5rem",
              backgroundColor: "#f5f5f5",
              color: "#333",
              borderRadius: "0.25rem",
              textDecoration: "none",
              display: "inline-block",
            }}
          >
            Cancel
          </Link>
          <button
            type="submit"
            disabled={isSubmitting}
            style={{
              padding: "0.75rem 1.5rem",
              backgroundColor: "#0070f3",
              color: "white",
              borderRadius: "0.25rem",
              border: "none",
              cursor: isSubmitting ? "not-allowed" : "pointer",
              fontSize: "1rem",
              opacity: isSubmitting ? 0.7 : 1,
            }}
          >
            {isSubmitting ? "Creating..." : "Create Template"}
          </button>
        </div>
      </form>
    </div>
  )
}

