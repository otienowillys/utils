"use client"

import * as React from "react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ThemeDebug() {
  const [mounted, setMounted] = React.useState(false)
  const { theme, setTheme, themes, systemTheme, resolvedTheme } = useTheme()
  const [debugInfo, setDebugInfo] = React.useState<Record<string, any>>({})

  // Avoid hydration mismatch
  React.useEffect(() => {
    setMounted(true)
  }, [])

  // Collect debug information
  React.useEffect(() => {
    if (mounted) {
      const htmlEl = document.documentElement
      const info = {
        theme,
        systemTheme,
        resolvedTheme,
        availableThemes: themes,
        htmlClasses: htmlEl.className,
        htmlDataTheme: htmlEl.getAttribute("data-theme"),
        htmlDataMode: htmlEl.getAttribute("data-mode"),
        hasClassDark: htmlEl.classList.contains("dark"),
        mediaPrefersDark: window.matchMedia("(prefers-color-scheme: dark)").matches,
        localStorageTheme: localStorage.getItem("theme"),
      }
      setDebugInfo(info)
      console.log("Theme debug info:", info)
    }
  }, [mounted, theme, themes, systemTheme, resolvedTheme])

  // Force apply dark class for testing
  const forceApplyDarkClass = () => {
    document.documentElement.classList.add("dark")
    setDebugInfo((prev) => ({ ...prev, manuallyApplied: "dark class added" }))
  }

  // Force remove dark class for testing
  const forceRemoveDarkClass = () => {
    document.documentElement.classList.remove("dark")
    setDebugInfo((prev) => ({ ...prev, manuallyApplied: "dark class removed" }))
  }

  if (!mounted) {
    return <div>Loading...</div>
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-8">Theme Debugging</h1>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Theme Controls</CardTitle>
            <CardDescription>Manually set the theme</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Button onClick={() => setTheme("light")}>Set Light</Button>
              <Button onClick={() => setTheme("dark")}>Set Dark</Button>
              <Button onClick={() => setTheme("system")}>Set System</Button>
              <Button variant="outline" onClick={forceApplyDarkClass}>
                Force Add Dark Class
              </Button>
              <Button variant="outline" onClick={forceRemoveDarkClass}>
                Force Remove Dark Class
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Debug Information</CardTitle>
            <CardDescription>Current theme state</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-4 rounded-md overflow-auto">{JSON.stringify(debugInfo, null, 2)}</pre>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Theme Test Elements</CardTitle>
            <CardDescription>Visual elements to test theme appearance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="p-4 rounded-md bg-primary text-primary-foreground">Primary Background</div>
              <div className="p-4 rounded-md bg-secondary text-secondary-foreground">Secondary Background</div>
              <div className="p-4 rounded-md bg-accent text-accent-foreground">Accent Background</div>
              <div className="p-4 rounded-md bg-muted text-muted-foreground">Muted Background</div>
              <div className="p-4 rounded-md border">Border Element</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

