"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function Dashboard() {
  const router = useRouter()
  // Initialize to null to avoid hydration mismatch
  const [isAuthenticated, setIsAuthenticated] = useState(null)
  const [recentConversions, setRecentConversions] = useState([])
  const [templates, setTemplates] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check authentication after mount
    const authStatus = localStorage?.getItem("isAuthenticated") === "true"
    setIsAuthenticated(authStatus)

    if (!authStatus) {
      router.push("/login")
      return
    }

    // Load data
    loadDashboardData()
  }, [router])

  const loadDashboardData = () => {
    // Load recent conversions from localStorage
    const storedConversionsJSON = localStorage.getItem("recentConversions")
    let conversionsData = []

    if (storedConversionsJSON) {
      try {
        const parsed = JSON.parse(storedConversionsJSON)
        if (Array.isArray(parsed) && parsed.length > 0) {
          conversionsData = parsed.slice(0, 3) // Get only the 3 most recent
        }
      } catch (error) {
        console.error("Error parsing conversions:", error)
      }
    }

    // If no conversions found, use mock data
    if (conversionsData.length === 0) {
      conversionsData = [
        { id: "1", filename: "report.docx", status: "completed", date: "2023-12-15" },
        { id: "2", filename: "contract.docx", status: "completed", date: "2023-12-12" },
        { id: "3", filename: "proposal.docx", status: "failed", date: "2023-12-10" },
      ]
    }

    setRecentConversions(conversionsData)

    // Load templates from localStorage
    const storedTemplatesJSON = localStorage.getItem("templates")
    let templatesData = []

    if (storedTemplatesJSON) {
      try {
        const parsed = JSON.parse(storedTemplatesJSON)
        if (Array.isArray(parsed) && parsed.length > 0) {
          templatesData = parsed.slice(0, 3) // Get only the 3 most recent
        }
      } catch (error) {
        console.error("Error parsing templates:", error)
      }
    }

    // If no templates found, use mock data
    if (templatesData.length === 0) {
      templatesData = [
        { id: "1", name: "Business Report", sections: [1, 2, 3, 4, 5] },
        { id: "2", name: "Legal Contract", sections: [1, 2, 3, 4, 5, 6, 7, 8] },
        { id: "3", name: "Project Proposal", sections: [1, 2, 3, 4, 5, 6] },
      ]
    }

    setTemplates(templatesData)
    setIsLoading(false)
  }

  const handleDeleteConversion = (id) => {
    // Get current conversions from localStorage
    const storedConversionsJSON = localStorage.getItem("recentConversions")
    let storedConversions = []

    try {
      storedConversions = storedConversionsJSON ? JSON.parse(storedConversionsJSON) : []
    } catch (error) {
      console.error("Error parsing conversions:", error)
    }

    // Filter out the conversion to delete
    const updatedConversions = storedConversions.filter((conv) => conv.id !== id)

    // Save back to localStorage
    localStorage.setItem("recentConversions", JSON.stringify(updatedConversions))

    // Update state
    setRecentConversions((prev) => prev.filter((conv) => conv.id !== id))
  }

  // Don't render until authentication is checked
  if (isAuthenticated === null || isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <div className="flex gap-3">
          <Button asChild>
            <Link href="/convert">Convert Document</Link>
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              localStorage.removeItem("isAuthenticated")
              router.push("/login")
            }}
          >
            Logout
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Recent Conversions */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xl">Recent Conversions</CardTitle>
            <Link href="/conversions" className="text-sm text-primary hover:underline">
              View All
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentConversions.length > 0 ? (
                recentConversions.map((conversion) => (
                  <div key={conversion.id} className="flex items-center justify-between p-3 bg-muted/40 rounded-md">
                    <div>
                      <p className="font-medium">{conversion.filename || `Document ${conversion.id}`}</p>
                      <p className="text-sm text-muted-foreground">{conversion.date}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${
                          conversion.status === "completed"
                            ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                            : "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300"
                        }`}
                      >
                        {conversion.status}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive/80 hover:bg-background"
                        onClick={() => handleDeleteConversion(conversion.id)}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-muted-foreground py-4">No recent conversions found.</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Templates */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xl">Templates</CardTitle>
            <Link href="/templates" className="text-sm text-primary hover:underline">
              View All
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {templates.length > 0 ? (
                templates.map((template) => (
                  <div key={template.id} className="flex items-center justify-between p-3 bg-muted/40 rounded-md">
                    <div>
                      <p className="font-medium">{template.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {Array.isArray(template.sections)
                          ? template.sections.length
                          : Object.keys(template.sections || {}).length}{" "}
                        sections
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-primary hover:text-primary/80 hover:bg-background"
                      asChild
                    >
                      <Link href={`/templates/${template.id}`}>Edit</Link>
                    </Button>
                  </div>
                ))
              ) : (
                <p className="text-center text-muted-foreground py-4">No templates found.</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link href="/convert" className="block">
          <div className="h-full p-6 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-100 dark:border-blue-900 hover:shadow-md transition-shadow">
            <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-400 mb-2">Convert Document</h3>
            <p className="text-blue-600 dark:text-blue-300">Upload and convert DOCX files using templates</p>
          </div>
        </Link>

        <Link href="/templates/new" className="block">
          <div className="h-full p-6 bg-green-50 dark:bg-green-950 rounded-lg border border-green-100 dark:border-green-900 hover:shadow-md transition-shadow">
            <h3 className="text-lg font-semibold text-green-700 dark:text-green-400 mb-2">Create Template</h3>
            <p className="text-green-600 dark:text-green-300">Create a new template for document conversion</p>
          </div>
        </Link>

        <Link href="/conversions" className="block">
          <div className="h-full p-6 bg-amber-50 dark:bg-amber-950 rounded-lg border border-amber-100 dark:border-amber-900 hover:shadow-md transition-shadow">
            <h3 className="text-lg font-semibold text-amber-700 dark:text-amber-400 mb-2">Conversion History</h3>
            <p className="text-amber-600 dark:text-amber-300">View your past document conversions</p>
          </div>
        </Link>
      </div>
    </div>
  )
}

