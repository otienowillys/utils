"use client"

import { useState, useEffect } from "react"
import { HeadingExtractor, type DocumentHeading } from "@/components/phase1-heading-extractor"
import { HeadingOrganizer } from "@/components/phase2-heading-organizer"
import { Phase3SectionMapper } from "@/components/phase3-section-mapper"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { LexicalEditor } from "@/components/lexical-editor"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Template } from "@/lib/types"

// Mock templates for demonstration
const mockTemplates: Template[] = [
  {
    id: "template-1",
    name: "Research Paper",
    description: "Standard academic research paper template",
    sections: [
      { id: "section-1", name: "Abstract", type: "text", order: 1 },
      { id: "section-2", name: "Introduction", type: "text", order: 2 },
      { id: "section-3", name: "Literature Review", type: "text", order: 3 },
      { id: "section-4", name: "Methodology", type: "text", order: 4 },
      { id: "section-5", name: "Results", type: "text", order: 5 },
      { id: "section-6", name: "Discussion", type: "text", order: 6 },
      { id: "section-7", name: "Conclusion", type: "text", order: 7 },
      { id: "section-8", name: "References", type: "text", order: 8 },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "template-2",
    name: "Business Report",
    description: "Standard business report template",
    sections: [
      { id: "section-1", name: "Executive Summary", type: "text", order: 1 },
      { id: "section-2", name: "Introduction", type: "text", order: 2 },
      { id: "section-3", name: "Company Overview", type: "text", order: 3 },
      { id: "section-4", name: "Market Analysis", type: "text", order: 4 },
      { id: "section-5", name: "Recommendations", type: "text", order: 5 },
      { id: "section-6", name: "Implementation Plan", type: "text", order: 6 },
      { id: "section-7", name: "Conclusion", type: "text", order: 7 },
      { id: "section-8", name: "Appendices", type: "text", order: 8 },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
]

export default function SectionExtractionDemo() {
  const [extractedHeadings, setExtractedHeadings] = useState<DocumentHeading[]>([])
  const [organizedHeadings, setOrganizedHeadings] = useState<DocumentHeading[]>([])
  const [selectedHeading, setSelectedHeading] = useState<DocumentHeading | null>(null)
  const [activePhase, setActivePhase] = useState<"phase1" | "phase2" | "phase3">("phase1")
  const [templates, setTemplates] = useState<Template[]>(mockTemplates)
  const [sectionMapping, setSectionMapping] = useState<any[]>([])
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>("")
  const { toast } = useToast()

  // Update organized headings when extracted headings change
  useEffect(() => {
    setOrganizedHeadings(extractedHeadings)
  }, [extractedHeadings])

  const handleHeadingsExtracted = (headings: DocumentHeading[]) => {
    setExtractedHeadings(headings)
    toast({
      title: "Headings extracted",
      description: `${headings.length} headings found in the document.`,
    })

    // Automatically move to Phase 2 after extraction
    setActivePhase("phase2")
  }

  const handleHeadingsReordered = (headings: DocumentHeading[]) => {
    setOrganizedHeadings(headings)
  }

  const handleHeadingSelected = (heading: DocumentHeading) => {
    setSelectedHeading(heading)
  }

  const handleMappingComplete = (mapping: any[], templateId: string) => {
    setSectionMapping(mapping)
    setSelectedTemplateId(templateId)

    toast({
      title: "Mapping complete",
      description: "Your document sections have been mapped to the template. Ready for conversion!",
      action: (
        <Button
          onClick={() => {
            // In a real app, this would navigate to the conversion page
            toast({
              title: "Starting conversion",
              description: "Your document is being converted based on the mapping.",
            })
          }}
        >
          Convert Now
        </Button>
      ),
    })
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Document Section Extraction and Mapping</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Tabs value={activePhase} onValueChange={(value) => setActivePhase(value as "phase1" | "phase2" | "phase3")}>
            <TabsList className="mb-4">
              <TabsTrigger value="phase1">Phase 1: Extract</TabsTrigger>
              <TabsTrigger value="phase2" disabled={extractedHeadings.length === 0}>
                Phase 2: Organize
              </TabsTrigger>
              <TabsTrigger value="phase3" disabled={organizedHeadings.length === 0}>
                Phase 3: Map to Template
              </TabsTrigger>
            </TabsList>

            <TabsContent value="phase1">
              <HeadingExtractor onHeadingsExtracted={handleHeadingsExtracted} />
            </TabsContent>

            <TabsContent value="phase2">
              {extractedHeadings.length > 0 ? (
                <HeadingOrganizer
                  headings={extractedHeadings}
                  onHeadingsReordered={handleHeadingsReordered}
                  onHeadingSelected={handleHeadingSelected}
                />
              ) : (
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-center text-gray-500">Please complete Phase 1 to extract headings first.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="phase3">
              {organizedHeadings.length > 0 ? (
                <Phase3SectionMapper
                  headings={organizedHeadings}
                  templates={templates}
                  onMappingComplete={handleMappingComplete}
                />
              ) : (
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-center text-gray-500">Please complete Phase 2 to organize headings first.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Implementation Details</CardTitle>
              <CardDescription>How the document section extraction and mapping works</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Phase 1: Heading Extraction</h3>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li>Upload a DOCX file using drag-and-drop or file selection</li>
                    <li>The system extracts H1, H2, and H3 headings from the document</li>
                    <li>Headings are displayed with their hierarchy levels</li>
                    <li>The extracted structure is prepared for Phase 2</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Phase 2: Drag-and-Drop Functionality</h3>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li>Headings can be reordered using drag-and-drop</li>
                    <li>Visual feedback is provided during dragging</li>
                    <li>Headings can be edited, added, or deleted</li>
                    <li>The final structure can be saved for further processing</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Phase 3: Template Mapping</h3>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li>Select a document template to map sections to</li>
                    <li>Map each extracted heading to a template section</li>
                    <li>Auto-mapping feature for quick matching based on content</li>
                    <li>Save the mapping for document conversion</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="h-full">
            <CardHeader>
              <CardTitle>{selectedHeading ? selectedHeading.text : "Section Content"}</CardTitle>
              <CardDescription>
                {selectedHeading
                  ? `Level ${selectedHeading.level} heading content`
                  : "Select a heading to view and edit its content"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {selectedHeading ? (
                <div>
                  <LexicalEditor
                    initialContent={selectedHeading.content}
                    onChange={(content) => {
                      console.log("Content updated:", content)

                      // In a real implementation, you would update the heading content
                      // in the extractedHeadings or organizedHeadings array
                    }}
                    placeholder="Edit section content here..."
                    className="min-h-[300px] border border-gray-200 rounded-md p-4"
                  />
                  <div className="flex justify-end mt-4">
                    <Button>Save Content</Button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-[300px] text-center">
                  <p className="mb-4 text-gray-500">
                    {extractedHeadings.length > 0
                      ? "Select a heading from the list to view and edit its content"
                      : "Extract headings from a document to get started"}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {sectionMapping.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Mapping Summary</CardTitle>
                <CardDescription>
                  {templates.find((t) => t.id === selectedTemplateId)?.name || "Template"} mapping
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {sectionMapping.map((item, index) => {
                    const templateSection = templates
                      .find((t) => t.id === selectedTemplateId)
                      ?.sections.find((s) => s.id === item.templateSectionId)

                    const documentHeading = organizedHeadings.find((h) => h.id === item.documentHeadingId)

                    return (
                      <li key={index} className="text-sm">
                        <span className="font-medium">{templateSection?.name || "Unknown section"}</span>
                        {documentHeading ? (
                          <span className="text-green-600"> ➔ {documentHeading.text}</span>
                        ) : (
                          <span className="text-gray-400"> ➔ Not mapped</span>
                        )}
                      </li>
                    )
                  })}
                </ul>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

