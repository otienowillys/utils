"use client"

import { ThemeToggle } from "@/components/theme-toggle"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ThemeDemo() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-8">Theme Toggle Demo</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Dropdown Theme Toggle</CardTitle>
            <CardDescription>Compact dropdown menu for theme selection</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <ThemeToggle variant="dropdown" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tabs Theme Toggle</CardTitle>
            <CardDescription>More visible tabs interface for theme selection</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <ThemeToggle variant="tabs" />
          </CardContent>
        </Card>
      </div>

      <div className="mt-10">
        <Card>
          <CardHeader>
            <CardTitle>Theme Preview</CardTitle>
            <CardDescription>See how different elements look in the current theme</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-md bg-primary text-primary-foreground">Primary</div>
                <div className="p-4 rounded-md bg-secondary text-secondary-foreground">Secondary</div>
                <div className="p-4 rounded-md bg-accent text-accent-foreground">Accent</div>
                <div className="p-4 rounded-md bg-muted text-muted-foreground">Muted</div>
              </div>

              <div className="border rounded-md p-4">
                <p className="text-foreground mb-2">Text in foreground color</p>
                <p className="text-muted-foreground mb-2">Text in muted foreground color</p>
                <div className="flex gap-2">
                  <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md">Primary Button</button>
                  <button className="px-4 py-2 bg-secondary text-secondary-foreground rounded-md">
                    Secondary Button
                  </button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

