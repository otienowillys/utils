"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { SectionMapper } from "@/components/section-mapper"
import { StepIndicator } from "@/components/step-indicator"
import type { Template } from "@/lib/types"

export default function SectionMappingDemo() {
  const [currentStep] = useState(3) // Fixed to step 3 for this page
  const [sectionMapping, setSectionMapping] = useState<Record<string, string>>({})
  const [template, setTemplate] = useState<Template | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const steps = [
    { number: 1, label: "Upload" },
    { number: 2, label: "Select Template" },
    { number: 3, label: "Map Sections" },
    { number: 4, label: "Convert" },
  ]

  useEffect(() => {
    // Load a sample template for demonstration
    const sampleTemplate: Template = {
      id: "1",
      name: "Business Report",
      description: "Standard template for business reports",
      sections: [
        { id: "s1", name: "Executive Summary", order: 0, type: "text" },
        { id: "s2", name: "Introduction", order: 1, type: "text" },
        { id: "s3", name: "Methodology", order: 2, type: "text" },
        { id: "s4", name: "Findings", order: 3, type: "text" },
        { id: "s5", name: "Recommendations", order: 4, type: "text" },
        { id: "s6", name: "Conclusion", order: 5, type: "text" },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    setTemplate(sampleTemplate)
    setIsLoading(false)
  }, [])

  const handleSectionMappingChange = (mapping: Record<string, string>) => {
    setSectionMapping(mapping)
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <div className="dark bg-[#000814] text-white min-h-screen p-4">
      <StepIndicator steps={steps} currentStep={currentStep} />

      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-2">Step 3: Map Sections</h1>
        <p className="text-gray-400 mb-6">Map sections from your document to the template sections.</p>

        {template && <SectionMapper templateSections={template.sections} onChange={handleSectionMappingChange} />}

        <div className="flex justify-between mt-6">
          <Button variant="outline" className="border-gray-700 text-white hover:bg-gray-800">
            Previous
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white">Next</Button>
        </div>
      </div>
    </div>
  )
}

