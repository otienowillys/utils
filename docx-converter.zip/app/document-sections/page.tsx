"use client"

import { useState } from "react"
import { DocumentHeadingExtractor, type DocumentHeading } from "@/components/document-heading-extractor"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { LexicalEditor } from "@/components/lexical-editor"

export default function DocumentSectionsPage() {
  const [selectedHeading, setSelectedHeading] = useState<DocumentHeading | null>(null)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const { toast } = useToast()

  const handleHeadingSelected = (heading: DocumentHeading) => {
    setSelectedHeading(heading)
    toast({
      title: `Selected: ${heading.text}`,
      description: `Level ${heading.level} heading`,
    })
  }

  const toggleDarkMode = () => {
    setIsDarkMode((prev) => !prev)
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? "bg-gray-900 text-white dark" : "bg-gray-50 text-gray-900"}`}>
      <div className="container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Document Section Management</h1>
          <Button variant="outline" onClick={toggleDarkMode}>
            {isDarkMode ? "Light Mode" : "Dark Mode"}
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <DocumentHeadingExtractor
              onHeadingSelected={handleHeadingSelected}
              isDarkMode={isDarkMode}
              className="mb-6"
            />

            <Card className={isDarkMode ? "bg-gray-800 border-gray-700" : ""}>
              <CardHeader>
                <CardTitle>Instructions</CardTitle>
                <CardDescription>How to use the document section manager</CardDescription>
              </CardHeader>
              <CardContent>
                <ol className={`list-decimal pl-5 space-y-2 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                  <li>Upload a DOCX file using the panel above</li>
                  <li>The system will extract H1, H2, and H3 headings from your document</li>
                  <li>You can drag and drop headings to reorder them</li>
                  <li>Click on a heading to view and edit its content</li>
                  <li>Use the edit button to modify heading text if needed</li>
                  <li>Click "Save Order" when you're satisfied with the arrangement</li>
                </ol>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className={`${isDarkMode ? "bg-gray-800 border-gray-700" : ""} h-full`}>
              <CardHeader>
                <CardTitle>{selectedHeading ? selectedHeading.text : "Section Content"}</CardTitle>
                <CardDescription>
                  {selectedHeading
                    ? `Level ${selectedHeading.level} heading content`
                    : "Select a heading to view and edit its content"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {selectedHeading ? (
                  <div>
                    <LexicalEditor
                      initialContent={selectedHeading.content}
                      onChange={(content) => {
                        console.log("Content updated:", content)
                      }}
                      placeholder="Edit section content here..."
                      className={`min-h-[300px] border ${
                        isDarkMode ? "border-gray-700" : "border-gray-200"
                      } rounded-md p-4`}
                    />
                    <div className="flex justify-end mt-4">
                      <Button>Save Content</Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[300px] text-center">
                    <p className={`mb-4 ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                      Select a heading from the list to view and edit its content
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

